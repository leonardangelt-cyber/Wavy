package app.wavy.player.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.wavy.player.MusicViewModel
import app.wavy.player.data.MediaRepository
import app.wavy.player.data.Song
import kotlinx.coroutines.flow.StateFlow

private val PERMISSIONS: Array<String> = if (Build.VERSION.SDK_INT >= 33) {
    arrayOf(
        Manifest.permission.READ_MEDIA_AUDIO,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.POST_NOTIFICATIONS,
    )
} else {
    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WavyApp(vm: MusicViewModel) {
    val ctx = LocalContext.current
    val songs by vm.songs.collectAsStateWithLifecycle()
    val loaded by vm.loaded.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val excluded by vm.excludedIds.collectAsStateWithLifecycle()
    val ps by vm.player.collectAsStateWithLifecycle()
    val seed by vm.seed.collectAsStateWithLifecycle()
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val current by vm.currentSong.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var openPlaylistId by rememberSaveable { mutableStateOf<Long?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var granted by remember { mutableStateOf(MediaRepository.hasPermission(ctx)) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = MediaRepository.hasPermission(ctx)
        if (granted) vm.refreshSongs()
    }

    // Beim ersten Start gleich nach der Berechtigung fragen
    androidx.compose.runtime.LaunchedEffect(Unit) {
        if (granted) vm.refreshSongs() else launcher.launch(PERMISSIONS)
    }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        granted = MediaRepository.hasPermission(ctx)
        if (granted) vm.refreshSongs()
    }

    val songsById = remember(songs) { songs.associateBy { it.id } }
    val openPlaylist = playlists.firstOrNull { it.id == openPlaylistId }

    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && tab == 1 && openPlaylist != null) { openPlaylistId = null }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                Column {
                    AnimatedVisibility(visible = current != null) {
                        current?.let { s ->
                            PlayerTheme(seed) {
                                MiniPlayerHost(
                                    song = s,
                                    isPlaying = ps.isPlaying,
                                    durationMs = if (ps.durationMs > 0) ps.durationMs else s.durationMs,
                                    positionFlow = vm.position,
                                    onOpen = { showPlayer = true },
                                    onToggle = vm::togglePlay,
                                    onNext = vm::next,
                                )
                            }
                        }
                    }
                    NavigationBar {
                        NavigationBarItem(
                            selected = tab == 0,
                            onClick = { tab = 0 },
                            icon = { Icon(Icons.Rounded.Home, null) },
                            label = { Text("Start") },
                        )
                        NavigationBarItem(
                            selected = tab == 1,
                            onClick = { tab = 1 },
                            icon = { Icon(Icons.AutoMirrored.Rounded.QueueMusic, null) },
                            label = { Text("Playlists") },
                        )
                    }
                }
            },
        ) { padding ->
            val bottom = padding.calculateBottomPadding()
            when (tab) {
                0 -> HomeScreen(
                    songs = songs,
                    loaded = loaded,
                    granted = granted,
                    excluded = excluded,
                    currentId = ps.mediaId,
                    bottomPad = bottom,
                    onRequestPermission = { launcher.launch(PERMISSIONS) },
                    onPlayAll = { vm.playHome(it, shuffle = false) },
                    onShuffle = { vm.playHome(it, shuffle = true) },
                    onSongClick = { list, s -> vm.playFromHome(list, s) },
                )
                else -> if (openPlaylist == null) {
                    PlaylistsScreen(
                        playlists = playlists,
                        songsById = songsById,
                        bottomPad = bottom,
                        onOpen = { openPlaylistId = it },
                        onCreate = { openPlaylistId = vm.createPlaylist(it) },
                    )
                } else {
                    val plSongs: List<Song> = openPlaylist.songIds.mapNotNull { songsById[it] }
                    PlaylistDetailScreen(
                        playlist = openPlaylist,
                        songs = plSongs,
                        allSongs = songs,
                        currentId = ps.mediaId,
                        bottomPad = bottom,
                        onBack = { openPlaylistId = null },
                        onPlay = { shuffle -> vm.playPlaylist(plSongs, shuffle) },
                        onSongClick = { s -> vm.playPlaylistSong(plSongs, s) },
                        onToggleSong = { sid -> vm.toggleSong(openPlaylist.id, sid) },
                        onToggleExclude = { vm.setExclude(openPlaylist.id, it) },
                        onRename = { vm.renamePlaylist(openPlaylist.id, it) },
                        onDelete = {
                            val id = openPlaylist.id
                            openPlaylistId = null
                            vm.deletePlaylist(id)
                        },
                    )
                }
            }
        }

        // Voller Player (Cover, Zeitstrahl, Steuerung) – alles in den Cover-Farben
        AnimatedVisibility(
            visible = showPlayer && current != null,
            enter = slideInVertically(spring(dampingRatio = 0.85f, stiffness = 380f)) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            current?.let { s ->
                PlayerTheme(seed) {
                    PlayerScreen(
                        song = s,
                        state = ps,
                        positionFlow = vm.position,
                        lyrics = lyrics,
                        onClose = { showPlayer = false },
                        onToggle = vm::togglePlay,
                        onNext = vm::next,
                        onPrev = vm::prev,
                        onSeekFraction = vm::seekFraction,
                        onSeekMs = vm::seekToMs,
                        onShuffle = vm::toggleShuffle,
                        onRepeat = vm::cycleRepeat,
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniPlayerHost(
    song: Song,
    isPlaying: Boolean,
    durationMs: Long,
    positionFlow: StateFlow<Long>,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
) {
    val position by positionFlow.collectAsStateWithLifecycle()
    val progress = if (durationMs > 0) (position.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    MiniPlayer(
        song = song,
        isPlaying = isPlaying,
        progress = progress,
        onOpen = onOpen,
        onToggle = onToggle,
        onNext = onNext,
    )
}
