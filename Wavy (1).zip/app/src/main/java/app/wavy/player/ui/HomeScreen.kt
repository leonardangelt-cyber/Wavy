package app.wavy.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    songs: List<Song>,
    loaded: Boolean,
    granted: Boolean,
    excluded: Set<Long>,
    currentId: Long?,
    bottomPad: Dp,
    onRequestPermission: () -> Unit,
    onPlayAll: (List<Song>) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onSongClick: (List<Song>, Song) -> Unit,
) {
    var filter by rememberSaveable { mutableIntStateOf(0) }
    val shown = remember(songs, filter) { if (filter == 1) songs.filter { it.isDownload } else songs }
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    Scaffold(
        modifier = Modifier.padding(bottom = bottomPad).nestedScroll(scroll.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = { Text("Deine Musik", fontWeight = FontWeight.Bold) },
                scrollBehavior = scroll,
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { inner ->
        when {
            !granted -> EmptyState(
                title = "Zugriff auf deine Musik",
                text = "Erlaube den Zugriff auf Audio- und MP4-Dateien, damit Wavy deine Songs anzeigen kann.",
                modifier = Modifier.padding(inner),
                buttonText = "Zugriff erlauben",
                onButton = onRequestPermission,
            )
            loaded && songs.isEmpty() -> EmptyState(
                title = "Keine Songs gefunden",
                text = "Lade Musik auf dein Handy (z. B. in den Ordner Download oder Music), dann erscheint sie hier.",
                modifier = Modifier.padding(inner),
            )
            else -> LazyColumn(
                contentPadding = PaddingValues(
                    start = 16.dp, end = 16.dp,
                    top = inner.calculateTopPadding() + 4.dp, bottom = 24.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                item {
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onPlayAll(shown) },
                            modifier = Modifier.weight(1f).height(56.dp),
                            shape = CircleShape,
                        ) {
                            Icon(Icons.Rounded.PlayArrow, null, Modifier.size(ButtonDefaults.IconSize))
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Text("Alle abspielen")
                        }
                        FilledTonalButton(
                            onClick = { onShuffle(shown) },
                            modifier = Modifier.weight(1f).height(56.dp),
                            shape = CircleShape,
                        ) {
                            Icon(Icons.Rounded.Shuffle, null, Modifier.size(ButtonDefaults.IconSize))
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Text("Shuffle")
                        }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = filter == 0, onClick = { filter = 0 }, label = { Text("Alle") })
                        FilterChip(selected = filter == 1, onClick = { filter = 1 }, label = { Text("Downloads") })
                    }
                }
                item {
                    Text(
                        "${shown.size} Songs",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
                    )
                }
                itemsIndexed(shown, key = { _, s -> s.id }) { i, s ->
                    SongRow(
                        song = s,
                        index = i,
                        count = shown.size,
                        isCurrent = s.id == currentId,
                        note = if (s.id in excluded) "nicht in Auto-Wiedergabe" else null,
                        onClick = { onSongClick(shown, s) },
                    )
                }
            }
        }
    }
}
