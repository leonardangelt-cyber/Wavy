package app.wavy.player.ui

import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.rounded.Bedtime
import kotlin.math.roundToInt
import androidx.compose.ui.zIndex
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.key
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.LongState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import androidx.media3.common.Player
import app.wavy.player.PlayerUi
import app.wavy.player.data.LyricsUi
import app.wavy.player.data.Song
import app.wavy.player.data.TranslationStatus
import app.wavy.player.data.TranslationUi
import kotlin.math.abs
import kotlin.math.PI
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    song: Song,
    prevSong: Song?,
    nextSong: Song?,
    state: PlayerUi,
    positionMs: LongState,
    lyrics: LyricsUi,
    translation: TranslationUi,
    onTranslate: () -> Unit,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onPrevTrack: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onSeekFraction: (Float) -> Unit,
    onSeekStart: () -> Unit,
    onSeekEnd: () -> Unit,
    onSeekMs: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    contentAlpha: () -> Float = { 1f },
    hideCover: () -> Boolean = { false },
    onCoverBounds: (androidx.compose.ui.geometry.Rect) -> Unit = {},
    songsById: Map<Long, Song> = emptyMap(),
    onPull: (Float) -> Float = { 0f },
    onPullEnd: (Float) -> Unit = {},
    onPeek: (Song?) -> Unit = {},
    onPlayQueueItem: (Long) -> Unit = {},
    onMoveQueue: (Long, Long) -> Unit = { _, _ -> },
    sleepLeftMin: Int = 0,
    onSleep: (Int) -> Unit = {},
    karaoke: Boolean = true,
) {
    var showSleep by remember { mutableStateOf(false) }
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val duration = if (state.durationMs > 0) state.durationMs else song.durationMs

    val corner by animateDpAsState(
        if (state.isPlaying) 12.dp else 8.dp,
        spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "coverCorner",
    )
    // Pausiert: das Cover rückt ein Stück nach hinten, beim Abspielen wird es wieder groß
    val scale by animateFloatAsState(
        if (state.isPlaying) 1f else 0.84f,
        spring(dampingRatio = 0.7f, stiffness = 260f),
        label = "coverScale",
    )
    val playCorner by animateDpAsState(
        if (state.isPlaying) 28.dp else 42.dp,
        spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "playCorner",
    )

    // Nach unten ziehen (am Anfang der Liste) zieht den Player kontrolliert zusammen (App steuert die Animation).
    // Im Warteschlangen-Modus bringt es stattdessen zurück zur normalen Ansicht.
    var queueMode by rememberSaveable { mutableStateOf(false) }
    val queueNow by rememberUpdatedState(queueMode)
    val pull by rememberUpdatedState(onPull)
    val pullEnd by rememberUpdatedState(onPullEnd)
    val dismissConn = remember {
        object : NestedScrollConnection {
            var pulling = false
            var qPull = 0f
            var upPull = 0f

            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (!queueNow && pulling && available.y < 0f) {
                    return Offset(0f, pull(available.y))
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                // Nur echte Fingerbewegungen zählen (nicht das Auslaufen eines Wischens)
                if (source == NestedScrollSource.Fling || source == NestedScrollSource.SideEffect) return Offset.Zero
                if (available.y > 0f) {
                    if (queueNow) {
                        qPull += available.y
                        return Offset.Zero
                    }
                    pulling = true
                    return Offset(0f, pull(available.y))
                }
                if (available.y < 0f && !queueNow && !pulling) upPull += available.y
                return Offset.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (pulling) {
                    pulling = false
                    pullEnd(0f)
                }
                return Velocity.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (queueNow) {
                    if (qPull > 140f || available.y > 2000f) queueMode = false
                    qPull = 0f
                    return Velocity.Zero
                }
                if (!pulling) {
                    if (upPull < -120f || available.y < -1800f) queueMode = true
                    upPull = 0f
                    return Velocity.Zero
                }
                pulling = false
                upPull = 0f
                pullEnd(available.y)
                return available
            }
        }
    }
    val q by animateFloatAsState(if (queueMode) 1f else 0f, spring(dampingRatio = 0.9f, stiffness = 320f), label = "queueMode")
    androidx.activity.compose.BackHandler(enabled = queueMode) { queueMode = false }

    // Wischen auf Cover/Titel: links = nächster Song, rechts = vorheriger Song
    var swipePx by remember { mutableFloatStateOf(0f) }
    var swipeW by remember { mutableIntStateOf(1) }
    val swipeState = rememberDraggableState { d -> swipePx += d }
    val density = LocalDensity.current
    // Wechselt der Song, springt das Karussell nahtlos in die Mitte (der neue Song steht schon an der richtigen Stelle)
    var lastId by remember { mutableLongStateOf(song.id) }
    if (song.id != lastId) {
        lastId = song.id
        swipePx = 0f
    }

    // Akzentfarbe folgt schon dem Song, auf den man gerade wischt
    val peekSong = when {
        swipePx < -swipeW * 0.3f -> nextSong
        swipePx > swipeW * 0.3f -> prevSong
        else -> null
    }
    LaunchedEffect(peekSong?.id) { onPeek(peekSong) }
    DisposableEffect(Unit) { onDispose { onPeek(null) } }

    // Komplett deckender Hintergrund (nichts schimmert durch), Touches werden hier abgefangen.
    Box(
        Modifier
            .fillMaxSize()
            .background(cs.surface)
            .background(
                Brush.verticalGradient(
                    0f to cs.primaryContainer,
                    0.65f to cs.surface,
                    1f to cs.surface,
                ),
            )
            .pointerInput(Unit) { detectTapGestures { } }
            .nestedScroll(dismissConn),
    ) {
        if (q < 0.999f) Column(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = contentAlpha() * (1f - q) }
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalIconButton(onClick = onClose, modifier = Modifier.size(52.dp), shape = CircleShape) {
                    Icon(Icons.Rounded.KeyboardArrowDown, "Schließen", Modifier.size(30.dp))
                }
                Text(
                    "Aktuelle Wiedergabe",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f).padding(start = 20.dp),
                )
                if (sleepLeftMin > 0) {
                    Text("$sleepLeftMin min", style = MaterialTheme.typography.labelLarge, color = cs.primary, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { showSleep = true }) {
                    Icon(Icons.Rounded.Bedtime, "Schlaftimer", tint = if (sleepLeftMin > 0) cs.primary else cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(16.dp))

            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val coverSize = if (maxWidth < 600.dp) maxWidth else 600.dp
                Box(
                    Modifier
                        .fillMaxWidth()
                        .onSizeChanged { swipeW = it.width }
                        .draggable(
                            state = swipeState,
                            orientation = Orientation.Horizontal,
                            onDragStopped = { v ->
                                val pitch = swipeW + with(density) { 24.dp.toPx() }
                                val go = when {
                                    swipePx < -pitch * 0.22f || v < -900f -> -1
                                    swipePx > pitch * 0.22f || v > 900f -> 1
                                    else -> 0
                                }
                                val ok = (go < 0 && nextSong != null) || (go > 0 && prevSong != null)
                                if (!ok) {
                                    animate(swipePx, 0f, animationSpec = spring(dampingRatio = 0.75f, stiffness = 380f)) { x, _ -> swipePx = x }
                                } else {
                                    animate(
                                        swipePx,
                                        go * pitch,
                                        initialVelocity = v,
                                        animationSpec = spring(dampingRatio = 0.9f, stiffness = 450f),
                                    ) { x, _ -> swipePx = x }
                                    if (go < 0) onNext() else onPrevTrack()
                                    // Falls der Titel gleich bleibt (z. B. Einzelwiederholung): zurückfedern
                                    delay(700)
                                    if (swipePx != 0f) {
                                        animate(swipePx, 0f, animationSpec = spring(dampingRatio = 0.8f, stiffness = 380f)) { x, _ -> swipePx = x }
                                    }
                                }
                            },
                        ),
                ) {
                    // Vorheriges Cover: direkt links neben dem aktuellen
                    if (prevSong != null) {
                        Box(
                            Modifier.matchParentSize().graphicsLayer {
                                translationX = swipePx - (swipeW + 24.dp.toPx())
                                alpha = if (swipePx == 0f) 0f else 1f
                            },
                        ) { TrackSlot(prevSong, coverSize, scale, corner) }
                    }
                    // Nächstes Cover: direkt rechts daneben, schiebt sich beim Wischen herein
                    if (nextSong != null) {
                        Box(
                            Modifier.matchParentSize().graphicsLayer {
                                translationX = swipePx + (swipeW + 24.dp.toPx())
                                alpha = if (swipePx == 0f) 0f else 1f
                            },
                        ) { TrackSlot(nextSong, coverSize, scale, corner) }
                    }
                    Box(Modifier.graphicsLayer { translationX = swipePx }) {
                        TrackSlot(song, coverSize, scale, corner, hideCover, onCoverBounds)
                    }
                    FilledTonalIconButton(
                        onClick = { showLyrics = !showLyrics },
                        modifier = Modifier.align(Alignment.BottomEnd).size(56.dp),
                        shape = CircleShape,
                        colors = if (showLyrics) IconButtonDefaults.filledIconButtonColors(containerColor = cs.primary, contentColor = cs.onPrimary)
                        else IconButtonDefaults.filledTonalIconButtonColors(),
                    ) { Icon(Icons.Rounded.Lyrics, "Songtext") }
                }
            }
            Spacer(Modifier.height(12.dp))

            Column(Modifier.fillMaxWidth()) {
                SeekSection(
                    positionMs = positionMs,
                    durationMs = duration,
                    playing = state.isPlaying,
                    onSeek = onSeekFraction,
                    onSeekStart = onSeekStart,
                    onSeekEnd = onSeekEnd,
                )
            }
            Spacer(Modifier.height(12.dp))

            var act by remember { mutableIntStateOf(-1) }
            val setAct: (Int, Boolean) -> Unit = { i, on ->
                if (on) act = i else if (act == i) act = -1
            }
            // Der gedrückte Knopf wird richtig groß, die anderen machen Platz
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TransportButton(0, act, setAct, 1f, onPrev, CircleShape, cs.primaryContainer, cs.onPrimaryContainer) {
                    Icon(Icons.Rounded.SkipPrevious, "Zurück", Modifier.size(36.dp))
                }
                TransportButton(1, act, setAct, 1.2f, onToggle, RoundedCornerShape(playCorner), cs.primary, cs.onPrimary) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (state.isPlaying) "Pause" else "Abspielen",
                        Modifier.size(44.dp),
                    )
                }
                TransportButton(2, act, setAct, 1f, onNext, CircleShape, cs.primaryContainer, cs.onPrimaryContainer) {
                    Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(36.dp))
                }
            }
            Spacer(Modifier.height(14.dp))

            // Shuffle, Wiederholen, Songtext in einer Pille
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(36.dp),
                color = cs.surfaceContainerHigh,
                contentColor = cs.onSurface,
            ) {
                // Überall gleicher Abstand (8 dp) zum Rand und zwischen den Segmenten; Segmente sind konzentrische Kapseln
                Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillAction(state.shuffle, Icons.Rounded.Shuffle, "Shuffle", "Shuffle", onShuffle)
                    PillAction(
                        state.repeat != Player.REPEAT_MODE_OFF,
                        if (state.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        when (state.repeat) {
                            Player.REPEAT_MODE_ONE -> "Einmal wiederholen"
                            Player.REPEAT_MODE_ALL -> "Alles wiederholen"
                            else -> "Wiederholung aus"
                        },
                        when (state.repeat) {
                            Player.REPEAT_MODE_ONE -> "Eins"
                            Player.REPEAT_MODE_ALL -> "Alle"
                            else -> "Aus"
                        },
                        onRepeat,
                    )
                    PillAction(false, Icons.AutoMirrored.Rounded.PlaylistAdd, "Zu Playlist hinzufügen", "Playlist", onAddToPlaylist)
                }
            }
            // Griff: nach oben wischen oder tippen zeigt die Warteschlange
            var upSum by remember { mutableFloatStateOf(0f) }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .clickable { queueMode = true }
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragStart = { upSum = 0f },
                            onDragEnd = { if (upSum < -40f) queueMode = true },
                        ) { _, dy -> upSum += dy }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.size(width = 44.dp, height = 5.dp).clip(CircleShape).background(cs.onSurfaceVariant.copy(alpha = 0.5f)))
            }
            Spacer(Modifier.height(12.dp))
        }
        if (q > 0.001f) {
            QueueView(
                song = song,
                state = state,
                songsById = songsById,
                alpha = q,
                positionMs = positionMs,
                durationMs = duration,
                onSeekFraction = onSeekFraction,
                onSeekStart = onSeekStart,
                onSeekEnd = onSeekEnd,
                onBack = { queueMode = false },
                onToggle = onToggle,
                onNext = onNext,
                onPrev = onPrev,
                onPlay = onPlayQueueItem,
                onMove = onMoveQueue,
                onAddToPlaylist = onAddToPlaylist,
            )
        }
    }

    if (showSleep) {
        SleepSheet(current = sleepLeftMin, onSet = onSleep, onDismiss = { showSleep = false })
    }

    if (showLyrics) {
        ModalBottomSheet(
            onDismissRequest = { showLyrics = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = cs.surfaceContainerHigh,
            contentColor = cs.onSurface,
        ) {
            var showTr by rememberSaveable { mutableStateOf(true) }
            LyricsHeader(translation, showTr, onTranslate) { showTr = !showTr }
            LyricsContent(
                lyrics,
                positionMs,
                onSeekMs,
                if (showTr && translation.status == TranslationStatus.Done) translation.map else emptyMap(),
                karaoke,
            )
        }
    }
}

/** Cover + Titel eines Songs (ein "Slot" im Wisch-Karussell). */
@Composable
private fun TrackSlot(
    song: Song,
    size: Dp,
    scale: Float,
    corner: Dp,
    hideCover: (() -> Boolean)? = null,
    onCoverBounds: ((androidx.compose.ui.geometry.Rect) -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        CoverFramed(
            song = song,
            px = 900,
            modifier = Modifier
                .size(size)
                .then(
                    if (onCoverBounds != null) Modifier.onGloballyPositioned { onCoverBounds(it.boundsInRoot()) } else Modifier,
                )
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    alpha = if (hideCover?.invoke() == true) 0f else 1f
                },
            shape = RoundedCornerShape(corner),
        )
        Spacer(Modifier.height(24.dp))
        Column(Modifier.fillMaxWidth().padding(end = 68.dp)) {
            Text(
                song.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier.marq(),
            )
            Text(
                song.artistLabel,
                style = MaterialTheme.typography.titleMedium,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier.marq(),
            )
        }
    }
}

/** Play/Zurück/Weiter: beim Drücken (und bei jedem Tippen) wächst der Knopf stark, die anderen weichen aus. */
@Composable
private fun RowScope.TransportButton(
    index: Int,
    active: Int,
    onActive: (Int, Boolean) -> Unit,
    baseWeight: Float,
    onClick: () -> Unit,
    shape: Shape,
    container: Color,
    content: Color,
    icon: @Composable () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    var bump by remember { mutableStateOf(false) }
    LaunchedEffect(bump) {
        if (bump) {
            delay(220)
            bump = false
        }
    }
    val on = pressed || bump
    LaunchedEffect(on) { onActive(index, on) }
    val target = when {
        active == index -> baseWeight * 1.9f
        active >= 0 -> baseWeight * 0.7f
        else -> baseWeight
    }
    val w by animateFloatAsState(target, spring(dampingRatio = 0.55f, stiffness = 380f), label = "transportWeight")
    FilledIconButton(
        onClick = {
            bump = true
            onClick()
        },
        modifier = Modifier.weight(w.coerceAtLeast(0.1f)).height(92.dp),
        shape = shape,
        colors = IconButtonDefaults.filledIconButtonColors(containerColor = container, contentColor = content),
        interactionSource = src,
    ) { icon() }
}

/** Ein Segment der Aktions-Pille: aktiv = volle Kapsel in Akzentfarbe, inaktiv = weicher Block. */
@Composable
private fun RowScope.PillAction(
    checked: Boolean,
    icon: ImageVector,
    desc: String,
    label: String,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val bg by animateColorAsState(if (checked) cs.primary else cs.surfaceContainerHighest, tween(220), label = "pillBg")
    val fg by animateColorAsState(if (checked) cs.onPrimary else cs.onSurface, label = "pillFg")
    Row(
        Modifier
            .weight(1f)
            .height(56.dp)
            .pressScale(src, 1.05f)
            .clip(RoundedCornerShape(28.dp))
            .background(bg)
            .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, desc, tint = fg, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun TimeText(ms: () -> Long, style: TextStyle = MaterialTheme.typography.labelLarge) {
    val current by rememberUpdatedState(ms)
    val sec by remember { derivedStateOf { current() / 1000 } }
    Text(formatTime(sec * 1000), style = style, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Zeitstrahl mit Welle, Punkt (Griff) und Zeiten. Antippen oder Ziehen zum Spulen. */
@Composable
private fun SeekSection(
    positionMs: LongState,
    durationMs: Long,
    playing: Boolean,
    onSeek: (Float) -> Unit,
    onSeekStart: () -> Unit,
    onSeekEnd: () -> Unit,
) {
    val startSeek by rememberUpdatedState(onSeekStart)
    val endSeek by rememberUpdatedState(onSeekEnd)
    var width by remember { mutableIntStateOf(0) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val seek by rememberUpdatedState(onSeek)
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .onSizeChanged { width = it.width }
            .pointerInput(Unit) {
                awaitEachGesture {
                    fun frac(x: Float) = if (width > 0) (x / width).coerceIn(0f, 1f) else 0f
                    val down = awaitFirstDown()
                    startSeek()
                    drag = frac(down.position.x)
                    down.consume()
                    do {
                        val event = awaitPointerEvent()
                        val c = event.changes.firstOrNull() ?: break
                        if (c.pressed) {
                            drag = frac(c.position.x)
                            c.consume()
                        }
                    } while (event.changes.any { it.pressed })
                    drag?.let { seek(it) }
                    drag = null
                    endSeek()
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        PillProgress(
            progress = {
                drag ?: if (durationMs > 0) (positionMs.longValue.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
            },
            playing = playing,
            dragging = drag != null,
            color = cs.primary,
            trackColor = cs.primary.copy(alpha = 0.25f),
            trackHeight = 8.dp,
            handleHeight = 14.dp,
            playWidth = 36.dp,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        )
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        TimeText(ms = { drag?.let { (it * durationMs).toLong() } ?: positionMs.longValue })
        Text(
            formatTime(durationMs),
            style = MaterialTheme.typography.labelLarge,
            color = cs.onSurfaceVariant,
        )
    }
}

/** Selbst gezeichneter Wellen-Zeitstrahl mit Griff. Alles Animierte wird erst beim Zeichnen gelesen. */
@Composable
private fun WavyProgress(
    progress: () -> Float,
    playing: Boolean,
    dragging: Boolean,
    color: Color,
    trackColor: Color,
    modifier: Modifier = Modifier,
) {
    // Die Welle bewegt sich nur beim Abspielen (kein Dauerlauf im Leerlauf)
    val phaseAnim = remember { Animatable(0f) }
    LaunchedEffect(playing) {
        if (playing) {
            while (true) {
                phaseAnim.snapTo(0f)
                phaseAnim.animateTo((2 * PI).toFloat(), tween(1800, easing = LinearEasing))
            }
        }
    }
    val path = remember { Path() }
    val amp by animateFloatAsState(
        if (playing && !dragging) 1f else 0f,
        spring(dampingRatio = 0.6f, stiffness = 200f),
        label = "amp",
    )
    val handleH by animateFloatAsState(
        if (dragging) 40f else 30f,
        spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "handle",
    )
    Canvas(modifier.height(44.dp)) {
        val w = size.width
        val cy = size.height / 2
        val stroke = 4.dp.toPx()
        val ampPx = 3.5.dp.toPx() * amp
        val wave = 34.dp.toPx()
        val hw = 5.dp.toPx()
        val hh = handleH.dp.toPx()
        val gap = 6.dp.toPx()
        val x = (w * progress().coerceIn(0f, 1f)).coerceIn(hw, w - hw)

        if (x + gap < w) {
            drawLine(trackColor, Offset(x + gap, cy), Offset(w, cy), stroke, StrokeCap.Round)
        }
        val phase = phaseAnim.value
        val end = x - gap
        if (end > 0f) {
            path.rewind()
            val step = 3.dp.toPx()
            val fadeLen = 16.dp.toPx()
            var px = 0f
            path.moveTo(0f, cy)
            while (px < end) {
                val fade = (px / fadeLen).coerceIn(0f, 1f)
                path.lineTo(px, cy + ampPx * fade * sin(px / wave * 2f * PI.toFloat() - phase))
                px += step
            }
            path.lineTo(end, cy + ampPx * sin(end / wave * 2f * PI.toFloat() - phase))
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        drawRoundRect(
            color,
            topLeft = Offset(x - hw / 2, cy - hh / 2),
            size = Size(hw, hh),
            cornerRadius = CornerRadius(hw / 2, hw / 2),
        )
    }
}

@Composable
private fun LyricsContent(
    lyrics: LyricsUi,
    positionMs: LongState,
    onSeekMs: (Long) -> Unit,
    translations: Map<String, String>,
    karaoke: Boolean = true,
) {
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier.fillMaxWidth().fillMaxHeight(0.75f),
        contentAlignment = Alignment.Center,
    ) {
        when {
            lyrics.loading -> CircularProgressIndicator()

            lyrics.lines.isNotEmpty() -> {
                val listState = rememberLazyListState()
                val idx by remember(lyrics.lines) {
                    derivedStateOf {
                        val p = positionMs.longValue + 200
                        lyrics.lines.indexOfLast { it.timeMs <= p }
                    }
                }
                // Weiches Mitscrollen: die aktive Zeile gleitet auf ein Drittel der Höhe
                LaunchedEffect(idx) {
                    if (idx < 0) return@LaunchedEffect
                    val info = listState.layoutInfo
                    val target = info.viewportSize.height * 0.30f
                    val item = info.visibleItemsInfo.firstOrNull { it.index == idx }
                    if (item == null) {
                        listState.scrollToItem(idx)
                    } else {
                        listState.animateScrollBy(
                            item.offset - target,
                            spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessVeryLow),
                        )
                    }
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    itemsIndexed(lyrics.lines) { i, line ->
                        val active = i == idx
                        val a by animateFloatAsState(
                            if (active) 1f else 0.4f,
                            spring(stiffness = Spring.StiffnessLow),
                            label = "lyricAlpha",
                        )
                        val sc by animateFloatAsState(
                            if (active) 1f else 0.9f,
                            spring(stiffness = Spring.StiffnessLow),
                            label = "lyricScale",
                        )
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .graphicsLayer {
                                    alpha = a
                                    scaleX = sc
                                    scaleY = sc
                                    transformOrigin = TransformOrigin(0f, 0.5f)
                                }
                                .clickable { onSeekMs(line.timeMs) },
                        ) {
                            if (active && karaoke && line.text.isNotBlank()) {
                                KaraokeLine(
                                    text = line.text,
                                    startMs = line.timeMs,
                                    endMs = lyrics.lines.getOrNull(i + 1)?.timeMs,
                                    positionMs = positionMs,
                                    lit = cs.primary,
                                    dim = cs.onSurface.copy(alpha = 0.5f),
                                    style = MaterialTheme.typography.headlineSmall,
                                )
                            } else {
                                Text(
                                    line.text.ifBlank { "♪" },
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = cs.onSurface,
                                )
                            }
                            translations[line.text.trim()]?.let { tr ->
                                Text(
                                    tr,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = cs.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 4.dp),
                                )
                            }
                        }
                    }
                }
            }

            lyrics.plain != null -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            ) {
                lyrics.plain.lines().forEach { l ->
                    if (l.isBlank()) {
                        Spacer(Modifier.height(14.dp))
                    } else {
                        Text(
                            l,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Medium,
                            color = cs.onSurface,
                        )
                        translations[l.trim()]?.let { tr ->
                            Text(tr, style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }

            lyrics.instrumental -> LyricsMessage("Instrumental – kein Text vorhanden")
            lyrics.error -> LyricsMessage("Keine Internetverbindung. Der Songtext wird im Hintergrund erneut geladen.")
            else -> LyricsMessage("Kein Songtext gefunden")
        }
    }
}

@Composable
private fun LyricsMessage(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(32.dp),
    )
}

@Composable
private fun LyricsHeader(
    tr: TranslationUi,
    showTr: Boolean,
    onTranslate: () -> Unit,
    onToggle: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Songtext",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            when (tr.status) {
                TranslationStatus.Loading -> CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                TranslationStatus.Done -> FilterChip(selected = showTr, onClick = onToggle, label = { Text("Übersetzung") })
                TranslationStatus.Same -> {}
                else -> FilledTonalButton(onClick = onTranslate) { Text("Übersetzen") }
            }
        }
        tr.message?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = if (tr.status == TranslationStatus.Error) cs.error else cs.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}


/** Warteschlange: großes Cover am oberen Rand (verschmilzt mit dem Hintergrund), Name, Balken und Tasten darauf, darunter die nächsten Songs. */
@Composable
private fun QueueView(
    song: Song,
    state: PlayerUi,
    songsById: Map<Long, Song>,
    alpha: Float,
    positionMs: LongState,
    durationMs: Long,
    onSeekFraction: (Float) -> Unit,
    onSeekStart: () -> Unit,
    onSeekEnd: () -> Unit,
    onBack: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onPlay: (Long) -> Unit,
    onMove: (Long, Long) -> Unit,
    onAddToPlaylist: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val density = LocalDensity.current
    val pitchPx = with(density) { (74.dp + 3.dp).toPx() }
    val ids = state.queue
    val local = remember(ids) { mutableStateListOf<Long>().also { it.addAll(ids) } }
    var dragId by remember { mutableStateOf<Long?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val canMove = !state.shuffle
    val btn = IconButtonDefaults.filledTonalIconButtonColors(containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer)

    Column(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                this.alpha = alpha
                translationY = (1f - alpha) * 80f
            }
            .background(cs.surface)
            .verticalScroll(rememberScrollState(), enabled = dragId == null),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.98f)) {
            // Hintergrund hinter dem Cover: oben Akzent-Container, unten Fläche
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to cs.primaryContainer, 0.75f to cs.surface, 1f to cs.surface)))
            // Das Cover selbst blendet oben und unten weich aus (Alpha-Maske), dadurch gibt es keine harte Kante
            Cover(
                song, 900,
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        val stops = Array(17) { i ->
                            val t = i / 16f
                            fun sm(e0: Float, e1: Float, x: Float): Float {
                                val u = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
                                return u * u * (3f - 2f * u)
                            }
                            val a = sm(0f, 0.42f, t) * (1f - sm(0.50f, 1f, t))
                            t to Color.Black.copy(alpha = a)
                        }
                        drawRect(Brush.verticalGradient(colorStops = stops), blendMode = androidx.compose.ui.graphics.BlendMode.DstIn)
                    },
                androidx.compose.ui.graphics.RectangleShape,
            )
            FilledTonalIconButton(
                onClick = onBack,
                modifier = Modifier.statusBarsPadding().padding(start = 16.dp, top = 8.dp).size(48.dp),
                shape = CircleShape,
                colors = btn,
            ) { Icon(Icons.Rounded.KeyboardArrowDown, "Zurück zum Player", Modifier.size(28.dp)) }

            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 20.dp)) {
                Text(song.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.marq())
                Text(song.artistLabel, style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.marq())
                Spacer(Modifier.height(2.dp))
                SeekSection(
                    positionMs = positionMs,
                    durationMs = if (state.durationMs > 0) state.durationMs else durationMs,
                    playing = state.isPlaying,
                    onSeek = onSeekFraction,
                    onSeekStart = onSeekStart,
                    onSeekEnd = onSeekEnd,
                )
                // Eine ruhige Leiste: Zurück und Weiter schlicht, Play/Pause als breite Kapsel in der Akzentfarbe
                Surface(
                    shape = RoundedCornerShape(36.dp),
                    color = cs.surfaceContainerHigh.copy(alpha = 0.92f),
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 2.dp, bottom = 10.dp),
                ) {
                    Row(
                        Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = onPrev, modifier = Modifier.size(width = 64.dp, height = 56.dp)) {
                            Icon(Icons.Rounded.SkipPrevious, "Zurück", Modifier.size(30.dp))
                        }
                        FilledIconButton(
                            onClick = onToggle,
                            modifier = Modifier.size(width = 92.dp, height = 56.dp),
                            shape = RoundedCornerShape(28.dp),
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = cs.primary, contentColor = cs.onPrimary),
                        ) {
                            Icon(
                                if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                if (state.isPlaying) "Pause" else "Abspielen",
                                Modifier.size(32.dp),
                            )
                        }
                        IconButton(onClick = onNext, modifier = Modifier.size(width = 64.dp, height = 56.dp)) {
                            Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(30.dp))
                        }
                    }
                }
            }
        }

        Row(Modifier.padding(start = 20.dp, end = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Als Nächstes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onAddToPlaylist) { Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, "Zu Playlist hinzufügen") }
        }
        if (local.isEmpty()) {
            Text("Keine weiteren Songs in der Warteschlange.", modifier = Modifier.padding(20.dp), color = cs.onSurfaceVariant)
        }
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            val rows = local.toList()
            rows.forEachIndexed { i, id ->
                val s = songsById[id] ?: return@forEachIndexed
                key(id) {
                    val dragging = dragId == id
                    Box(
                        Modifier
                            .zIndex(if (dragging) 1f else 0f)
                            .graphicsLayer {
                                translationY = if (dragging) dragOffset else 0f
                                val sc = if (dragging) 1.03f else 1f
                                scaleX = sc
                                scaleY = sc
                                shadowElevation = if (dragging) 24f else 0f
                                shape = RoundedCornerShape(20.dp)
                            },
                    ) {
                        SongRow(
                            song = s,
                            index = i,
                            count = rows.size,
                            isCurrent = false,
                            onClick = { onPlay(id) },
                            trailing = {
                                if (canMove) {
                                    Box(
                                        Modifier
                                            .size(52.dp)
                                            .pointerInput(id) {
                                                detectDragGesturesAfterLongPress(
                                                    onDragStart = { dragId = id; dragOffset = 0f },
                                                    onDrag = { change, amt ->
                                                        change.consume()
                                                        dragOffset += amt.y
                                                        val cur = local.indexOf(id)
                                                        val target = (cur + (dragOffset / pitchPx).roundToInt()).coerceIn(0, local.lastIndex)
                                                        if (target != cur && cur >= 0) {
                                                            local.add(target, local.removeAt(cur))
                                                            dragOffset -= (target - cur) * pitchPx
                                                        }
                                                    },
                                                    onDragEnd = {
                                                        val to = local.indexOf(id)
                                                        val from = ids.indexOf(id)
                                                        if (to >= 0 && from >= 0 && to != from) onMove(id, ids[to])
                                                        dragId = null
                                                        dragOffset = 0f
                                                    },
                                                    onDragCancel = {
                                                        dragId = null
                                                        dragOffset = 0f
                                                        local.clear(); local.addAll(ids)
                                                    },
                                                )
                                            },
                                        contentAlignment = Alignment.Center,
                                    ) { Icon(Icons.Rounded.DragHandle, "Verschieben") }
                                }
                            },
                        )
                    }
                }
            }
        }
        Spacer(Modifier.navigationBarsPadding().height(120.dp))
    }
}


/**
 * Die gerade gesungene Zeile leuchtet Buchstabe für Buchstabe auf. LRCLIB liefert nur Zeilenzeiten,
 * die Buchstaben werden deshalb gleichmäßig über die geschätzte Singdauer der Zeile verteilt.
 */
@Composable
private fun KaraokeLine(
    text: String,
    startMs: Long,
    endMs: Long?,
    positionMs: LongState,
    lit: Color,
    dim: Color,
    style: TextStyle,
) {
    val letters = remember(text) { text.count { !it.isWhitespace() } }.coerceAtLeast(1)
    val singMs = remember(text, startMs, endMs) {
        val gap = endMs?.let { it - startMs } ?: 5000L
        minOf(gap - 120L, letters * 85L + 400L).coerceAtLeast(400L).toFloat()
    }
    val frac = ((positionMs.longValue + 150L - startMs) / singMs).coerceIn(0f, 1f)
    val cut = frac * letters
    val styled = buildAnnotatedString {
        var n = 0
        text.forEach { ch ->
            if (ch.isWhitespace()) {
                append(ch)
            } else {
                val a = (cut - n).coerceIn(0f, 1f)
                withStyle(SpanStyle(color = androidx.compose.ui.graphics.lerp(dim, lit, a))) { append(ch) }
                n++
            }
        }
    }
    Text(styled, style = style, fontWeight = FontWeight.Bold)
}

/** Schlaftimer im Material-3-Expressive-Stil: große Zahl, Plus/Minus, Schnellwahl und ein großer Startknopf. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SleepSheet(current: Int, onSet: (Int) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var minutes by remember { mutableIntStateOf(if (current > 0) current else 30) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        shape = RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(18.dp)).background(cs.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Bedtime, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(28.dp)) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Schlaftimer", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        if (current > 0) "Läuft noch $current min" else "Die Musik wird sanft ausgeblendet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                FilledTonalIconButton(
                    onClick = { minutes = (minutes - 5).coerceAtLeast(5) },
                    modifier = Modifier.size(64.dp),
                    shape = RoundedCornerShape(22.dp),
                ) { Icon(Icons.Rounded.Remove, "Weniger", Modifier.size(30.dp)) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$minutes", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.ExtraBold, color = cs.primary)
                    Text("Minuten", style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant)
                }
                FilledTonalIconButton(
                    onClick = { minutes = (minutes + 5).coerceAtMost(180) },
                    modifier = Modifier.size(64.dp),
                    shape = RoundedCornerShape(22.dp),
                ) { Icon(Icons.Rounded.Add, "Mehr", Modifier.size(30.dp)) }
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(10, 15, 30, 45, 60).forEach { v ->
                    val sel = minutes == v
                    val r by animateDpAsState(if (sel) 24.dp else 14.dp, spring(dampingRatio = 0.6f, stiffness = 400f), label = "presetShape")
                    val bg by animateColorAsState(if (sel) cs.primary else cs.surfaceContainerHighest, label = "presetBg")
                    val fg by animateColorAsState(if (sel) cs.onPrimary else cs.onSurface, label = "presetFg")
                    Box(
                        Modifier
                            .weight(1f)
                            .height(52.dp)
                            .clip(RoundedCornerShape(r))
                            .background(bg)
                            .clickable { minutes = v },
                        contentAlignment = Alignment.Center,
                    ) { Text("$v", color = fg, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(28.dp))
            androidx.compose.material3.Button(
                onClick = { onSet(minutes); onDismiss() },
                modifier = Modifier.fillMaxWidth().height(60.dp),
                shape = RoundedCornerShape(30.dp),
            ) {
                Icon(Icons.Rounded.Bedtime, null, Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Text(if (current > 0) "Timer neu starten" else "Timer starten", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            if (current > 0) {
                TextButton(onClick = { onSet(0); onDismiss() }, modifier = Modifier.padding(top = 4.dp)) { Text("Timer ausschalten") }
            }
        }
    }
}
