package app.wavy.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.util.Locale

private fun num(n: Int): String = String.format(Locale.getDefault(), "%,d", n)

@Composable
private fun Card(content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
    ) {
        Column(Modifier.padding(20.dp)) { content() }
    }
}

@Composable
fun SettingsScreen(
    apiKey: String,
    limit: Int,
    used: Int,
    bottomPad: Dp,
    onSaveKey: (String) -> Unit,
    onLimit: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var input by remember(apiKey) { mutableStateOf(apiKey) }
    var visible by remember { mutableStateOf(false) }
    val lang = remember { Locale.getDefault().displayLanguage }

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Text(
            "Einstellungen",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.statusBarsPadding().padding(start = 4.dp, top = 16.dp, bottom = 16.dp),
        )

        Card {
            Text("Songtexte übersetzen", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Mit deinem Google-Cloud-Translation-API-Schlüssel übersetzt Wavy Songtexte in deine Systemsprache ($lang). " +
                    "Übersetzt wird nur, wenn du im Songtext auf „Übersetzen“ tippst.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                singleLine = true,
                label = { Text("Google-API-Schlüssel") },
                visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { visible = !visible }) {
                        Icon(if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Anzeigen")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onSaveKey(input) }, enabled = input.trim() != apiKey) { Text("Speichern") }
                if (apiKey.isNotBlank()) {
                    TextButton(onClick = { input = ""; onSaveKey("") }) { Text("Entfernen") }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (apiKey.isBlank()) "Noch kein Schlüssel gespeichert."
                else "Schlüssel gespeichert (endet auf …${apiKey.takeLast(4)}).",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "So bekommst du einen Schlüssel: In der Google Cloud Console ein Projekt anlegen, die „Cloud Translation API“ " +
                    "aktivieren und unter „APIs & Dienste → Anmeldedaten“ einen API-Schlüssel erstellen. " +
                    "Er bleibt nur auf deinem Handy gespeichert und ist nicht in Backups.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }

        Card {
            Text("Sparsam bleiben", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "• Nie automatisch, nur auf Knopfdruck\n" +
                    "• Jede Zeile wird nur einmal gesendet (Refrains zählen einmal)\n" +
                    "• Ergebnisse bleiben gespeichert, derselbe Song kostet nie wieder\n" +
                    "• Ist ein Text schon in deiner Sprache, wird das gemerkt\n" +
                    "• Vor jeder Anfrage wird dein Monatslimit geprüft",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            Text("Monatslimit (Zeichen)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(20_000, 50_000, 100_000, 200_000).forEach { v ->
                    FilterChip(selected = limit == v, onClick = { onLimit(v) }, label = { Text(num(v)) })
                }
            }
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { if (limit > 0) (used.toFloat() / limit).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Diesen Monat verbraucht: ${num(used)} von ${num(limit)} Zeichen",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Google rechnet nach Zeichen ab. Aktuelle Preise und das Gratis-Kontingent findest du in der Preisliste von Google Cloud Translation.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(bottomPad + 16.dp))
    }
}
