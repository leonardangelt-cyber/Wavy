package app.wavy.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Lädt Cover: eingebettetes Bild -> System-Thumbnail -> (bei MP4) Videoframe. */
object CoverLoader {

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing = ConcurrentHashMap.newKeySet<String>()

    private fun key(song: Song, px: Int) = "${song.id}@$px"

    fun cached(song: Song, px: Int): Bitmap? = cache.get(key(song, px))

    suspend fun load(ctx: Context, song: Song, px: Int): Bitmap? {
        val k = key(song, px)
        cache.get(k)?.let { return it }
        if (k in missing) return null
        val bmp = withContext(Dispatchers.IO) { decode(ctx, song, px) }
        if (bmp == null) {
            missing.add(k)
            return null
        }
        cache.put(k, bmp)
        return bmp
    }

    private fun Bitmap.soft(): Bitmap =
        if (config == Bitmap.Config.HARDWARE) copy(Bitmap.Config.ARGB_8888, false) ?: this else this

    private fun decode(ctx: Context, song: Song, px: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, song.uri)
            val bytes = r.embeddedPicture
            if (bytes != null) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.let { return it.soft() }
            }
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        try {
            return ctx.contentResolver.loadThumbnail(song.uri, Size(px, px), null).soft()
        } catch (_: Exception) {
        }
        if (song.isVideo) {
            val rr = MediaMetadataRetriever()
            try {
                rr.setDataSource(ctx, song.uri)
                return rr.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.soft()
            } catch (_: Exception) {
            } finally {
                try { rr.release() } catch (_: Exception) {}
            }
        }
        return null
    }
}
