package app.wavy.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Übersetzt Songtexte mit der Google Cloud Translation API (v2, API-Schlüssel).
 * Sparsam: nur auf Knopfdruck, jede einzigartige Zeile nur einmal, Ergebnis wird gespeichert,
 * Monatslimit wird vor jeder Anfrage geprüft.
 */
class TranslationRepository(ctx: Context, private val settings: SettingsStore) {

    private val dir = File(ctx.filesDir, "translations").apply { mkdirs() }

    private fun file(song: Song, lang: String) = File(dir, "${song.id}_$lang.json")

    /** Gespeichertes Ergebnis (kostet nichts) oder null. */
    fun cached(song: Song, lang: String): TranslationUi? {
        val f = file(song, lang)
        if (!f.exists()) return null
        return try {
            val o = JSONObject(f.readText())
            if (o.optBoolean("same")) {
                TranslationUi(TranslationStatus.Same, message = "Der Songtext ist schon in deiner Sprache.")
            } else {
                val m = o.getJSONObject("map")
                val map = HashMap<String, String>()
                m.keys().forEach { map[it] = m.getString(it) }
                TranslationUi(TranslationStatus.Done, map)
            }
        } catch (_: Exception) {
            null
        }
    }

    suspend fun translate(song: Song, lines: List<String>, lang: String): TranslationUi = withContext(Dispatchers.IO) {
        cached(song, lang)?.let { return@withContext it }

        val key = settings.apiKey.value
        if (key.isBlank()) {
            return@withContext err("Trage zuerst in den Einstellungen deinen Google-API-Schlüssel ein.")
        }
        val unique = lines.map { it.trim() }
            .filter { line -> line.isNotBlank() && line.any { it.isLetter() } }
            .distinct()
        if (unique.isEmpty()) return@withContext err("Keine Textzeilen zum Übersetzen gefunden.")

        settings.refresh()
        val total = unique.sumOf { it.length }
        val used = settings.usedChars.value
        val limit = settings.monthlyLimit.value
        if (used + total > limit) {
            return@withContext err(
                "Monatslimit würde überschritten (Verbrauch $used + dieser Song $total von $limit Zeichen). " +
                    "Du kannst das Limit in den Einstellungen erhöhen.",
            )
        }

        val result = LinkedHashMap<String, String>()
        var sameCount = 0
        var checked = 0
        var i = 0
        while (i < unique.size) {
            val chunk = ArrayList<String>()
            var chars = 0
            while (i < unique.size && chunk.size < 100 && chars + unique[i].length <= 20_000) {
                chunk += unique[i]
                chars += unique[i].length
                i++
            }
            if (chunk.isEmpty()) { // einzelne Zeile ist zu lang – überspringen
                i++
                continue
            }
            when (val r = post(key, chunk, lang)) {
                is Post.Fail -> return@withContext err(r.message)
                is Post.Ok -> {
                    settings.addUsage(chars)
                    chunk.forEachIndexed { idx, orig ->
                        val t = r.items.getOrNull(idx) ?: return@forEachIndexed
                        result[orig] = t.first
                        checked++
                        if (t.second.substringBefore('-').equals(lang, ignoreCase = true)) sameCount++
                    }
                }
            }
        }

        val same = checked > 0 && sameCount * 10 >= checked * 7
        try {
            val o = JSONObject().put("same", same)
            val m = JSONObject()
            if (!same) result.forEach { (k, v) -> m.put(k, v) }
            o.put("map", m)
            file(song, lang).writeText(o.toString())
        } catch (_: Exception) {
        }
        if (same) {
            TranslationUi(TranslationStatus.Same, message = "Der Songtext ist schon in deiner Sprache.")
        } else {
            TranslationUi(TranslationStatus.Done, result)
        }
    }

    private fun err(msg: String) = TranslationUi(TranslationStatus.Error, message = msg)

    private sealed interface Post {
        /** Paare aus (Übersetzung, erkannte Quellsprache) */
        data class Ok(val items: List<Pair<String, String>>) : Post
        data class Fail(val message: String) : Post
    }

    private fun post(key: String, texts: List<String>, lang: String): Post {
        var c: HttpURLConnection? = null
        return try {
            val url = URL("https://translation.googleapis.com/language/translate/v2?key=" + URLEncoder.encode(key, "UTF-8"))
            c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 20_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val body = JSONObject()
                .put("q", JSONArray(texts))
                .put("target", lang)
                .put("format", "text")
                .toString()
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code in 200..299) {
                val arr = JSONObject(text).getJSONObject("data").getJSONArray("translations")
                Post.Ok(
                    List(arr.length()) {
                        val o = arr.getJSONObject(it)
                        o.getString("translatedText") to o.optString("detectedSourceLanguage", "")
                    },
                )
            } else {
                val m = try {
                    JSONObject(text).getJSONObject("error").optString("message")
                } catch (_: Exception) {
                    ""
                }
                Post.Fail(
                    when (code) {
                        400, 403 -> "Google hat den Schlüssel abgelehnt. Prüfe, ob er stimmt und die Cloud Translation API aktiviert ist." +
                            if (m.isNotBlank()) " ($m)" else ""
                        429 -> "Google-Kontingent erreicht. Versuche es später noch einmal."
                        else -> "Übersetzung fehlgeschlagen (Fehler $code)."
                    },
                )
            }
        } catch (_: Exception) {
            Post.Fail("Keine Internetverbindung. Versuche es später noch einmal.")
        } finally {
            c?.disconnect()
        }
    }
}
