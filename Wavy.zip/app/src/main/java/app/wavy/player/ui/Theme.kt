package app.wavy.player.ui

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.ColorUtils

/** App-Theme: Material You (dynamische Farben) + Material 3 Expressive (Motion). */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun WavyTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        content = content,
    )
}

private fun tone(h: Float, s: Float, l: Float): Color =
    Color(ColorUtils.HSLToColor(floatArrayOf(h, s.coerceIn(0f, 1f), l.coerceIn(0f, 1f))))

/** Baut aus der Cover-Farbe ein komplettes Farbschema (hell/dunkel). */
private fun schemeFromSeed(seed: Int, dark: Boolean, base: ColorScheme): ColorScheme {
    val hsl = FloatArray(3)
    ColorUtils.colorToHSL(seed, hsl)
    val h = hsl[0]
    val s = hsl[1].coerceIn(0.35f, 0.85f)
    return if (dark) {
        base.copy(
            primary = tone(h, s, 0.80f),
            onPrimary = tone(h, s, 0.14f),
            primaryContainer = tone(h, s, 0.30f),
            onPrimaryContainer = tone(h, s, 0.90f),
            secondary = tone(h, s * 0.5f, 0.78f),
            onSecondary = tone(h, s * 0.5f, 0.14f),
            secondaryContainer = tone(h, s * 0.45f, 0.27f),
            onSecondaryContainer = tone(h, s * 0.5f, 0.90f),
            tertiary = tone((h + 60f) % 360f, s * 0.6f, 0.78f),
            background = tone(h, 0.22f, 0.08f),
            surface = tone(h, 0.22f, 0.08f),
            onSurface = tone(h, 0.10f, 0.92f),
            onSurfaceVariant = tone(h, 0.15f, 0.78f),
            surfaceContainer = tone(h, 0.22f, 0.12f),
            surfaceContainerHigh = tone(h, 0.22f, 0.16f),
            surfaceContainerHighest = tone(h, 0.22f, 0.20f),
            outline = tone(h, 0.10f, 0.60f),
        )
    } else {
        base.copy(
            primary = tone(h, s, 0.38f),
            onPrimary = Color.White,
            primaryContainer = tone(h, s, 0.88f),
            onPrimaryContainer = tone(h, s, 0.12f),
            secondary = tone(h, s * 0.5f, 0.40f),
            onSecondary = Color.White,
            secondaryContainer = tone(h, s * 0.5f, 0.86f),
            onSecondaryContainer = tone(h, s * 0.5f, 0.12f),
            tertiary = tone((h + 60f) % 360f, s * 0.6f, 0.40f),
            background = tone(h, 0.40f, 0.97f),
            surface = tone(h, 0.40f, 0.97f),
            onSurface = tone(h, 0.10f, 0.10f),
            onSurfaceVariant = tone(h, 0.15f, 0.30f),
            surfaceContainer = tone(h, 0.35f, 0.93f),
            surfaceContainerHigh = tone(h, 0.35f, 0.90f),
            surfaceContainerHighest = tone(h, 0.35f, 0.87f),
            outline = tone(h, 0.10f, 0.50f),
        )
    }
}

@Composable
private fun animColor(target: Color): Color =
    animateColorAsState(target, tween<Color>(700), label = "coverColor").value

/** Alles, was in diesem Block gezeichnet wird, nimmt die Farben des aktuellen Covers an. */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun PlayerTheme(seed: Int?, content: @Composable () -> Unit) {
    val base = MaterialTheme.colorScheme
    val dark = isSystemInDarkTheme()
    val target = remember(seed, dark, base) { if (seed == null) base else schemeFromSeed(seed, dark, base) }
    val scheme = target.copy(
        primary = animColor(target.primary),
        onPrimary = animColor(target.onPrimary),
        primaryContainer = animColor(target.primaryContainer),
        onPrimaryContainer = animColor(target.onPrimaryContainer),
        secondary = animColor(target.secondary),
        onSecondary = animColor(target.onSecondary),
        secondaryContainer = animColor(target.secondaryContainer),
        onSecondaryContainer = animColor(target.onSecondaryContainer),
        tertiary = animColor(target.tertiary),
        background = animColor(target.background),
        surface = animColor(target.surface),
        onSurface = animColor(target.onSurface),
        onSurfaceVariant = animColor(target.onSurfaceVariant),
        surfaceContainer = animColor(target.surfaceContainer),
        surfaceContainerHigh = animColor(target.surfaceContainerHigh),
        surfaceContainerHighest = animColor(target.surfaceContainerHighest),
        outline = animColor(target.outline),
    )
    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        content = content,
    )
}
