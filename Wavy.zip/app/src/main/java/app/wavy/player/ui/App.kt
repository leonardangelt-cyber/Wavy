package app.wavy.player.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.wavy.player.MusicViewModel
import app.wavy.player.data.MediaRepository
import app.wavy.player.data.Song

private val PERMISSIONS: Array<String> = if (Build.VERSION.SDK_INT >= 33) {
    arrayOf(
        Manifest.permission.READ_MEDIA_AUDIO,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.POST_NOTIFICATIONS,
    )
} else {
    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

@Composable
fun WavyApp(vm: MusicViewModel) {
    val ctx = LocalContext.current
    val songs by vm.songs.collectAsStateWithLifecycle()
    val loaded by vm.loaded.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val excluded by vm.excludedIds.collectAsStateWithLifecycle()
    val ps by vm.player.collectAsStateWithLifecycle()
    val seed by vm.seed.collectAsStateWithLifecycle()
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val translation by vm.translation.collectAsStateWithLifecycle()
    val current by vm.currentSong.collectAsStateWithLifecycle()
    val apiKey by vm.settings.apiKey.collectAsStateWithLifecycle()
    val limit by vm.settings.monthlyLimit.collectAsStateWithLifecycle()
    val used by vm.settings.usedChars.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var homeView by rememberSaveable { mutableIntStateOf(0) }
    var groupKey by rememberSaveable { mutableStateOf<String?>(null) }
    var openPlaylistId by rememberSaveable { mutableStateOf<Long?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var addSongId by rememberSaveable { mutableStateOf<Long?>(null) }
    var granted by remember { mutableStateOf(MediaRepository.hasPermission(ctx)) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = MediaRepository.hasPermission(ctx)
        if (granted) vm.refreshSongs()
    }

    LaunchedEffect(Unit) {
        if (granted) vm.refreshSongs() else launcher.launch(PERMISSIONS)
    }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        granted = MediaRepository.hasPermission(ctx)
        if (granted) vm.refreshSongs()
    }

    val songsById = remember(songs) { songs.associateBy { it.id } }
    val openPlaylist = playlists.firstOrNull { it.id == openPlaylistId }
    val addSong = addSongId?.let { songsById[it] }

    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && tab == 1 && openPlaylist != null) { openPlaylistId = null }
    BackHandler(enabled = !showPlayer && tab == 0 && groupKey != null) { groupKey = null }

    // Die Farben des aktuellen Covers färben die ganze App ein
    PlayerTheme(seed) {
        val cs = MaterialTheme.colorScheme
        val density = LocalDensity.current
        var barPx by remember { mutableIntStateOf(0) }
        val bottom = with(density) { barPx.toDp() }

        Box(Modifier.fillMaxSize().background(cs.background)) {
            when (tab) {
                0 -> HomeScreen(
                    songs = songs,
                    loaded = loaded,
                    granted = granted,
                    excluded = excluded,
                    currentId = ps.mediaId,
                    bottomPad = bottom,
                    view = homeView,
                    onView = { homeView = it; groupKey = null },
                    groupKey = groupKey,
                    onGroup = { groupKey = it },
                    onRequestPermission = { launcher.launch(PERMISSIONS) },
                    onPlayAll = { vm.playHome(it, shuffle = false) },
                    onShuffle = { vm.playHome(it, shuffle = true) },
                    onSongClick = { list, s -> vm.playFromHome(list, s) },
                    onMore = { addSongId = it.id },
                    onPlayGroup = { list, shuffle -> vm.playPlaylist(list, shuffle) },
                    onGroupSongClick = { list, s -> vm.playPlaylistSong(list, s) },
                )
                1 -> if (openPlaylist == null) {
                    PlaylistsScreen(
                        playlists = playlists,
                        songsById = songsById,
                        bottomPad = bottom,
                        onOpen = { openPlaylistId = it },
                        onCreate = { openPlaylistId = vm.createPlaylist(it) },
                    )
                } else {
                    val plSongs: List<Song> = openPlaylist.songIds.mapNotNull { songsById[it] }
                    PlaylistDetailScreen(
                        playlist = openPlaylist,
                        songs = plSongs,
                        allSongs = songs,
                        currentId = ps.mediaId,
                        bottomPad = bottom,
                        onBack = { openPlaylistId = null },
                        onPlay = { shuffle -> vm.playPlaylist(plSongs, shuffle) },
                        onSongClick = { s -> vm.playPlaylistSong(plSongs, s) },
                        onToggleSong = { sid -> vm.toggleSong(openPlaylist.id, sid) },
                        onToggleExclude = { vm.setExclude(openPlaylist.id, it) },
                        onRename = { vm.renamePlaylist(openPlaylist.id, it) },
                        onDelete = {
                            val id = openPlaylist.id
                            openPlaylistId = null
                            vm.deletePlaylist(id)
                        },
                    )
                }
                else -> SettingsScreen(
                    apiKey = apiKey,
                    limit = limit,
                    used = used,
                    bottomPad = bottom,
                    onSaveKey = vm.settings::setApiKey,
                    onLimit = vm.settings::setLimit,
                )
            }

            // Schwebende Pill-Navigation mit eingebautem Mini-Player
            FloatingNavBar(
                selected = tab,
                onSelect = { tab = it },
                song = current,
                isPlaying = ps.isPlaying,
                progress = {
                    val dur = if (ps.durationMs > 0) ps.durationMs else current?.durationMs ?: 0L
                    if (dur > 0) (vm.positionMs.longValue.toFloat() / dur).coerceIn(0f, 1f) else 0f
                },
                onOpenPlayer = { showPlayer = true },
                onToggle = vm::togglePlay,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .onSizeChanged { barPx = it.height }
                    .navigationBarsPadding(),
            )

            // Voller Player: deckend, schiebt sich von unten rein, wischen schließt ihn
            AnimatedVisibility(
                visible = showPlayer && current != null,
                enter = slideInVertically(spring(dampingRatio = 0.9f, stiffness = 400f)) { it },
                exit = slideOutVertically(spring(dampingRatio = 1f, stiffness = 500f)) { it },
            ) {
                current?.let { s ->
                    PlayerScreen(
                        song = s,
                        state = ps,
                        positionMs = vm.positionMs,
                        lyrics = lyrics,
                        translation = translation,
                        onTranslate = vm::translateLyrics,
                        onClose = { showPlayer = false },
                        onToggle = vm::togglePlay,
                        onNext = vm::next,
                        onPrev = vm::prev,
                        onSeekFraction = vm::seekFraction,
                        onSeekMs = vm::seekToMs,
                        onShuffle = vm::toggleShuffle,
                        onRepeat = vm::cycleRepeat,
                    )
                }
            }
        }

        // Song zu Playlist(s) hinzufügen (Drei-Punkte-Menü in der Songliste)
        if (addSong != null) {
            AddToPlaylistSheet(
                song = addSong,
                playlists = playlists,
                onToggle = { pid -> vm.toggleSong(pid, addSong.id) },
                onCreate = { name ->
                    val id = vm.createPlaylist(name)
                    vm.toggleSong(id, addSong.id)
                },
                onDismiss = { addSongId = null },
            )
        }
    }
}
