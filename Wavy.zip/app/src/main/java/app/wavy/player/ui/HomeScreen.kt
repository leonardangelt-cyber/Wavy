package app.wavy.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

@Composable
fun HomeScreen(
    songs: List<Song>,
    loaded: Boolean,
    granted: Boolean,
    excluded: Set<Long>,
    currentId: Long?,
    bottomPad: Dp,
    onRequestPermission: () -> Unit,
    onPlayAll: (List<Song>) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onSongClick: (List<Song>, Song) -> Unit,
    onMore: (Song) -> Unit,
) {
    var filter by rememberSaveable { mutableIntStateOf(0) }
    val shown = remember(songs, filter) { if (filter == 1) songs.filter { it.isDownload } else songs }

    Box(Modifier.fillMaxSize().padding(bottom = bottomPad)) {
        when {
            !granted -> EmptyState(
                title = "Zugriff auf deine Musik",
                text = "Erlaube den Zugriff auf Audio- und MP4-Dateien, damit Wavy deine Songs anzeigen kann.",
                modifier = Modifier.statusBarsPadding(),
                buttonText = "Zugriff erlauben",
                onButton = onRequestPermission,
            )
            loaded && songs.isEmpty() -> EmptyState(
                title = "Keine Songs gefunden",
                text = "Lade Musik auf dein Handy (z. B. in den Ordner Download oder Music), dann erscheint sie hier.",
                modifier = Modifier.statusBarsPadding(),
            )
            else -> LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                item(key = "hero") {
                    Hero(
                        count = shown.size,
                        onPlayAll = { onPlayAll(shown) },
                        onShuffle = { onShuffle(shown) },
                    )
                }
                item(key = "filters") {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        val colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = tone(265f, 0.75f, 0.42f),
                            selectedLabelColor = Color.White,
                        )
                        FilterChip(selected = filter == 0, onClick = { filter = 0 }, label = { Text("Alle") }, colors = colors)
                        FilterChip(selected = filter == 1, onClick = { filter = 1 }, label = { Text("Downloads") }, colors = colors)
                    }
                }
                itemsIndexed(shown, key = { _, s -> s.id }) { i, s ->
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        SongRow(
                            song = s,
                            index = i,
                            count = shown.size,
                            isCurrent = s.id == currentId,
                            note = if (s.id in excluded) "nicht in Auto-Wiedergabe" else null,
                            onClick = { onSongClick(shown, s) },
                            onMore = { onMore(s) },
                        )
                    }
                }
            }
        }
    }
}

/** Bunter Kopfbereich mit Verlauf. Weißer Text auf dunklen Farben, immer gut lesbar. */
@Composable
private fun Hero(count: Int, onPlayAll: () -> Unit, onShuffle: () -> Unit) {
    val brush = remember {
        Brush.linearGradient(
            listOf(tone(255f, 0.75f, 0.40f), tone(315f, 0.72f, 0.42f), tone(8f, 0.80f, 0.44f)),
        )
    }
    Box(
        Modifier
            .statusBarsPadding()
            .padding(16.dp)
            .clip(RoundedCornerShape(36.dp))
            .background(brush),
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.12f), radius = size.height * 0.75f, center = Offset(size.width * 0.95f, size.height * 0.05f))
            drawCircle(Color.White.copy(alpha = 0.08f), radius = size.height * 0.55f, center = Offset(size.width * 0.05f, size.height * 1.0f))
            drawCircle(Color.White.copy(alpha = 0.10f), radius = size.height * 0.18f, center = Offset(size.width * 0.62f, size.height * 0.78f))
        }
        Column(Modifier.padding(24.dp)) {
            Text(
                "Deine Musik",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
            )
            Text(
                "$count Songs auf deinem Handy",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White.copy(alpha = 0.9f),
            )
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val s1 = remember { MutableInteractionSource() }
                val s2 = remember { MutableInteractionSource() }
                Button(
                    onClick = onPlayAll,
                    interactionSource = s1,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = tone(255f, 0.75f, 0.30f)),
                    shape = CircleShape,
                    modifier = Modifier.weight(1f).height(54.dp).pressScale(s1),
                ) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(ButtonDefaults.IconSize))
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text("Alle abspielen", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = onShuffle,
                    interactionSource = s2,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.25f), contentColor = Color.White),
                    shape = CircleShape,
                    modifier = Modifier.weight(1f).height(54.dp).pressScale(s2),
                ) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(ButtonDefaults.IconSize))
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text("Shuffle", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
