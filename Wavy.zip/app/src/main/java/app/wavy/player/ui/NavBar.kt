package app.wavy.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

/**
 * Schwebende Pill-Navigation. Spielt gerade ein Song, wandert der Mini-Player als Kapsel
 * in die Leiste (links), die Navigationspunkte schrumpfen auf Icons.
 */
@Composable
fun FloatingNavBar(
    selected: Int,
    onSelect: (Int) -> Unit,
    song: Song?,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpenPlayer: () -> Unit,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val hasSong = song != null
    Surface(
        shape = CircleShape,
        color = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        shadowElevation = 12.dp,
        tonalElevation = 2.dp,
        modifier = modifier
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .then(if (hasSong) Modifier.fillMaxWidth() else Modifier)
            .animateContentSize(spring(dampingRatio = 0.8f, stiffness = 400f)),
    ) {
        Row(
            Modifier.padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (song != null) {
                MiniCapsule(Modifier.weight(1f), song, isPlaying, progress, onOpenPlayer, onToggle)
                Spacer(Modifier.width(2.dp))
            }
            NavPill(selected == 0, !hasSong, Icons.Rounded.Home, "Start") { onSelect(0) }
            NavPill(selected == 1, !hasSong, Icons.AutoMirrored.Rounded.QueueMusic, "Playlists") { onSelect(1) }
            NavPill(selected == 2, !hasSong, Icons.Rounded.Settings, "Einstellungen") { onSelect(2) }
        }
    }
}

@Composable
private fun MiniCapsule(
    modifier: Modifier,
    song: Song,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onOpen,
        shape = CircleShape,
        color = cs.primaryContainer,
        contentColor = cs.onPrimaryContainer,
        modifier = modifier.height(52.dp),
    ) {
        Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(song, 128, Modifier.size(44.dp), CircleShape)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song.artistLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onPrimaryContainer.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = progress,
                    modifier = Modifier.fillMaxSize(),
                    color = cs.primary,
                    trackColor = cs.onPrimaryContainer.copy(alpha = 0.15f),
                    strokeWidth = 3.dp,
                )
                IconButton(onClick = onToggle, modifier = Modifier.size(36.dp)) {
                    Icon(
                        if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (isPlaying) "Pause" else "Abspielen",
                        Modifier.size(22.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun NavPill(
    selected: Boolean,
    showLabel: Boolean,
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (selected) cs.primary else Color.Transparent, label = "navBg")
    val fg = if (selected) cs.onPrimary else cs.onSurfaceVariant
    val src = remember { MutableInteractionSource() }
    Row(
        Modifier
            .pressScale(src, 0.9f)
            .clip(CircleShape)
            .background(bg)
            .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, label, tint = fg)
        AnimatedVisibility(
            visible = selected && showLabel,
            enter = expandHorizontally(spring(dampingRatio = 0.8f, stiffness = 400f)) + fadeIn(),
            exit = shrinkHorizontally(spring(dampingRatio = 0.8f, stiffness = 400f)) + fadeOut(),
        ) {
            Text(
                label,
                color = fg,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
    }
}
