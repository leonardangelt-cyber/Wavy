package app.wavy.player.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import app.wavy.player.PlayerUi
import app.wavy.player.data.LyricsUi
import app.wavy.player.data.Song
import kotlinx.coroutines.flow.StateFlow

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun PlayerScreen(
    song: Song,
    state: PlayerUi,
    positionFlow: StateFlow<Long>,
    lyrics: LyricsUi,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeekFraction: (Float) -> Unit,
    onSeekMs: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
) {
    val position by positionFlow.collectAsStateWithLifecycle()
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    val duration = if (state.durationMs > 0) state.durationMs else song.durationMs
    val progress = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f

    val corner by animateDpAsState(
        if (state.isPlaying) 56.dp else 32.dp,
        spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "coverCorner",
    )
    val scale by animateFloatAsState(
        if (state.isPlaying) 1f else 0.9f,
        spring(dampingRatio = 0.55f, stiffness = 300f),
        label = "coverScale",
    )
    val playCorner by animateDpAsState(
        if (state.isPlaying) 26.dp else 42.dp,
        spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "playCorner",
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0f to cs.primaryContainer.copy(alpha = 0.9f),
                    0.65f to cs.surface,
                    1f to cs.surface,
                ),
            ),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Schließen", Modifier.size(32.dp)) }
                Text(
                    "Wird abgespielt",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.size(48.dp))
            }
            Spacer(Modifier.height(16.dp))

            // Cover
            Cover(
                song = song,
                px = 900,
                modifier = Modifier
                    .widthIn(max = 420.dp)
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .graphicsLayer { scaleX = scale; scaleY = scale },
                shape = RoundedCornerShape(corner),
            )
            Spacer(Modifier.height(28.dp))

            // Titel + Interpret
            Column(Modifier.fillMaxWidth()) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song.artistLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(16.dp))

            // Zeitstrahl
            SeekBar(
                progress = progress,
                playing = state.isPlaying,
                onSeek = onSeekFraction,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(position), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Text(formatTime(duration), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            }
            Spacer(Modifier.height(16.dp))

            // Zurück / Play-Pause / Weiter
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilledTonalIconButton(
                    onClick = onPrev,
                    modifier = Modifier.weight(1f).height(84.dp),
                    shape = CircleShape,
                ) { Icon(Icons.Rounded.SkipPrevious, "Zurück", Modifier.size(36.dp)) }
                FilledIconButton(
                    onClick = onToggle,
                    modifier = Modifier.weight(1.7f).height(84.dp),
                    shape = RoundedCornerShape(playCorner),
                ) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (state.isPlaying) "Pause" else "Abspielen",
                        Modifier.size(44.dp),
                    )
                }
                FilledTonalIconButton(
                    onClick = onNext,
                    modifier = Modifier.weight(1f).height(84.dp),
                    shape = CircleShape,
                ) { Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(36.dp)) }
            }
            Spacer(Modifier.height(16.dp))

            // Shuffle / Wiederholung / Lyrics
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillToggle(
                    checked = state.shuffle,
                    onClick = onShuffle,
                    modifier = Modifier.weight(1f),
                ) { Icon(Icons.Rounded.Shuffle, "Shuffle") }
                PillToggle(
                    checked = state.repeat != Player.REPEAT_MODE_OFF,
                    onClick = onRepeat,
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(
                        if (state.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        when (state.repeat) {
                            Player.REPEAT_MODE_ONE -> "Einmal wiederholen"
                            Player.REPEAT_MODE_ALL -> "Alles wiederholen"
                            else -> "Wiederholung aus"
                        },
                    )
                }
                PillToggle(
                    checked = showLyrics,
                    onClick = { showLyrics = !showLyrics },
                    modifier = Modifier.weight(1f),
                ) { Icon(Icons.Rounded.Lyrics, "Songtext") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showLyrics) {
        ModalBottomSheet(
            onDismissRequest = { showLyrics = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = cs.surfaceContainerHigh,
        ) {
            LyricsContent(lyrics, positionFlow, onSeekMs)
        }
    }
}

@Composable
private fun PillToggle(
    checked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val r by animateDpAsState(
        if (checked) 28.dp else 14.dp,
        spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "pillCorner",
    )
    FilledTonalIconToggleButton(
        checked = checked,
        onCheckedChange = { onClick() },
        modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(r),
        content = content,
    )
}

/** Wellenförmiger Zeitstrahl (Material 3 Expressive). Antippen oder ziehen zum Spulen. */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun SeekBar(
    progress: Float,
    playing: Boolean,
    onSeek: (Float) -> Unit,
) {
    var width by remember { mutableIntStateOf(0) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier
            .fillMaxWidth()
            .height(40.dp)
            .onSizeChanged { width = it.width }
            .pointerInput(Unit) {
                detectTapGestures { off ->
                    if (width > 0) onSeek((off.x / width).coerceIn(0f, 1f))
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { off -> if (width > 0) drag = (off.x / width).coerceIn(0f, 1f) },
                    onDragEnd = { drag?.let(onSeek); drag = null },
                    onDragCancel = { drag = null },
                ) { change, amount ->
                    change.consume()
                    if (width > 0) drag = ((drag ?: 0f) + amount / width).coerceIn(0f, 1f)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        LinearWavyProgressIndicator(
            progress = { drag ?: progress },
            modifier = Modifier.fillMaxWidth(),
            color = cs.primary,
            trackColor = cs.primary.copy(alpha = 0.25f),
            amplitude = { if (playing) 1f else 0f },
        )
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun LyricsContent(
    lyrics: LyricsUi,
    positionFlow: StateFlow<Long>,
    onSeekMs: (Long) -> Unit,
) {
    val position by positionFlow.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier.fillMaxWidth().fillMaxHeight(0.85f),
        contentAlignment = Alignment.Center,
    ) {
        when {
            lyrics.loading -> LoadingIndicator()

            lyrics.lines.isNotEmpty() -> {
                val listState = rememberLazyListState()
                val idx = lyrics.lines.indexOfLast { it.timeMs <= position + 250 }
                LaunchedEffect(idx) {
                    if (idx >= 0) {
                        listState.animateScrollToItem(idx, -(listState.layoutInfo.viewportSize.height / 3))
                    }
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 48.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                ) {
                    itemsIndexed(lyrics.lines) { i, line ->
                        val active = i == idx
                        val color by animateColorAsState(
                            if (active) cs.onSurface else cs.onSurfaceVariant.copy(alpha = 0.5f),
                            label = "lyricColor",
                        )
                        Text(
                            line.text.ifBlank { "♪" },
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = color,
                            modifier = Modifier.fillMaxWidth().clickable { onSeekMs(line.timeMs) },
                        )
                    }
                }
            }

            lyrics.plain != null -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            ) {
                Text(
                    lyrics.plain,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Medium,
                )
            }

            lyrics.instrumental -> LyricsMessage("Instrumental – kein Text vorhanden")
            lyrics.error -> LyricsMessage("Keine Internetverbindung. Der Songtext wird im Hintergrund erneut geladen.")
            else -> LyricsMessage("Kein Songtext gefunden")
        }
    }
}

@Composable
private fun LyricsMessage(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(32.dp),
    )
}
