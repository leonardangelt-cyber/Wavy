package app.wavy.player.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.LongState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import app.wavy.player.PlayerUi
import app.wavy.player.data.LyricsUi
import app.wavy.player.data.Song
import kotlin.math.PI
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    song: Song,
    state: PlayerUi,
    positionMs: LongState,
    lyrics: LyricsUi,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeekFraction: (Float) -> Unit,
    onSeekMs: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
) {
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val duration = if (state.durationMs > 0) state.durationMs else song.durationMs

    val corner by animateDpAsState(
        if (state.isPlaying) 56.dp else 32.dp,
        spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "coverCorner",
    )
    val scale by animateFloatAsState(
        if (state.isPlaying) 1f else 0.92f,
        spring(dampingRatio = 0.55f, stiffness = 300f),
        label = "coverScale",
    )
    val playCorner by animateDpAsState(
        if (state.isPlaying) 28.dp else 42.dp,
        spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "playCorner",
    )

    // Komplett deckender Hintergrund (nichts schimmert durch), Touches werden hier abgefangen.
    Box(
        Modifier
            .fillMaxSize()
            .background(cs.surface)
            .background(
                Brush.verticalGradient(
                    0f to cs.primaryContainer,
                    0.65f to cs.surface,
                    1f to cs.surface,
                ),
            )
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Schließen", Modifier.size(32.dp)) }
                Text(
                    "Wird abgespielt",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.size(48.dp))
            }
            Spacer(Modifier.height(16.dp))

            Cover(
                song = song,
                px = 900,
                modifier = Modifier
                    .widthIn(max = 420.dp)
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    },
                shape = RoundedCornerShape(corner),
            )
            Spacer(Modifier.height(28.dp))

            Column(Modifier.fillMaxWidth()) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = cs.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song.artistLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(12.dp))

            SeekSection(
                positionMs = positionMs,
                durationMs = duration,
                playing = state.isPlaying,
                onSeek = onSeekFraction,
            )
            Spacer(Modifier.height(12.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TransportButton(
                    onClick = onPrev,
                    modifier = Modifier.weight(1f).height(84.dp),
                    shape = CircleShape,
                    filled = false,
                ) { Icon(Icons.Rounded.SkipPrevious, "Zurück", Modifier.size(36.dp)) }
                TransportButton(
                    onClick = onToggle,
                    modifier = Modifier.weight(1.7f).height(84.dp),
                    shape = RoundedCornerShape(playCorner),
                    filled = true,
                ) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (state.isPlaying) "Pause" else "Abspielen",
                        Modifier.size(44.dp),
                    )
                }
                TransportButton(
                    onClick = onNext,
                    modifier = Modifier.weight(1f).height(84.dp),
                    shape = CircleShape,
                    filled = false,
                ) { Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(36.dp)) }
            }
            Spacer(Modifier.height(16.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillToggle(checked = state.shuffle, onToggle = onShuffle, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Shuffle, "Shuffle")
                }
                PillToggle(
                    checked = state.repeat != Player.REPEAT_MODE_OFF,
                    onToggle = onRepeat,
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(
                        if (state.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        when (state.repeat) {
                            Player.REPEAT_MODE_ONE -> "Einmal wiederholen"
                            Player.REPEAT_MODE_ALL -> "Alles wiederholen"
                            else -> "Wiederholung aus"
                        },
                    )
                }
                PillToggle(checked = showLyrics, onToggle = { showLyrics = !showLyrics }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Lyrics, "Songtext")
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showLyrics) {
        ModalBottomSheet(
            onDismissRequest = { showLyrics = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = cs.surfaceContainerHigh,
            contentColor = cs.onSurface,
        ) {
            LyricsContent(lyrics, positionMs, onSeekMs)
        }
    }
}

@Composable
private fun TransportButton(
    onClick: () -> Unit,
    modifier: Modifier,
    shape: Shape,
    filled: Boolean,
    content: @Composable () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val m = modifier.pressScale(src, 0.92f)
    if (filled) {
        FilledIconButton(onClick = onClick, modifier = m, shape = shape, interactionSource = src) { content() }
    } else {
        FilledTonalIconButton(onClick = onClick, modifier = m, shape = shape, interactionSource = src) { content() }
    }
}

@Composable
private fun PillToggle(
    checked: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val r by animateDpAsState(
        if (checked) 28.dp else 16.dp,
        spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "pillCorner",
    )
    FilledTonalIconToggleButton(
        checked = checked,
        onCheckedChange = { onToggle() },
        modifier = modifier.height(56.dp).pressScale(src, 0.92f),
        shape = RoundedCornerShape(r),
        colors = IconButtonDefaults.filledTonalIconToggleButtonColors(
            checkedContainerColor = cs.primary,
            checkedContentColor = cs.onPrimary,
        ),
        interactionSource = src,
    ) { content() }
}

@Composable
private fun TimeText(ms: () -> Long, style: TextStyle = MaterialTheme.typography.labelLarge) {
    val current by rememberUpdatedState(ms)
    val sec by remember { derivedStateOf { current() / 1000 } }
    Text(formatTime(sec * 1000), style = style, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Zeitstrahl mit Welle, Punkt (Griff) und Zeiten. Antippen oder Ziehen zum Spulen. */
@Composable
private fun SeekSection(
    positionMs: LongState,
    durationMs: Long,
    playing: Boolean,
    onSeek: (Float) -> Unit,
) {
    var width by remember { mutableIntStateOf(0) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val seek by rememberUpdatedState(onSeek)
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .onSizeChanged { width = it.width }
            .pointerInput(Unit) {
                awaitEachGesture {
                    fun frac(x: Float) = if (width > 0) (x / width).coerceIn(0f, 1f) else 0f
                    val down = awaitFirstDown()
                    drag = frac(down.position.x)
                    down.consume()
                    do {
                        val event = awaitPointerEvent()
                        val c = event.changes.firstOrNull() ?: break
                        if (c.pressed) {
                            drag = frac(c.position.x)
                            c.consume()
                        }
                    } while (event.changes.any { it.pressed })
                    drag?.let { seek(it) }
                    drag = null
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        WavyProgress(
            progress = {
                drag ?: if (durationMs > 0) (positionMs.longValue.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
            },
            playing = playing,
            dragging = drag != null,
            color = cs.primary,
            trackColor = cs.primary.copy(alpha = 0.25f),
            modifier = Modifier.fillMaxWidth(),
        )
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        TimeText(ms = { drag?.let { (it * durationMs).toLong() } ?: positionMs.longValue })
        Text(
            formatTime(durationMs),
            style = MaterialTheme.typography.labelLarge,
            color = cs.onSurfaceVariant,
        )
    }
}

/** Selbst gezeichneter Wellen-Zeitstrahl mit Griff. Alles Animierte wird erst beim Zeichnen gelesen. */
@Composable
private fun WavyProgress(
    progress: () -> Float,
    playing: Boolean,
    dragging: Boolean,
    color: Color,
    trackColor: Color,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart),
        label = "phase",
    )
    val amp by animateFloatAsState(
        if (playing && !dragging) 1f else 0f,
        spring(dampingRatio = 0.6f, stiffness = 200f),
        label = "amp",
    )
    val handleH by animateFloatAsState(
        if (dragging) 40f else 30f,
        spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "handle",
    )
    Canvas(modifier.height(44.dp)) {
        val w = size.width
        val cy = size.height / 2
        val stroke = 4.dp.toPx()
        val ampPx = 5.dp.toPx() * amp
        val wave = 28.dp.toPx()
        val hw = 5.dp.toPx()
        val hh = handleH.dp.toPx()
        val gap = 6.dp.toPx()
        val x = (w * progress().coerceIn(0f, 1f)).coerceIn(hw, w - hw)

        if (x + gap < w) {
            drawLine(trackColor, Offset(x + gap, cy), Offset(w, cy), stroke, StrokeCap.Round)
        }
        val end = x - gap
        if (end > 0f) {
            val path = Path()
            val step = 2.dp.toPx()
            val fadeLen = 12.dp.toPx()
            var px = 0f
            path.moveTo(0f, cy)
            while (px < end) {
                val fade = (px / fadeLen).coerceIn(0f, 1f)
                path.lineTo(px, cy + ampPx * fade * sin(px / wave * 2f * PI.toFloat() - phase))
                px += step
            }
            path.lineTo(end, cy + ampPx * sin(end / wave * 2f * PI.toFloat() - phase))
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        drawRoundRect(
            color,
            topLeft = Offset(x - hw / 2, cy - hh / 2),
            size = Size(hw, hh),
            cornerRadius = CornerRadius(hw / 2, hw / 2),
        )
    }
}

@Composable
private fun LyricsContent(
    lyrics: LyricsUi,
    positionMs: LongState,
    onSeekMs: (Long) -> Unit,
) {
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier.fillMaxWidth().fillMaxHeight(0.85f),
        contentAlignment = Alignment.Center,
    ) {
        when {
            lyrics.loading -> CircularProgressIndicator()

            lyrics.lines.isNotEmpty() -> {
                val listState = rememberLazyListState()
                val idx by remember(lyrics.lines) {
                    derivedStateOf {
                        val p = positionMs.longValue + 200
                        lyrics.lines.indexOfLast { it.timeMs <= p }
                    }
                }
                // Weiches Mitscrollen: die aktive Zeile gleitet auf ein Drittel der Höhe
                LaunchedEffect(idx) {
                    if (idx < 0) return@LaunchedEffect
                    val info = listState.layoutInfo
                    val target = info.viewportSize.height * 0.30f
                    val item = info.visibleItemsInfo.firstOrNull { it.index == idx }
                    if (item == null) {
                        listState.scrollToItem(idx)
                    } else {
                        listState.animateScrollBy(
                            item.offset - target,
                            spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessVeryLow),
                        )
                    }
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    itemsIndexed(lyrics.lines) { i, line ->
                        val active = i == idx
                        val a by animateFloatAsState(
                            if (active) 1f else 0.4f,
                            spring(stiffness = Spring.StiffnessLow),
                            label = "lyricAlpha",
                        )
                        val sc by animateFloatAsState(
                            if (active) 1f else 0.9f,
                            spring(stiffness = Spring.StiffnessLow),
                            label = "lyricScale",
                        )
                        Text(
                            line.text.ifBlank { "♪" },
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = cs.onSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .graphicsLayer {
                                    alpha = a
                                    scaleX = sc
                                    scaleY = sc
                                    transformOrigin = TransformOrigin(0f, 0.5f)
                                }
                                .clickable { onSeekMs(line.timeMs) },
                        )
                    }
                }
            }

            lyrics.plain != null -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            ) {
                Text(
                    lyrics.plain,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Medium,
                    color = cs.onSurface,
                )
            }

            lyrics.instrumental -> LyricsMessage("Instrumental – kein Text vorhanden")
            lyrics.error -> LyricsMessage("Keine Internetverbindung. Der Songtext wird im Hintergrund erneut geladen.")
            else -> LyricsMessage("Kein Songtext gefunden")
        }
    }
}

@Composable
private fun LyricsMessage(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(32.dp),
    )
}
