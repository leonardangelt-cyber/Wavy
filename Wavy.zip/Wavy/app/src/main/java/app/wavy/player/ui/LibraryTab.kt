package app.wavy.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import app.wavy.player.MusicViewModel
import app.wavy.player.data.PlayStat
import app.wavy.player.data.Playlist
import app.wavy.player.data.Song
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

/**
 * Bibliothek-Tab: Kacheln -> Tippen -> die vier Cover fliegen an ihren Platz oben in der Liste (wie beim Mini-Player),
 * die Songliste blendet dabei ein. Beim Zurückgehen läuft alles rückwärts.
 */
@Composable
fun LibraryTab(
    vm: MusicViewModel,
    smart: List<SmartList>,
    playlists: List<Playlist>,
    songs: List<Song>,
    songsById: Map<Long, Song>,
    stats: Map<Long, PlayStat>,
    currentId: Long?,
    bottom: Dp,
    backEnabled: Boolean,
    openPlaylistId: Long?,
    onOpenPlaylistId: (Long?) -> Unit,
    openSmartKey: String?,
    onOpenSmartKey: (String?) -> Unit,
    onMore: (Song) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val open = openPlaylistId != null || openSmartKey != null
    val prog = remember { Animatable(if (open) 1f else 0f) }
    var closing by remember { mutableStateOf(false) }
    var from by remember { mutableStateOf(Rect.Zero) }
    val header = remember { arrayOf(Rect.Zero) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    val settled by remember { derivedStateOf { prog.value >= 0.999f } }

    val pl = playlists.firstOrNull { it.id == openPlaylistId }
    val sm = smart.firstOrNull { it.key == openSmartKey }
    val plSongs = remember(pl?.songIds, songsById) { pl?.songIds?.mapNotNull { songsById[it] } ?: emptyList() }
    val heroCovers = remember(plSongs, sm?.songs, stats) { topPlayed(sm?.songs ?: plSongs, stats) }

    fun openList(pid: Long?, key: String?, r: Rect) {
        from = r
        closing = false
        onOpenPlaylistId(pid)
        onOpenSmartKey(key)
        scope.launch {
            prog.snapTo(0f)
            prog.animateTo(1f, spring(dampingRatio = 0.9f, stiffness = 260f))
        }
    }

    fun close() {
        if (closing) return
        closing = true
        scope.launch {
            prog.animateTo(0f, tween(360, easing = FastOutSlowInEasing))
            onOpenPlaylistId(null)
            onOpenSmartKey(null)
            closing = false
        }
    }

    BackHandler(enabled = backEnabled && open) { close() }

    Box(Modifier.fillMaxSize().onGloballyPositioned { origin = it.positionInRoot() }) {
        PlaylistsScreen(
            smart = smart,
            stats = stats,
            onOpenSmart = { k, r -> openList(null, k, r) },
            onCreateAi = { req, done -> vm.createAiPlaylist(req, done) },
            playlists = playlists,
            songsById = songsById,
            bottomPad = bottom,
            onOpen = { id, r -> openList(id, null, r) },
            onCreate = {
                val id = vm.createPlaylist(it)
                closing = false
                onOpenPlaylistId(id)
                scope.launch { prog.snapTo(1f) }
            },
        )

        if (open) {
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = ((prog.value - 0.2f) / 0.55f).coerceIn(0f, 1f) }
                    .background(MaterialTheme.colorScheme.background)
                    .pointerInput(Unit) { detectTapGestures { } },
            ) {
                val heroActive = settled && !closing
                if (sm != null) {
                    SmartListScreen(
                        list = sm,
                        covers = heroCovers,
                        heroActive = heroActive,
                        onHeaderRect = { header[0] = it },
                        currentId = currentId,
                        bottomPad = bottom,
                        onBack = { close() },
                        onPlay = { shuffle -> vm.playPlaylist(sm.songs, shuffle) },
                        onSongClick = { sg -> vm.playPlaylistSong(sm.songs, sg) },
                        onMore = onMore,
                    )
                } else if (pl != null) {
                    PlaylistDetailScreen(
                        playlist = pl,
                        songs = plSongs,
                        allSongs = songs,
                        currentId = currentId,
                        bottomPad = bottom,
                        onBack = { close() },
                        onPlay = { shuffle -> vm.playPlaylist(plSongs, shuffle) },
                        onSongClick = { s -> vm.playPlaylistSong(plSongs, s) },
                        onToggleSong = { sid -> vm.toggleSong(pl.id, sid) },
                        onToggleExclude = { vm.setExclude(pl.id, it) },
                        onToggleHide = { vm.setHide(pl.id, it) },
                        onRename = { vm.renamePlaylist(pl.id, it) },
                        onDelete = {
                            val id = pl.id
                            onOpenPlaylistId(null)
                            vm.deletePlaylist(id)
                        },
                        covers = heroCovers,
                        heroActive = heroActive,
                        onHeaderRect = { header[0] = it },
                    )
                }
            }

            // Fliegende Collage zwischen Kachel und Kopfbereich
            if (!heroActive(settled, closing)) {
                Box(
                    Modifier
                        .offset2 {
                            val to = if (header[0] == Rect.Zero) from else header[0]
                            val r = lerp(from, to, prog.value)
                            IntOffset((r.left - origin.x).roundToInt(), (r.top - origin.y).roundToInt())
                        }
                        .layout { m, _ ->
                            val to = if (header[0] == Rect.Zero) from else header[0]
                            val r = lerp(from, to, prog.value)
                            val w = r.width.roundToInt().coerceAtLeast(1)
                            val h = r.height.roundToInt().coerceAtLeast(1)
                            val p = m.measure(Constraints.fixed(w, h))
                            layout(w, h) { p.place(0, 0) }
                        }
                        .clip(RoundedCornerShape(28.dp)),
                ) {
                    CoverCollage(heroCovers, Modifier.fillMaxSize())
                }
            }
        }
    }
}

private fun heroActive(settled: Boolean, closing: Boolean) = settled && !closing

private fun Modifier.offset2(block: androidx.compose.ui.unit.Density.() -> IntOffset): Modifier =
    this.offset(block)
