package app.wavy.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

/**
 * Holt Songtexte im Hintergrund von LRCLIB (https://lrclib.net, kostenlos, kein Key nötig)
 * und speichert sie lokal, damit sie danach auch offline da sind.
 */
class LyricsRepository(ctx: Context) {

    private val dir = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    private sealed interface Fetch {
        data class Found(val json: JSONObject) : Fetch
        data object NotFound : Fetch
        data object Error : Fetch
    }

    suspend fun get(song: Song): LyricsUi = withContext(Dispatchers.IO) {
        val f = File(dir, "${song.id}.json")
        try {
            if (f.exists()) {
                val o = JSONObject(f.readText())
                val fresh = System.currentTimeMillis() - o.optLong("t") < NOT_FOUND_TTL
                if (o.optBoolean("found") || fresh) return@withContext fromJson(o)
            }
        } catch (_: Exception) {
        }
        when (val r = fetch(song)) {
            is Fetch.Error -> LyricsUi(error = true)
            is Fetch.NotFound -> {
                save(f, JSONObject().put("t", System.currentTimeMillis()).put("found", false))
                LyricsUi(notFound = true)
            }
            is Fetch.Found -> {
                val o = r.json.put("t", System.currentTimeMillis()).put("found", true)
                save(f, o)
                fromJson(o)
            }
        }
    }

    /** Vom Nutzer aus dem Web übernommener Text (ersetzt "nicht gefunden"). */
    suspend fun saveCustom(song: Song, text: String): LyricsUi = withContext(Dispatchers.IO) {
        val o = JSONObject().put("t", System.currentTimeMillis()).put("found", true)
            .put("plain", text).put("synced", "").put("instr", false)
        save(File(dir, "${song.id}.json"), o)
        fromJson(o)
    }

    private fun save(f: File, o: JSONObject) {
        try { f.writeText(o.toString()) } catch (_: Exception) {}
    }

    private fun fromJson(o: JSONObject): LyricsUi {
        if (!o.optBoolean("found")) return LyricsUi(notFound = true)
        val plain = o.optString("plain", "").ifBlank { null }
        val synced = o.optString("synced", "")
        val lines = if (synced.isNotBlank()) parseLrc(synced) else emptyList()
        val instr = o.optBoolean("instr")
        if (plain == null && lines.isEmpty() && !instr) return LyricsUi(notFound = true)
        return LyricsUi(plain = plain, lines = lines, instrumental = instr)
    }

    private fun fetch(song: Song): Fetch {
        var title = cleanTitle(song.title)
        var artist = song.artist.trim()
        if (artist.isBlank() && " - " in title) {
            artist = title.substringBefore(" - ").trim()
            title = title.substringAfter(" - ").trim()
        }
        val targetSec = song.durationMs / 1000
        var networkError = false

        if (artist.isNotBlank()) {
            val url = "$BASE/get?track_name=${enc(title)}&artist_name=${enc(artist)}" +
                (if (song.album.isNotBlank()) "&album_name=${enc(song.album)}" else "") +
                (if (targetSec > 0) "&duration=$targetSec" else "")
            val (code, body) = http(url)
            if (code == 200 && body != null) {
                try { return Fetch.Found(toStored(JSONObject(body))) } catch (_: Exception) {}
            } else if (code == -1) networkError = true
        }

        val q = "$BASE/search?track_name=${enc(title)}" + if (artist.isNotBlank()) "&artist_name=${enc(artist)}" else ""
        val (code, body) = http(q)
        if (code == -1) networkError = true
        if (code == 200 && body != null) {
            try {
                val arr = JSONArray(body)
                var best: JSONObject? = null
                var bestScore = Double.MAX_VALUE
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val hasText = !o.isNull("syncedLyrics") || !o.isNull("plainLyrics") || o.optBoolean("instrumental")
                    if (!hasText) continue
                    val d = abs(o.optDouble("duration", 0.0) - targetSec)
                    if (targetSec > 0 && d > 10) continue
                    val score = d - (if (!o.isNull("syncedLyrics")) 3 else 0)
                    if (score < bestScore) { bestScore = score; best = o }
                }
                if (best != null) return Fetch.Found(toStored(best))
            } catch (_: Exception) {}
        }
        return if (networkError) Fetch.Error else Fetch.NotFound
    }

    private fun toStored(o: JSONObject): JSONObject = JSONObject()
        .put("plain", if (o.isNull("plainLyrics")) "" else o.optString("plainLyrics"))
        .put("synced", if (o.isNull("syncedLyrics")) "" else o.optString("syncedLyrics"))
        .put("instr", o.optBoolean("instrumental"))

    private fun http(url: String): Pair<Int, String?> {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Wavy/1.0 (Android music player)")
            val code = c.responseCode
            if (code == 200) code to c.inputStream.bufferedReader().use { it.readText() } else code to null
        } catch (_: Exception) {
            -1 to null
        } finally {
            c?.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun cleanTitle(t: String): String = t.replace(
        Regex("""\s*[(\[][^)\]]*(official|lyric|video|audio|visualizer|hd|4k|remaster)[^)\]]*[)\]]""", RegexOption.IGNORE_CASE),
        "",
    ).trim()

    companion object {
        private const val BASE = "https://lrclib.net/api"
        private const val NOT_FOUND_TTL = 7L * 24 * 60 * 60 * 1000

        private val timeRegex = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")

        fun parseLrc(s: String): List<LrcLine> {
            val out = ArrayList<LrcLine>()
            for (line in s.lines()) {
                val ms = timeRegex.findAll(line).toList()
                if (ms.isEmpty()) continue
                val text = line.substring(ms.last().range.last + 1).trim()
                for (m in ms) {
                    val min = m.groupValues[1].toLong()
                    val sec = m.groupValues[2].toLong()
                    val frac = m.groupValues[3]
                    val fracMs = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                    out += LrcLine((min * 60 + sec) * 1000 + fracMs, text)
                }
            }
            return out.sortedBy { it.timeMs }
        }
    }
}
