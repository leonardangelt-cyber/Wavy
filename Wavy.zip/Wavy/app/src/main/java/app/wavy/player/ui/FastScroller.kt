package app.wavy.player.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Scroll-Leiste am rechten Rand: Griff ziehen, um schnell durch die Liste zu springen. Zeigt den Anfangsbuchstaben. */
@Composable
fun FastScroller(
    state: LazyListState,
    modifier: Modifier = Modifier,
    label: (Int) -> String,
) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val total by remember { derivedStateOf { state.layoutInfo.totalItemsCount } }
    var h by remember { mutableIntStateOf(0) }
    var dragFrac by remember { mutableStateOf<Float?>(null) }
    var idx by remember { mutableIntStateOf(0) }
    val dragging = dragFrac != null
    val alpha by animateFloatAsState(if (dragging || state.isScrollInProgress) 1f else 0.35f, label = "fsAlpha")
    if (total < 15) return

    Box(
        modifier
            .width(40.dp)
            .fillMaxHeight()
            .onSizeChanged { h = it.height }
            .pointerInput(Unit) {
                val thumb = 52.dp.toPx()
                fun jump(y: Float) {
                    val usable = (h - thumb).coerceAtLeast(1f)
                    val f = ((y - thumb / 2) / usable).coerceIn(0f, 1f)
                    dragFrac = f
                    val i = (f * (total - 1)).roundToInt().coerceIn(0, total - 1)
                    idx = i
                    scope.launch { state.scrollToItem(i) }
                }
                detectVerticalDragGestures(
                    onDragStart = { jump(it.y) },
                    onDragEnd = { dragFrac = null },
                    onDragCancel = { dragFrac = null },
                ) { change, _ ->
                    jump(change.position.y)
                    change.consume()
                }
            },
    ) {
        fun frac(): Float {
            dragFrac?.let { return it }
            val visible = state.layoutInfo.visibleItemsInfo.size
            val maxFirst = (total - visible).coerceAtLeast(1)
            return (state.firstVisibleItemIndex / maxFirst.toFloat()).coerceIn(0f, 1f)
        }
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .offset {
                    val thumb = 52.dp.roundToPx()
                    IntOffset(0, (frac() * (h - thumb).coerceAtLeast(0)).roundToInt())
                }
                .padding(end = 4.dp)
                .width(6.dp)
                .height(52.dp)
                .clip(CircleShape)
                .background(cs.primary.copy(alpha = alpha)),
        )
        if (dragging) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset {
                        val thumb = 52.dp.roundToPx()
                        IntOffset(-48.dp.roundToPx(), (frac() * (h - thumb).coerceAtLeast(0)).roundToInt())
                    }
                    .width(52.dp)
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(cs.primary),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label(idx),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = cs.onPrimary,
                )
            }
        }
    }
}
