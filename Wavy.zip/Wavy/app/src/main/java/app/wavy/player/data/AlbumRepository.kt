package app.wavy.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class AlbumTrack(val disc: Int, val number: Int, val title: String, val durationMs: Long)

/** Titel für Abgleich: klein, ohne Klammern (feat., Remastered …) und Satzzeichen. */
fun normTitle(s: String): String = s.lowercase(Locale.ROOT)
    .replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
    .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
    .trim()

/**
 * Holt die komplette Titelliste eines Albums aus der öffentlichen iTunes-Suche (ohne Schlüssel)
 * und merkt sie sich auf dem Gerät. So kann Wavy auch die Songs zeigen, die du nicht hast.
 */
class AlbumRepository(ctx: Context) {
    private val dir = File(ctx.filesDir, "albums").apply { mkdirs() }

    private fun file(artist: String, album: String) =
        File(dir, (artist.lowercase(Locale.ROOT) + "|" + album.lowercase(Locale.ROOT)).hashCode().toString(16) + ".json")

    private fun read(f: File): List<AlbumTrack>? = try {
        val a = JSONArray(f.readText())
        List(a.length()) {
            val o = a.getJSONObject(it)
            AlbumTrack(o.getInt("d"), o.getInt("n"), o.getString("t"), o.getLong("ms"))
        }
    } catch (_: Exception) {
        null
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "Wavy/1.0")
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** null = nicht erreichbar, leere Liste = Album nicht gefunden. */
    suspend fun get(artist: String, album: String): List<AlbumTrack>? = withContext(Dispatchers.IO) {
        val f = file(artist, album)
        if (f.exists()) read(f)?.let { return@withContext it }
        try {
            val term = URLEncoder.encode("$artist $album", "UTF-8")
            val res = JSONObject(get("https://itunes.apple.com/search?term=$term&entity=album&limit=15")).optJSONArray("results")
                ?: return@withContext emptyList()
            val nAlbum = normTitle(album)
            val nArtist = normTitle(artist)
            val anyArtist = nArtist.isBlank() || nArtist.contains("unbekannt") || nArtist.contains("various")
            var bestId = -1L
            var bestScore = 0
            for (i in 0 until res.length()) {
                val o = res.getJSONObject(i)
                val name = normTitle(o.optString("collectionName"))
                val art = normTitle(o.optString("artistName"))
                var score = when {
                    name == nAlbum -> 4
                    name.isNotBlank() && (name.contains(nAlbum) || nAlbum.contains(name)) -> 2
                    else -> 0
                }
                if (score == 0) continue
                score += when {
                    anyArtist -> 1
                    art == nArtist -> 3
                    art.contains(nArtist) || nArtist.contains(art) -> 2
                    else -> -10
                }
                if (score > bestScore) {
                    bestScore = score
                    bestId = o.optLong("collectionId", -1L)
                }
            }
            if (bestId < 0 || bestScore < 3) return@withContext emptyList()
            val look = JSONObject(get("https://itunes.apple.com/lookup?id=$bestId&entity=song&limit=200")).optJSONArray("results")
                ?: return@withContext emptyList()
            val tracks = ArrayList<AlbumTrack>()
            for (i in 0 until look.length()) {
                val o = look.getJSONObject(i)
                if (o.optString("wrapperType") != "track") continue
                tracks += AlbumTrack(
                    o.optInt("discNumber", 1),
                    o.optInt("trackNumber", i),
                    o.optString("trackName"),
                    o.optLong("trackTimeMillis", 0L),
                )
            }
            val sorted = tracks.filter { it.title.isNotBlank() }.sortedWith(compareBy({ it.disc }, { it.number }))
            if (sorted.isNotEmpty()) {
                try {
                    val arr = JSONArray()
                    sorted.forEach {
                        arr.put(JSONObject().put("d", it.disc).put("n", it.number).put("t", it.title).put("ms", it.durationMs))
                    }
                    f.writeText(arr.toString())
                } catch (_: Exception) {
                }
            }
            sorted
        } catch (_: Exception) {
            null
        }
    }
}
