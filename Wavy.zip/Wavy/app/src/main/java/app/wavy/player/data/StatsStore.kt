package app.wavy.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File

data class PlayStat(val count: Int, val lastMs: Long)

/** Merkt sich, wie oft und wann ein Song zuletzt gespielt wurde (für automatische Listen). */
class StatsStore(ctx: Context) {
    private val file = File(ctx.filesDir, "stats.json")
    private val _stats = MutableStateFlow(load())
    val stats: StateFlow<Map<Long, PlayStat>> = _stats.asStateFlow()

    private fun load(): Map<Long, PlayStat> = try {
        val o = JSONObject(file.readText())
        buildMap {
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                put(k.toLong(), PlayStat(a.getInt(0), a.getLong(1)))
            }
        }
    } catch (_: Exception) {
        emptyMap()
    }

    fun record(id: Long) {
        val cur = _stats.value[id]
        val next = _stats.value + (id to PlayStat((cur?.count ?: 0) + 1, System.currentTimeMillis()))
        _stats.value = next
        try {
            val o = JSONObject()
            next.forEach { (k, v) -> o.put(k.toString(), org.json.JSONArray().put(v.count).put(v.lastMs)) }
            file.writeText(o.toString())
        } catch (_: Exception) {
        }
    }
}
