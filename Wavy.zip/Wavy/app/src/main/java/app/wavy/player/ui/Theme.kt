package app.wavy.player.ui

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.ColorUtils
import app.wavy.player.data.Song

/** App-Theme: Material You (dynamische Farben). Der Surface sorgt dafür, dass Text immer die richtige Farbe hat. */
@Composable
fun WavyTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = scheme.background,
            contentColor = scheme.onBackground,
            content = content,
        )
    }
}

internal fun tone(h: Float, s: Float, l: Float): Color =
    Color(ColorUtils.HSLToColor(floatArrayOf(h, s.coerceIn(0f, 1f), l.coerceIn(0f, 1f))))

/** Gibt [fg] zurück, wenn es auf [bg] gut lesbar ist (Kontrast >= 4.5), sonst Weiß oder Schwarz. */
fun readable(bg: Color, fg: Color): Color {
    val b = bg.copy(alpha = 1f).toArgb()
    if (ColorUtils.calculateContrast(fg.copy(alpha = 1f).toArgb(), b) >= 4.5) return fg
    val white = ColorUtils.calculateContrast(Color.White.toArgb(), b)
    val black = ColorUtils.calculateContrast(Color(0xFF101010).toArgb(), b)
    return if (white >= black) Color.White else Color(0xFF101010)
}

/** Bunte Akzentfarben für Listen, Karten und die Startseite. */
object Vivid {
    private val hues = floatArrayOf(350f, 22f, 42f, 140f, 172f, 205f, 250f, 285f, 320f)
    private fun h(key: Long) = hues[(key % hues.size).toInt().coerceAtLeast(0)]

    fun container(key: Long, dark: Boolean): Color =
        if (dark) tone(h(key), 0.50f, 0.20f) else tone(h(key), 0.90f, 0.89f)

    fun onContainer(key: Long, dark: Boolean): Color =
        if (dark) tone(h(key), 0.85f, 0.90f) else tone(h(key), 0.90f, 0.14f)

    fun strong(key: Long, dark: Boolean): Color =
        if (dark) tone(h(key), 0.80f, 0.68f) else tone(h(key), 0.75f, 0.40f)
}

fun songKey(song: Song): Long = song.title.hashCode().toLong() and 0x7fffffffL

/**
 * Baut aus der Cover-Palette ein komplettes Farbschema (hell/dunkel) mit garantiert lesbarem Text:
 * Hintergründe und Container kommen aus der Hauptfarbe, Knöpfe/Balken/Hervorhebungen aus der Akzentfarbe.
 */
private fun schemeFromSeed(p: CoverPalette, dark: Boolean, base: ColorScheme): ColorScheme {
    val t = FloatArray(3)
    ColorUtils.colorToHSL(p.tint, t)
    val a = FloatArray(3)
    ColorUtils.colorToHSL(p.accent, a)
    val h = t[0]
    val ha = a[0]
    // Farbige Cover behalten ihre Sättigung, fast graue Cover bekommen ein neutrales Schema
    val s = if (t[1] < 0.12f) 0.08f else t[1].coerceIn(0.35f, 0.92f)
    val sa = if (a[1] < 0.12f) 0.08f else a[1].coerceIn(0.5f, 0.95f)
    val k = (t[1] / 0.30f).coerceIn(0.12f, 1f)
    val sch = if (dark) {
        base.copy(
            primary = tone(ha, sa, 0.78f),
            onPrimary = tone(ha, sa, 0.14f),
            primaryContainer = tone(h, s, 0.30f),
            onPrimaryContainer = tone(h, s, 0.90f),
            secondary = tone(ha, sa * 0.55f, 0.78f),
            onSecondary = tone(ha, sa * 0.5f, 0.14f),
            secondaryContainer = tone(ha, sa * 0.45f, 0.27f),
            onSecondaryContainer = tone(ha, sa * 0.5f, 0.90f),
            tertiary = tone((ha + 60f) % 360f, sa * 0.6f, 0.78f),
            background = tone(h, 0.22f * k, 0.08f),
            surface = tone(h, 0.22f * k, 0.08f),
            onSurface = tone(h, 0.10f * k, 0.92f),
            onSurfaceVariant = tone(h, 0.15f * k, 0.78f),
            surfaceContainer = tone(h, 0.22f * k, 0.12f),
            surfaceContainerHigh = tone(h, 0.22f * k, 0.16f),
            surfaceContainerHighest = tone(h, 0.22f * k, 0.20f),
            outline = tone(h, 0.10f * k, 0.60f),
        )
    } else {
        base.copy(
            primary = tone(ha, sa, 0.38f),
            onPrimary = Color.White,
            primaryContainer = tone(h, s, 0.88f),
            onPrimaryContainer = tone(h, s, 0.12f),
            secondary = tone(ha, sa * 0.55f, 0.40f),
            onSecondary = Color.White,
            secondaryContainer = tone(ha, sa * 0.5f, 0.86f),
            onSecondaryContainer = tone(ha, sa * 0.5f, 0.12f),
            tertiary = tone((ha + 60f) % 360f, sa * 0.6f, 0.40f),
            background = tone(h, 0.40f * k, 0.97f),
            surface = tone(h, 0.40f * k, 0.97f),
            onSurface = tone(h, 0.10f * k, 0.10f),
            onSurfaceVariant = tone(h, 0.15f * k, 0.30f),
            surfaceContainer = tone(h, 0.35f * k, 0.93f),
            surfaceContainerHigh = tone(h, 0.35f * k, 0.90f),
            surfaceContainerHighest = tone(h, 0.35f * k, 0.87f),
            outline = tone(h, 0.10f * k, 0.50f),
        )
    }
    return sch.copy(
        onPrimary = readable(sch.primary, sch.onPrimary),
        onPrimaryContainer = readable(sch.primaryContainer, sch.onPrimaryContainer),
        onSecondary = readable(sch.secondary, sch.onSecondary),
        onSecondaryContainer = readable(sch.secondaryContainer, sch.onSecondaryContainer),
        onSurface = readable(sch.surface, sch.onSurface),
        onSurfaceVariant = readable(sch.surface, sch.onSurfaceVariant),
    )
}

@Composable
private fun animColor(target: Color): Color =
    animateColorAsState(target, tween<Color>(450), label = "coverColor").value

/** Alles in diesem Block nimmt die Farben des aktuellen Covers an. */
@Composable
fun PlayerTheme(seed: CoverPalette?, content: @Composable () -> Unit) {
    val base = MaterialTheme.colorScheme
    val dark = isSystemInDarkTheme()
    val target = remember(seed, dark, base) { if (seed == null) base else schemeFromSeed(seed, dark, base) }
    val scheme = target.copy(
        primary = animColor(target.primary),
        onPrimary = animColor(target.onPrimary),
        primaryContainer = animColor(target.primaryContainer),
        onPrimaryContainer = animColor(target.onPrimaryContainer),
        secondary = animColor(target.secondary),
        onSecondary = animColor(target.onSecondary),
        secondaryContainer = animColor(target.secondaryContainer),
        onSecondaryContainer = animColor(target.onSecondaryContainer),
        tertiary = animColor(target.tertiary),
        background = animColor(target.background),
        surface = animColor(target.surface),
        onSurface = animColor(target.onSurface),
        onSurfaceVariant = animColor(target.onSurfaceVariant),
        surfaceContainer = animColor(target.surfaceContainer),
        surfaceContainerHigh = animColor(target.surfaceContainerHigh),
        surfaceContainerHighest = animColor(target.surfaceContainerHighest),
        outline = animColor(target.outline),
    )
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalContentColor provides scheme.onSurface) {
            content()
        }
    }
}
