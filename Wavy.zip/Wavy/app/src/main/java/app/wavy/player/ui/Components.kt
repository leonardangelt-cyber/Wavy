package app.wavy.player.ui

import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.layout.height
import android.graphics.Bitmap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.wavy.player.data.CoverLoader
import app.wavy.player.data.Song
import kotlin.math.abs

fun formatTime(ms: Long): String {
    val s = (ms.coerceAtLeast(0L)) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

/** Verbundene, abgerundete Listenelemente. */
fun segShape(index: Int, count: Int): Shape {
    val big = 28.dp
    val small = 8.dp
    val first = index == 0
    val last = index == count - 1
    return RoundedCornerShape(
        topStart = if (first) big else small,
        topEnd = if (first) big else small,
        bottomStart = if (last) big else small,
        bottomEnd = if (last) big else small,
    )
}

/** Federndes Einsinken beim Drücken. Liest den Zustand erst beim Zeichnen, damit nichts neu komponiert wird. */
@Composable
fun Modifier.pressScale(source: MutableInteractionSource, pressed: Float = 0.93f): Modifier {
    val isPressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (isPressed) pressed else 1f,
        spring(dampingRatio = 0.5f, stiffness = 700f),
        label = "press",
    )
    return this.graphicsLayer {
        scaleX = s
        scaleY = s
    }
}

@Composable
fun Cover(
    song: Song?,
    px: Int,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    contentScale: ContentScale = ContentScale.Crop,
) {
    val ctx = LocalContext.current
    var bmp by remember(song?.id) { mutableStateOf<Bitmap?>(song?.let { CoverLoader.cached(it, px) }) }
    LaunchedEffect(song?.id) {
        if (song != null && bmp == null) bmp = CoverLoader.load(ctx, song, px)
    }
    Box(
        modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.secondaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        Crossfade(targetState = bmp, label = "cover") { b ->
            if (b != null) {
                val img: ImageBitmap = remember(b) { b.asImageBitmap() }
                Image(
                    bitmap = img,
                    contentDescription = null,
                    contentScale = contentScale,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Rounded.MusicNote,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f),
                        modifier = Modifier.fillMaxSize(0.45f),
                    )
                }
            }
        }
    }
}

/**
 * Großes Cover mit vollem Bild. Ist das Bild nicht quadratisch (z. B. Video-Vorschau), wird es komplett
 * gezeigt und die Balken links/rechts bzw. oben/unten füllt eine weichgezeichnete Version desselben Bildes.
 */
@Composable
fun CoverFramed(
    song: Song?,
    px: Int,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(10.dp),
) {
    val ctx = LocalContext.current
    var bmp by remember(song?.id) { mutableStateOf<Bitmap?>(song?.let { CoverLoader.cached(it, px) }) }
    LaunchedEffect(song?.id) {
        if (song != null && bmp == null) bmp = CoverLoader.load(ctx, song, px)
    }
    Box(
        modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.secondaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) {
            val img: ImageBitmap = remember(b) { b.asImageBitmap() }
            Image(
                bitmap = img,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(
                Icons.Rounded.MusicNote,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f),
                modifier = Modifier.fillMaxSize(0.45f),
            )
        }
    }
}

/** Bunte Songzeile. Die Farbe kommt vom Titel, der Text wird immer auf gute Lesbarkeit geprüft. */
@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
fun SongRow(
    song: Song,
    index: Int,
    count: Int,
    isCurrent: Boolean,
    note: String? = null,
    onClick: () -> Unit,
    onMore: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
) {
    val dark = isSystemInDarkTheme()
    val key = songKey(song)
    val seed = rememberCoverSeed(song)
    val containerTarget = when {
        seed != null && isCurrent -> CoverTone.strong(seed, dark)
        seed != null -> CoverTone.container(seed, dark)
        isCurrent -> Vivid.strong(key, dark)
        else -> Vivid.container(key, dark)
    }
    val container by animateColorAsState(containerTarget, tween(350), label = "rowColor")
    val content = readable(
        container,
        when {
            isCurrent -> Color.White
            seed != null -> CoverTone.onContainer(seed, dark)
            else -> Vivid.onContainer(key, dark)
        },
    )
    val src = remember { MutableInteractionSource() }
    val body: @Composable () -> Unit = {
        Row(
            Modifier.padding(start = 12.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Cover(song, 160, Modifier.size(54.dp), RoundedCornerShape(16.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = if (isCurrent) FontWeight.ExtraBold else FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song.artistLabel + (note?.let { " · $it" } ?: ""),
                    style = MaterialTheme.typography.bodyMedium,
                    color = content.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.width(8.dp))
            if (trailing != null) {
                trailing()
            } else {
                Text(
                    formatTime(song.durationMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = content.copy(alpha = 0.8f),
                )
                if (onMore != null) {
                    IconButton(onClick = onMore) { Icon(Icons.Rounded.MoreVert, "Mehr") }
                } else {
                    Spacer(Modifier.width(8.dp))
                }
            }
        }
    }
    val shape = segShape(index, count)
    if (onLongClick == null) {
        Surface(
            onClick = onClick,
            shape = shape,
            color = container,
            contentColor = content,
            interactionSource = src,
            modifier = Modifier.fillMaxWidth().pressScale(src, 0.97f),
        ) { body() }
    } else {
        Surface(
            shape = shape,
            color = container,
            contentColor = content,
            modifier = Modifier
                .fillMaxWidth()
                .pressScale(src, 0.97f)
                .clip(shape)
                .combinedClickable(
                    interactionSource = src,
                    indication = androidx.compose.foundation.LocalIndication.current,
                    onClick = onClick,
                    onLongClick = onLongClick,
                ),
        ) { body() }
    }
}

@Composable
fun EmptyState(
    title: String,
    text: String,
    modifier: Modifier = Modifier,
    buttonText: String? = null,
    onButton: (() -> Unit)? = null,
) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(96.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Rounded.MusicNote, null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(48.dp),
            )
        }
        Spacer(Modifier.size(20.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.size(8.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        if (buttonText != null && onButton != null) {
            Spacer(Modifier.size(24.dp))
            Button(onClick = onButton) { Text(buttonText) }
        }
    }
}

/** Zurück-Knopf im Expressive-Stil (weiches Rechteck statt nacktem Pfeil). */
@Composable
fun BackButton(onBack: () -> Unit, modifier: Modifier = Modifier) {
    androidx.compose.material3.FilledTonalIconButton(
        onClick = onBack,
        modifier = modifier.size(48.dp),
        shape = RoundedCornerShape(16.dp),
    ) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Zurück") }
}

/** Verbundene Tasten: Abspielen links, Shuffle rechts, innen kleine Ecken. */
val PlayShape = RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp, topEnd = 8.dp, bottomEnd = 8.dp)
val ShuffleShape = RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp, topEnd = 28.dp, bottomEnd = 28.dp)

/** Pop-up-Menü: große Rundung, weiche Fläche. */
@Composable
fun WavyMenu(expanded: Boolean, onDismiss: () -> Unit, content: @Composable () -> Unit) {
    androidx.compose.material3.DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 0.dp,
        shadowElevation = 8.dp,
        offset = androidx.compose.ui.unit.DpOffset(0.dp, 4.dp),
    ) {
        Column(Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) { content() }
    }
}

/** Eintrag im Pop-up-Menü: Symbol in weicher Kachel, Titel, optional Erklärung und Schalter. */
@Composable
fun WavyMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    summary: String? = null,
    danger: Boolean = false,
    checked: Boolean? = null,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = Color.Transparent,
        contentColor = if (danger) cs.error else cs.onSurface,
        modifier = Modifier.widthIn(min = 240.dp, max = 320.dp),
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (danger) cs.errorContainer else cs.primaryContainer),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, null, Modifier.size(22.dp), tint = if (danger) cs.onErrorContainer else cs.onPrimaryContainer) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f, fill = false)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                if (summary != null) {
                    Text(summary, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            if (checked != null) {
                Spacer(Modifier.width(10.dp))
                androidx.compose.material3.Switch(checked = checked, onCheckedChange = null)
            }
        }
    }
}

/** Dialog im Expressive-Stil: sehr runde Fläche, Symbol oben, gefüllter Bestätigungsknopf. */
@Composable
fun WavyDialog(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    confirm: String,
    confirmEnabled: Boolean = true,
    danger: Boolean = false,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    content: @Composable () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(36.dp),
        containerColor = cs.surfaceContainerHigh,
        icon = { Icon(icon, null, tint = if (danger) cs.error else cs.primary, modifier = Modifier.size(32.dp)) },
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = content,
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = confirmEnabled,
                shape = RoundedCornerShape(20.dp),
                colors = if (danger) androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = cs.error, contentColor = cs.onError)
                else androidx.compose.material3.ButtonDefaults.buttonColors(),
            ) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirm: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    WavyDialog(
        icon = Icons.Rounded.Edit,
        title = title,
        confirm = confirm,
        confirmEnabled = text.isNotBlank(),
        onDismiss = onDismiss,
        onConfirm = { onConfirm(text.trim()) },
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            label = { Text("Name") },
            shape = RoundedCornerShape(20.dp),
        )
    }
}

/** Kleiner Player über der Navigationsleiste (in Cover-Farben). */
@Composable
fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    Surface(
        onClick = onOpen,
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        interactionSource = src,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).pressScale(src, 0.98f),
    ) {
        Column {
            Row(
                Modifier.padding(start = 10.dp, end = 6.dp, top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Cover(song, 128, Modifier.size(48.dp), RoundedCornerShape(16.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        song.artistLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = LocalContentColor.current.copy(alpha = 0.8f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                FilledIconButton(onClick = onToggle) {
                    Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (isPlaying) "Pause" else "Abspielen")
                }
                IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Weiter") }
            }
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }
    }
}


/** Zu langer Text läuft von rechts nach links durch (einzeilig). */
fun Modifier.marq(): Modifier = this.basicMarquee(
    iterations = if (app.wavy.player.data.Perf.low) 1 else 3,
    initialDelayMillis = 1500,
    repeatDelayMillis = 1500,
    velocity = 32.dp,
)

/** Schlichter gerader Zeitstrahl (ohne Griff). Beim Ziehen wird er etwas dicker. */
@Composable
fun PillProgress(
    progress: () -> Float,
    playing: Boolean,
    dragging: Boolean,
    color: Color,
    trackColor: Color,
    trackHeight: androidx.compose.ui.unit.Dp,
    handleHeight: androidx.compose.ui.unit.Dp,
    playWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
) {
    val th by androidx.compose.animation.core.animateFloatAsState(
        if (dragging) trackHeight.value * 1.6f else trackHeight.value,
        androidx.compose.animation.core.spring(dampingRatio = 0.7f, stiffness = 500f),
        label = "barH",
    )
    androidx.compose.foundation.Canvas(modifier.height(handleHeight * 1.5f)) {
        val w = size.width
        val cy = size.height / 2f
        val h = th.dp.toPx()
        val r = androidx.compose.ui.geometry.CornerRadius(h / 2f, h / 2f)
        val x = w * progress().coerceIn(0f, 1f)
        drawRoundRect(trackColor, androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(w, h), r)
        if (x > 0f) {
            drawRoundRect(color, androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(maxOf(x, h), h), r)
        }
    }
}

/** Leichtes Vibrieren als Rückmeldung (abschaltbar in den Einstellungen). */
fun androidx.compose.ui.hapticfeedback.HapticFeedback.tick(
    type: androidx.compose.ui.hapticfeedback.HapticFeedbackType = androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove,
) {
    if (app.wavy.player.data.Perf.haptics) performHapticFeedback(type)
}
