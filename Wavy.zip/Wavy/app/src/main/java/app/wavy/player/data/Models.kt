package app.wavy.player.data

import android.net.Uri

data class Song(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val relativePath: String,
    val isVideo: Boolean,
    /** Hinzugefügt am (Sekunden seit 1970), 0 = unbekannt */
    val dateAdded: Long = 0L,
) {
    val artistLabel: String get() = artist.ifBlank { "Unbekannter Interpret" }
    val isDownload: Boolean get() = relativePath.startsWith("Download", ignoreCase = true)
}

data class Playlist(
    val id: Long,
    val name: String,
    /** true = Songs dieser Playlist werden auf dem Startbildschirm bei "Alle abspielen"/"Shuffle" übersprungen */
    val excludeFromHome: Boolean,
    val songIds: List<Long>,
    /** true = Songs dieser Playlist werden in der Bibliothek (Home) gar nicht angezeigt */
    val hideFromHome: Boolean = false,
)

data class LrcLine(val timeMs: Long, val text: String)

data class LyricsUi(
    val loading: Boolean = false,
    val plain: String? = null,
    val lines: List<LrcLine> = emptyList(),
    val instrumental: Boolean = false,
    val notFound: Boolean = false,
    val error: Boolean = false,
    val custom: Boolean = false,
)

enum class TranslationStatus { Idle, Loading, Done, Same, Error }

data class TranslationUi(
    val status: TranslationStatus = TranslationStatus.Idle,
    /** Originalzeile -> Übersetzung */
    val map: Map<String, String> = emptyMap(),
    val message: String? = null,
)
