package app.wavy.player.data

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat

object MediaRepository {

    fun hasPermission(ctx: Context): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    }

    /** Alle Audiodateien (mp3, m4a, ...) und MP4-Dateien auf dem Gerät. */
    fun loadSongs(ctx: Context): List<Song> {
        val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.TITLE,
            MediaStore.Audio.AudioColumns.ARTIST,
            MediaStore.Audio.AudioColumns.ALBUM,
            MediaStore.MediaColumns.DURATION,
            MediaStore.MediaColumns.RELATIVE_PATH,
        )
        val type = MediaStore.Files.FileColumns.MEDIA_TYPE
        val mime = MediaStore.MediaColumns.MIME_TYPE
        val path = MediaStore.MediaColumns.RELATIVE_PATH
        val dur = MediaStore.MediaColumns.DURATION
        val selection = "(" +
            "$type = ${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO}" +
            " OR ($mime = 'video/mp4' AND $path NOT LIKE 'DCIM/%' AND $path NOT LIKE 'Pictures/%')" +
            ") AND $dur >= 20000" +
            " AND $path NOT LIKE 'Ringtones/%' AND $path NOT LIKE 'Notifications/%' AND $path NOT LIKE 'Alarms/%'"

        val out = ArrayList<Song>()
        ctx.contentResolver.query(
            collection, projection, selection, null,
            "${MediaStore.MediaColumns.TITLE} COLLATE NOCASE ASC",
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val iType = c.getColumnIndexOrThrow(type)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.MediaColumns.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns.ALBUM)
            val iDur = c.getColumnIndexOrThrow(dur)
            val iPath = c.getColumnIndexOrThrow(path)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val isVideo = c.getInt(iType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val base = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val title = c.getString(iTitle)?.takeIf { it.isNotBlank() }
                    ?: c.getString(iName).orEmpty().substringBeforeLast('.')
                var artist = c.getString(iArtist).orEmpty()
                if (artist == "<unknown>") artist = ""
                var album = c.getString(iAlbum).orEmpty()
                if (album == "<unknown>") album = ""
                out += Song(
                    id = id,
                    uri = ContentUris.withAppendedId(base, id),
                    title = title,
                    artist = artist,
                    album = album,
                    durationMs = c.getLong(iDur),
                    relativePath = c.getString(iPath).orEmpty(),
                    isVideo = isVideo,
                )
            }
        }
        return out
    }
}
