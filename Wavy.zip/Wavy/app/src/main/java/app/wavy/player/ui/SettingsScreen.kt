package app.wavy.player.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.CircularProgressIndicator
import app.wavy.player.data.KeyState
import app.wavy.player.data.KeyStatus
import app.wavy.player.data.Provider
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.util.Locale

private fun num(n: Int): String = String.format(Locale.getDefault(), "%,d", n)

@Composable
private fun Card(content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
    ) {
        Column(Modifier.padding(20.dp)) { content() }
    }
}

@Composable
private fun StatusBox(st: KeyStatus) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when (st.state) {
        KeyState.Ok -> cs.primaryContainer to cs.onPrimaryContainer
        KeyState.Bad -> cs.errorContainer to cs.onErrorContainer
        else -> cs.surfaceContainerHighest to cs.onSurface
    }
    Surface(shape = RoundedCornerShape(20.dp), color = bg, contentColor = fg, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            when (st.state) {
                KeyState.Checking -> CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                KeyState.Ok -> Icon(Icons.Rounded.CheckCircle, null)
                KeyState.Bad -> Icon(Icons.Rounded.Error, null)
                KeyState.Offline -> Icon(Icons.Rounded.CloudOff, null)
                KeyState.None -> Icon(Icons.Rounded.Info, null)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(st.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                if (st.detail.isNotBlank()) {
                    Text(st.detail, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    apiKey: String,
    provider: String,
    modelPref: String,
    status: KeyStatus,
    limit: Int,
    used: Int,
    crossfade: Int,
    appPackage: String,
    appSha1: String,
    bottomPad: Dp,
    onSaveKey: (String) -> Unit,
    onProvider: (String) -> Unit,
    onModel: (String) -> Unit,
    onRecheck: () -> Unit,
    onLimit: (Int) -> Unit,
    onCrossfade: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var input by remember(apiKey) { mutableStateOf(apiKey) }
    var visible by remember { mutableStateOf(false) }
    var showId by remember { mutableStateOf(false) }
    val lang = remember { Locale.getDefault().displayLanguage }
    val gemini = provider != Provider.CLOUD

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Text(
            "Einstellungen",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.statusBarsPadding().padding(start = 4.dp, top = 16.dp, bottom = 16.dp),
        )

        Card {
            Text("Wiedergabe", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Überblenden: Das Ende des Songs blendet aus, während der nächste einblendet.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 3, 5, 8, 12).forEach { v ->
                    FilterChip(
                        selected = crossfade == v,
                        onClick = { onCrossfade(v) },
                        label = { Text(if (v == 0) "Aus" else "$v s") },
                    )
                }
            }
        }

        Card {
            Text("Songtexte übersetzen", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Nur auf Knopfdruck, in deine Systemsprache ($lang). Ergebnisse werden gespeichert.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = gemini, onClick = { onProvider(Provider.GEMINI) }, label = { Text("Gemini (KI)") })
                FilterChip(selected = !gemini, onClick = { onProvider(Provider.CLOUD) }, label = { Text("Cloud Translation") })
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                singleLine = true,
                label = { Text("Google-API-Schlüssel") },
                visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { visible = !visible }) {
                        Icon(if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Anzeigen")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { onSaveKey(input) }, enabled = input.trim() != apiKey) { Text("Speichern") }
                if (apiKey.isNotBlank()) {
                    TextButton(onClick = onRecheck) { Text("Prüfen") }
                    TextButton(onClick = { input = ""; onSaveKey("") }) { Text("Entfernen") }
                }
            }
            Spacer(Modifier.height(8.dp))
            StatusBox(status)
            if (gemini && status.state == KeyState.Ok && status.models.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("KI-Modell", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = modelPref.isBlank(), onClick = { onModel("") }, label = { Text("Automatisch") })
                    status.models.forEach { m ->
                        FilterChip(selected = modelPref == m, onClick = { onModel(m) }, label = { Text(m) })
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (gemini) "Schlüssel kostenlos auf aistudio.google.com erstellen. Er bleibt nur auf diesem Handy."
                else "Schlüssel in der Google Cloud Console (Cloud Translation API) erstellen. Er bleibt nur auf diesem Handy.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }

        Card {
            Text("Monatslimit", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(20_000, 50_000, 100_000, 200_000).forEach { v ->
                    FilterChip(selected = limit == v, onClick = { onLimit(v) }, label = { Text(num(v)) })
                }
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { if (limit > 0) (used.toFloat() / limit).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "${num(used)} von ${num(limit)} Zeichen diesen Monat",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }

        Card {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "App-Kennung",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { showId = !showId }) { Text(if (showId) "Verbergen" else "Anzeigen") }
            }
            if (showId) {
                Text(
                    "Nur nötig, wenn dein Schlüssel auf „Android-Apps“ eingeschränkt ist.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                SelectionContainer {
                    Column {
                        Text(appPackage, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (appSha1.isBlank()) "SHA-1 nicht verfügbar" else appSha1.chunked(2).joinToString(":"),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(bottomPad + 16.dp))
    }
}
