package app.wavy.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.wavy.player.data.KeyState
import app.wavy.player.data.KeyStatus
import app.wavy.player.data.Provider
import java.util.Locale
import kotlin.math.roundToInt

private fun num(n: Int): String = String.format(Locale.getDefault(), "%,d", n)

/** Große, weiche Karte für Gruppen mit freiem Inhalt. */
@Composable
private fun Card(content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
    ) {
        Column(Modifier.padding(20.dp)) { content() }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 8.dp, top = 12.dp, bottom = 8.dp),
    )
}

@Composable
private fun IconBadge(icon: ImageVector, enabled: Boolean = true) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) cs.primaryContainer else cs.surfaceContainerHighest),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = if (enabled) cs.onPrimaryContainer else cs.onSurfaceVariant, modifier = Modifier.size(26.dp)) }
}

/** Kachel, die eine Unterseite öffnet. */
@Composable
private fun NavTile(index: Int, count: Int, icon: ImageVector, title: String, summary: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = segShape(index, count),
        color = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(summary, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 2)
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = cs.onSurfaceVariant)
        }
    }
}

/** Kachel mit Ein-/Ausschalter. */
@Composable
private fun SwitchTile(
    index: Int,
    count: Int,
    icon: ImageVector,
    title: String,
    summary: String,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = { if (enabled) onChange(!checked) },
        shape = segShape(index, count),
        color = cs.surfaceContainerHigh,
        contentColor = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(start = 16.dp, end = 12.dp, top = 14.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon, enabled)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(summary, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                enabled = enabled,
                thumbContent = if (checked) {
                    { Icon(Icons.Rounded.Check, null, Modifier.size(16.dp)) }
                } else null,
            )
        }
    }
}

@Composable
private fun StatusBox(st: KeyStatus) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when (st.state) {
        KeyState.Ok -> cs.primaryContainer to cs.onPrimaryContainer
        KeyState.Bad -> cs.errorContainer to cs.onErrorContainer
        else -> cs.surfaceContainerHighest to cs.onSurface
    }
    Surface(shape = RoundedCornerShape(20.dp), color = bg, contentColor = fg, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            when (st.state) {
                KeyState.Checking -> CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                KeyState.Ok -> Icon(Icons.Rounded.CheckCircle, null)
                KeyState.Bad -> Icon(Icons.Rounded.Error, null)
                KeyState.Offline -> Icon(Icons.Rounded.CloudOff, null)
                KeyState.None -> Icon(Icons.Rounded.Info, null)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(st.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                if (st.detail.isNotBlank()) {
                    Text(st.detail, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    apiKey: String,
    provider: String,
    modelPref: String,
    status: KeyStatus,
    limit: Int,
    used: Int,
    crossfade: Int,
    lastCrossfade: Int,
    lyricsOn: Boolean,
    karaoke: Boolean,
    resumeOn: Boolean,
    stopOnClose: Boolean,
    appPackage: String,
    appSha1: String,
    bottomPad: Dp,
    onSaveKey: (String) -> Unit,
    onProvider: (String) -> Unit,
    onModel: (String) -> Unit,
    onRecheck: () -> Unit,
    onLimit: (Int) -> Unit,
    onCrossfade: (Int) -> Unit,
    onLyricsOn: (Boolean) -> Unit,
    onKaraoke: (Boolean) -> Unit,
    onResumeOn: (Boolean) -> Unit,
    onStopOnClose: (Boolean) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var page by rememberSaveable { mutableStateOf("") }
    BackHandler(enabled = page.isNotEmpty()) { page = "" }
    val gemini = provider != Provider.CLOUD

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Row(
            Modifier.statusBarsPadding().padding(start = 4.dp, top = 16.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (page.isNotEmpty()) {
                FilledTonalIconButton(onClick = { page = "" }, modifier = Modifier.size(48.dp), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Zurück")
                }
                Spacer(Modifier.width(14.dp))
            }
            Text(
                when (page) {
                    "play" -> "Wiedergabe"
                    "lyrics" -> "Songtexte"
                    "translate" -> "Übersetzung"
                    "about" -> "Info"
                    else -> "Einstellungen"
                },
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
            )
        }

        Crossfade(targetState = page, animationSpec = tween(220), label = "settingsPage") { p ->
            Column {
                when (p) {
                    "play" -> {
                        SectionLabel("Übergänge")
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            SwitchTile(
                                0, if (crossfade > 0) 2 else 1, Icons.Rounded.GraphicEq, "Songs überblenden",
                                "Der nächste Song setzt schon ein, bevor der alte endet.",
                                crossfade > 0,
                            ) { on -> onCrossfade(if (on) lastCrossfade else 0) }
                            AnimatedVisibility(
                                visible = crossfade > 0,
                                enter = expandVertically() + fadeIn(),
                                exit = shrinkVertically() + fadeOut(),
                            ) {
                                var v by remember(crossfade) { mutableFloatStateOf(crossfade.toFloat()) }
                                Surface(
                                    shape = segShape(1, 2),
                                    color = cs.surfaceContainerHigh,
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Dauer", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                            Text("${v.roundToInt()} s", style = MaterialTheme.typography.titleMedium, color = cs.primary, fontWeight = FontWeight.Bold)
                                        }
                                        Slider(
                                            value = v,
                                            onValueChange = { v = it },
                                            onValueChangeFinished = { onCrossfade(v.roundToInt().coerceAtLeast(1)) },
                                            valueRange = 1f..12f,
                                            steps = 10,
                                        )
                                    }
                                }
                            }
                        }
                        SectionLabel("Verhalten")
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            SwitchTile(
                                0, 2, Icons.Rounded.Info, "Wiedergabe fortsetzen",
                                "Nach dem Start geht es dort weiter, wo du aufgehört hast.",
                                resumeOn, onChange = onResumeOn,
                            )
                            SwitchTile(
                                1, 2, Icons.Rounded.Info, "Beim Schließen stoppen",
                                "Die Musik endet, wenn du die App aus der Übersicht wischst.",
                                stopOnClose, onChange = onStopOnClose,
                            )
                        }
                    }

                    "lyrics" -> {
                        SectionLabel("Anzeige")
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            SwitchTile(
                                0, 3, Icons.Rounded.Lyrics, "Songtexte laden",
                                "Texte kommen im Hintergrund von LRCLIB und werden gespeichert.",
                                lyricsOn, onChange = onLyricsOn,
                            )
                            SwitchTile(
                                1, 3, Icons.Rounded.Lyrics, "Wort für Wort mitleuchten",
                                "Die gesungene Zeile leuchtet Buchstabe für Buchstabe auf.",
                                karaoke, enabled = lyricsOn, onChange = onKaraoke,
                            )
                            NavTile(
                                2, 3, Icons.Rounded.Translate, "Übersetzung",
                                if (apiKey.isBlank()) "Noch nicht eingerichtet" else if (gemini) "Gemini (KI)" else "Cloud Translation",
                            ) { page = "translate" }
                        }
                    }

                    "translate" -> {
                        Card {
                            Text("Dienst", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Nur auf Knopfdruck, in deine Systemsprache (${Locale.getDefault().displayLanguage}). Ergebnisse werden gespeichert.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf(Provider.GEMINI to "Gemini (KI)", Provider.CLOUD to "Cloud Translation").forEachIndexed { i, (key, label) ->
                                    val sel = (key == Provider.GEMINI) == gemini
                                    Surface(
                                        onClick = { onProvider(key) },
                                        shape = RoundedCornerShape(
                                            topStart = if (sel || i == 0) 24.dp else 8.dp,
                                            bottomStart = if (sel || i == 0) 24.dp else 8.dp,
                                            topEnd = if (sel || i == 1) 24.dp else 8.dp,
                                            bottomEnd = if (sel || i == 1) 24.dp else 8.dp,
                                        ),
                                        color = if (sel) cs.primary else cs.surfaceContainerHighest,
                                        contentColor = if (sel) cs.onPrimary else cs.onSurface,
                                        modifier = Modifier.weight(1f).height(48.dp),
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        Card {
                            var input by remember(apiKey) { mutableStateOf(apiKey) }
                            var visible by remember { mutableStateOf(false) }
                            Text("Google-API-Schlüssel", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(
                                value = input,
                                onValueChange = { input = it },
                                singleLine = true,
                                label = { Text("Schlüssel") },
                                shape = RoundedCornerShape(20.dp),
                                visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { visible = !visible }) {
                                        Icon(if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Anzeigen")
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = { onSaveKey(input) }, enabled = input.trim() != apiKey) { Text("Speichern") }
                                if (apiKey.isNotBlank()) {
                                    TextButton(onClick = onRecheck) { Text("Prüfen") }
                                    TextButton(onClick = { input = ""; onSaveKey("") }) { Text("Entfernen") }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            StatusBox(status)
                            if (gemini && status.state == KeyState.Ok && status.models.isNotEmpty()) {
                                Spacer(Modifier.height(12.dp))
                                Text("KI-Modell", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(6.dp))
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(selected = modelPref.isBlank(), onClick = { onModel("") }, label = { Text("Automatisch") })
                                    status.models.forEach { m ->
                                        FilterChip(selected = modelPref == m, onClick = { onModel(m) }, label = { Text(m) })
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                if (gemini) "Schlüssel kostenlos auf aistudio.google.com erstellen. Er bleibt nur auf diesem Handy."
                                else "Schlüssel in der Google Cloud Console (Cloud Translation API) erstellen. Er bleibt nur auf diesem Handy.",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        Card {
                            Text("Monatslimit", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(20_000, 50_000, 100_000, 200_000).forEach { v ->
                                    FilterChip(selected = limit == v, onClick = { onLimit(v) }, label = { Text(num(v)) })
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            LinearProgressIndicator(
                                progress = { if (limit > 0) (used.toFloat() / limit).coerceIn(0f, 1f) else 0f },
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "${num(used)} von ${num(limit)} Zeichen diesen Monat",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                        }
                    }

                    "about" -> {
                        Card {
                            Text("App-Kennung", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Nur nötig, wenn dein Schlüssel auf „Android-Apps“ eingeschränkt ist.",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(12.dp))
                            SelectionContainer {
                                Column {
                                    Text(appPackage, style = MaterialTheme.typography.bodyMedium)
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        if (appSha1.isBlank()) "SHA-1 nicht verfügbar" else appSha1.chunked(2).joinToString(":"),
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                            }
                        }
                    }

                    else -> {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            NavTile(
                                0, 4, Icons.Rounded.GraphicEq, "Wiedergabe",
                                "Überblenden ${if (crossfade > 0) "$crossfade s" else "aus"} · Fortsetzen ${if (resumeOn) "an" else "aus"}",
                            ) { page = "play" }
                            NavTile(
                                1, 4, Icons.Rounded.Lyrics, "Songtexte",
                                "Laden ${if (lyricsOn) "an" else "aus"} · Mitleuchten ${if (karaoke && lyricsOn) "an" else "aus"}",
                            ) { page = "lyrics" }
                            NavTile(
                                2, 4, Icons.Rounded.Translate, "Übersetzung",
                                if (apiKey.isBlank()) "Noch nicht eingerichtet" else status.title.ifBlank { "Eingerichtet" },
                            ) { page = "translate" }
                            NavTile(3, 4, Icons.Rounded.Info, "Info", appPackage) { page = "about" }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(bottomPad + 16.dp))
    }
}
