package app.wavy.player.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.CircularProgressIndicator
import app.wavy.player.data.KeyState
import app.wavy.player.data.KeyStatus
import app.wavy.player.data.Provider
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.util.Locale

private fun num(n: Int): String = String.format(Locale.getDefault(), "%,d", n)

@Composable
private fun Card(content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
    ) {
        Column(Modifier.padding(20.dp)) { content() }
    }
}

@Composable
private fun StatusBox(st: KeyStatus) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when (st.state) {
        KeyState.Ok -> cs.primaryContainer to cs.onPrimaryContainer
        KeyState.Bad -> cs.errorContainer to cs.onErrorContainer
        else -> cs.surfaceContainerHighest to cs.onSurface
    }
    Surface(shape = RoundedCornerShape(20.dp), color = bg, contentColor = fg, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            when (st.state) {
                KeyState.Checking -> CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                KeyState.Ok -> Icon(Icons.Rounded.CheckCircle, null)
                KeyState.Bad -> Icon(Icons.Rounded.Error, null)
                KeyState.Offline -> Icon(Icons.Rounded.CloudOff, null)
                KeyState.None -> Icon(Icons.Rounded.Info, null)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(st.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                if (st.detail.isNotBlank()) {
                    Text(st.detail, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    apiKey: String,
    provider: String,
    modelPref: String,
    status: KeyStatus,
    limit: Int,
    used: Int,
    appPackage: String,
    appSha1: String,
    bottomPad: Dp,
    onSaveKey: (String) -> Unit,
    onProvider: (String) -> Unit,
    onModel: (String) -> Unit,
    onRecheck: () -> Unit,
    onLimit: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var input by remember(apiKey) { mutableStateOf(apiKey) }
    var visible by remember { mutableStateOf(false) }
    val lang = remember { Locale.getDefault().displayLanguage }
    val gemini = provider != Provider.CLOUD

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Text(
            "Einstellungen",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.statusBarsPadding().padding(start = 4.dp, top = 16.dp, bottom = 16.dp),
        )

        Card {
            Text("Songtexte übersetzen", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Wavy übersetzt Songtexte in deine Systemsprache ($lang). Übersetzt wird nur, wenn du im Songtext auf „Übersetzen“ tippst.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            Text("Anbieter", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = gemini, onClick = { onProvider(Provider.GEMINI) }, label = { Text("Gemini (KI)") })
                FilterChip(selected = !gemini, onClick = { onProvider(Provider.CLOUD) }, label = { Text("Cloud Translation") })
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                singleLine = true,
                label = { Text("Google-API-Schlüssel") },
                visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { visible = !visible }) {
                        Icon(if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Anzeigen")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { onSaveKey(input) }, enabled = input.trim() != apiKey) { Text("Speichern") }
                if (apiKey.isNotBlank()) {
                    TextButton(onClick = onRecheck) { Text("Erneut prüfen") }
                    TextButton(onClick = { input = ""; onSaveKey("") }) { Text("Entfernen") }
                }
            }
            Spacer(Modifier.height(12.dp))
            StatusBox(status)
            if (apiKey.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Gespeicherter Schlüssel endet auf …${apiKey.takeLast(4)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
            if (gemini && status.state == KeyState.Ok && status.models.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Text("KI-Modell", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = modelPref.isBlank(), onClick = { onModel("") }, label = { Text("Automatisch") })
                    status.models.forEach { m ->
                        FilterChip(selected = modelPref == m, onClick = { onModel(m) }, label = { Text(m) })
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                if (gemini) {
                    "So bekommst du einen Schlüssel: auf aistudio.google.com anmelden und „API-Schlüssel erstellen“ wählen. " +
                        "„Automatisch“ nimmt das günstigste passende Gemini-Modell. Der Schlüssel bleibt nur auf deinem Handy und ist nicht in Backups."
                } else {
                    "So bekommst du einen Schlüssel: In der Google Cloud Console die „Cloud Translation API“ aktivieren und unter " +
                        "„APIs & Dienste → Anmeldedaten“ einen API-Schlüssel erstellen. Der Schlüssel bleibt nur auf deinem Handy und ist nicht in Backups."
                },
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }

        Card {
            Text("App-Kennung", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Hast du deinen Schlüssel auf „Android-Apps“ eingeschränkt (Google Cloud → Anmeldedaten), trage genau diese Werte dort ein. " +
                    "Wavy schickt sie bei jeder Anfrage mit.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            SelectionContainer {
                Column {
                    Text("Paketname", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                    Text(appPackage, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("SHA-1-Fingerabdruck", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                    Text(
                        if (appSha1.isBlank()) "nicht verfügbar" else appSha1.chunked(2).joinToString(":"),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }

        Card {
            Text("Sparsam bleiben", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "• Nie automatisch, nur auf Knopfdruck\n" +
                    "• Jede Zeile wird nur einmal gesendet (Refrains zählen einmal)\n" +
                    "• Ergebnisse bleiben gespeichert, derselbe Song kostet nie wieder\n" +
                    "• Ist ein Text schon in deiner Sprache, wird das gemerkt\n" +
                    "• Vor jeder Anfrage wird dein Monatslimit geprüft",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            Text("Monatslimit (Zeichen)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(20_000, 50_000, 100_000, 200_000).forEach { v ->
                    FilterChip(selected = limit == v, onClick = { onLimit(v) }, label = { Text(num(v)) })
                }
            }
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { if (limit > 0) (used.toFloat() / limit).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Diesen Monat verbraucht: ${num(used)} von ${num(limit)} Zeichen",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Die Preise und das Gratis-Kontingent legt Google fest – schau in deinem Google-Konto nach den aktuellen Bedingungen.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(bottomPad + 16.dp))
    }
}
