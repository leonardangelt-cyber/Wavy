package app.wavy.player.data

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Findet für jede Zeile eines synchronisierten Songtexts, wann welches Wort beginnt – ohne Spracherkennung
 * und ohne Internet, direkt aus dem Audio:
 *  1. Die Datei wird mit dem Android-Decoder gelesen (MP3, AAC/M4A, FLAC, OGG, Opus, WAV … alles, was das Gerät abspielt)
 *     und auf Mono / ca. 11 kHz heruntergerechnet.
 *  2. Im Stimmband (300–3400 Hz) wird per FFT der "Einsatz" (Spectral Flux) jedes 10-ms-Schritts berechnet,
 *     lokal normalisiert, so dass leise und laute Stellen gleich zählen.
 *  3. Je Zeile werden die Wörter per Viterbi-Suche auf die Einsätze gelegt: Silbenschätzung des Textes liefert die
 *     erwartete Position, ein Einsatz in der Nähe zieht das Wort dorthin.
 * Das Ergebnis wird pro Song zwischengespeichert.
 */
class WordAligner(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "align").also { it.mkdirs() }

    suspend fun align(song: Song, lines: List<LrcLine>): WordTiming? = withContext(Dispatchers.Default) {
        if (lines.isEmpty()) return@withContext null
        val key = (song.durationMs.toString() + "|" + lines.joinToString("\n") { "${it.timeMs}:${it.text}" }.hashCode())
        val file = File(dir, "${song.id}.json")
        readCache(file, key, lines.size)?.let { return@withContext it }
        try {
            val cc = coroutineContext
            val onset = analyse(song.uri) { cc.isActive } ?: return@withContext null
            val starts = ArrayList<LongArray>()
            val ends = LongArray(lines.size)
            for (i in lines.indices) {
                val l = lines[i]
                val next = lines.getOrNull(i + 1)?.timeMs
                val words = splitWords(l.text)
                val total = words.sumOf { wordWeight(it).toDouble() }.toFloat().coerceAtLeast(1f)
                val natural = (total / 3.0f).coerceAtLeast(1f) * 300f + 400f
                val gap = (next?.let { it - l.timeMs } ?: 5000L).toFloat()
                val sing = (if (gap <= natural * 1.6f) gap - 150f else natural).coerceAtLeast(400f)
                val end = l.timeMs + sing.toLong()
                ends[i] = end
                starts += if (words.isEmpty()) LongArray(0) else alignLine(onset, l.timeMs, end, words)
            }
            val res = WordTiming(starts, ends)
            writeCache(file, key, res)
            res
        } catch (_: Throwable) {
            null
        }
    }

    // ---------- Zwischenspeicher ----------

    private fun readCache(f: File, key: String, n: Int): WordTiming? = try {
        if (!f.exists()) null else {
            val o = JSONObject(f.readText())
            if (o.getString("k") != key) null else {
                val s = o.getJSONArray("s")
                val e = o.getJSONArray("e")
                if (s.length() != n) null else WordTiming(
                    List(n) { i -> val a = s.getJSONArray(i); LongArray(a.length()) { a.getLong(it) } },
                    LongArray(n) { e.getLong(it) },
                )
            }
        }
    } catch (_: Exception) {
        null
    }

    private fun writeCache(f: File, key: String, t: WordTiming) {
        try {
            val s = JSONArray()
            t.starts.forEach { a -> s.put(JSONArray().also { j -> a.forEach { v -> j.put(v) } }) }
            val e = JSONArray().also { j -> t.ends.forEach { v -> j.put(v) } }
            f.writeText(JSONObject().put("k", key).put("s", s).put("e", e).toString())
        } catch (_: Exception) {
        }
    }

    // ---------- Text → Gewichte ----------

    private fun splitWords(text: String) = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    /** Vokale werden gedehnt gesungen, Konsonanten kurz, nach Satzzeichen entsteht eine Atempause. */
    private fun wordWeight(w: String): Float {
        var x = 0f
        for (ch in w) {
            x += if (ch.lowercaseChar() in "aeiouyäöüàáâèéêìíòóôùú") 2.4f else if (ch.isLetterOrDigit()) 0.9f else 0.3f
        }
        if (w.last() in ",;:.!?–-…") x += 2.2f
        return x
    }

    // ---------- Audio → Einsatzstärke ----------

    private class Onsets(val o: FloatArray, val frameMs: Double)

    private class FloatBuf {
        var a = FloatArray(1 shl 20)
        var n = 0
        fun add(v: Float) {
            if (n == a.size) a = a.copyOf(a.size * 2)
            a[n++] = v
        }
    }

    private fun decodeMono(uri: Uri, rate: Int, maxSec: Int, alive: () -> Boolean): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return null
            ex.selectTrack(track)
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0)
            codec.start()
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
            var pcmFloat = false
            var step = sr.toDouble() / rate
            var pos = 0.0
            var acc = 0.0
            var cnt = 0
            val buf = FloatBuf()
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            val deadline = System.currentTimeMillis() + 90_000
            val maxSamples = rate * maxSec
            while (!outDone && alive() && System.currentTimeMillis() < deadline && buf.n < maxSamples) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(5000)
                    if (i >= 0) {
                        val b = codec.getInputBuffer(i)!!
                        val sz = ex.readSampleData(b, 0)
                        if (sz < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 5000)
                if (o >= 0) {
                    val ob = codec.getOutputBuffer(o)
                    if (ob != null && info.size > 0) {
                        ob.order(ByteOrder.nativeOrder())
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        if (pcmFloat) {
                            val fb = ob.asFloatBuffer()
                            while (fb.remaining() >= ch) {
                                var s = 0f
                                for (c in 0 until ch) s += fb.get()
                                acc += s / ch; cnt++; pos += 1.0
                                if (pos >= step) { buf.add((acc / cnt).toFloat()); pos -= step; acc = 0.0; cnt = 0 }
                            }
                        } else {
                            val sb = ob.asShortBuffer()
                            while (sb.remaining() >= ch) {
                                var s = 0f
                                for (c in 0 until ch) s += sb.get()
                                acc += s / ch / 32768f; cnt++; pos += 1.0
                                if (pos >= step) { buf.add((acc / cnt).toFloat()); pos -= step; acc = 0.0; cnt = 0 }
                            }
                        }
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    step = sr.toDouble() / rate
                    pcmFloat = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                }
            }
            return if (buf.n > rate * 5) buf.a.copyOf(buf.n) else null
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }

    private fun analyse(uri: Uri, alive: () -> Boolean): Onsets? {
        val rate = 11025
        val pcm = decodeMono(uri, rate, 12 * 60, alive) ?: return null
        val n = 512
        val hop = 110
        val frames = (pcm.size - n) / hop
        if (frames < 100) return null
        val win = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
        val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
        val sinT = FloatArray(n / 2) { -sin(2.0 * PI * it / n).toFloat() }
        val rev = IntArray(n).also { r ->
            val bits = 9
            for (i in 0 until n) { var x = i; var y = 0; repeat(bits) { y = (y shl 1) or (x and 1); x = x shr 1 }; r[i] = y }
        }
        val lo = 14
        val hi = 160
        val prev = FloatArray(hi - lo)
        val flux = FloatArray(frames)
        val re = FloatArray(n)
        val im = FloatArray(n)
        for (t in 0 until frames) {
            if (t % 500 == 0 && !alive()) return null
            val off = t * hop
            for (i in 0 until n) { re[rev[i]] = pcm[off + i] * win[i]; im[rev[i]] = 0f }
            var len = 2
            while (len <= n) {
                val half = len / 2
                val stepT = n / len
                var i = 0
                while (i < n) {
                    for (j in 0 until half) {
                        val wr = cosT[j * stepT]
                        val wi = sinT[j * stepT]
                        val a = i + j
                        val b = a + half
                        val xr = re[b] * wr - im[b] * wi
                        val xi = re[b] * wi + im[b] * wr
                        re[b] = re[a] - xr; im[b] = im[a] - xi
                        re[a] += xr; im[a] += xi
                    }
                    i += len
                }
                len = len shl 1
            }
            var f = 0f
            for (b in lo until hi) {
                val mag = sqrt(re[b] * re[b] + im[b] * im[b])
                val lg = ln(1f + mag * 40f)
                val d = lg - prev[b - lo]
                if (d > 0f) f += d
                prev[b - lo] = lg
            }
            flux[t] = f / (hi - lo)
        }
        // lokale Normalisierung (±0,6 s): Einsatz = Abweichung über dem lokalen Mittel
        val pre = DoubleArray(frames + 1)
        for (i in 0 until frames) pre[i + 1] = pre[i] + flux[i]
        val raw = FloatArray(frames)
        val w = 60
        for (t in 0 until frames) {
            val a = max(0, t - w)
            val b = min(frames, t + w + 1)
            val mean = ((pre[b] - pre[a]) / (b - a)).toFloat()
            raw[t] = max(0f, (flux[t] - mean) / (mean + 0.02f))
        }
        val o = FloatArray(frames)
        for (t in 0 until frames) {
            val s = raw[t] * 0.5f + raw.getOrElse(t - 1) { 0f } * 0.25f + raw.getOrElse(t + 1) { 0f } * 0.25f
            o[t] = min(s, 6f)
        }
        return Onsets(o, 1000.0 * hop / rate)
    }

    // ---------- Wörter auf Einsätze legen (Viterbi) ----------

    private fun alignLine(on: Onsets, startMs: Long, endMs: Long, words: List<String>): LongArray {
        val n = words.size
        val cum = FloatArray(n + 1)
        for (k in 0 until n) cum[k + 1] = cum[k] + wordWeight(words[k])
        val total = cum[n].coerceAtLeast(1f)
        val dur = (endMs - startMs).toDouble().coerceAtLeast(300.0)
        val fm = on.frameMs
        val o = on.o
        val ideal = IntArray(n) { (((startMs + dur * cum[it] / total) / fm)).roundToInt() }
        val fallback = LongArray(n) { (startMs + dur * cum[it] / total).toLong() }
        if (ideal.last() < 0 || ideal[0] >= o.size) return fallback
        val avgWord = dur / n
        val tolN = ((avgWord * 0.4).coerceIn(80.0, 450.0) / fm).toInt().coerceAtLeast(3)
        val minSep = min(5, max(1, (avgWord / fm * 0.4).toInt()))
        val lambda = 1.0f
        val tolOf = { k: Int -> if (k == 0) min(tolN, 30) else tolN }
        val lows = IntArray(n) { max(0, ideal[it] - tolOf(it)) }
        val highs = IntArray(n) { min(o.size - 1, ideal[it] + tolOf(it)) }
        for (k in 0 until n) if (lows[k] > highs[k]) return fallback
        val score = Array(n) { FloatArray(highs[it] - lows[it] + 1) { Float.NEGATIVE_INFINITY } }
        val back = Array(n) { IntArray(highs[it] - lows[it] + 1) { -1 } }
        for (k in 0 until n) {
            val tol = tolOf(k).toFloat()
            for (j in score[k].indices) {
                val f = lows[k] + j
                val d = (f - ideal[k]) / tol
                val local = min(o[f], 4f) * 0.8f - lambda * d * d
                if (k == 0) {
                    score[k][j] = local
                } else {
                    var best = Float.NEGATIVE_INFINITY
                    var bi = -1
                    val pk = score[k - 1]
                    val maxPrev = f - minSep
                    var q = 0
                    while (q < pk.size && lows[k - 1] + q <= maxPrev) {
                        if (pk[q] > best) { best = pk[q]; bi = q }
                        q++
                    }
                    if (bi >= 0) { score[k][j] = best + local; back[k][j] = bi }
                }
            }
        }
        var bj = -1
        var bs = Float.NEGATIVE_INFINITY
        for (j in score[n - 1].indices) if (score[n - 1][j] > bs) { bs = score[n - 1][j]; bj = j }
        if (bj < 0) return fallback
        val res = LongArray(n)
        var j = bj
        for (k in n - 1 downTo 0) {
            res[k] = (( lows[k] + j) * fm).toLong()
            j = back[k][j]
            if (k > 0 && j < 0) return fallback
        }
        return res
    }
}
