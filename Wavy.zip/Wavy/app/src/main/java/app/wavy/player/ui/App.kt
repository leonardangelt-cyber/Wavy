package app.wavy.player.ui

import androidx.compose.runtime.derivedStateOf
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.layout
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.CubicBezierEasing
import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.spring
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.wavy.player.MusicViewModel
import app.wavy.player.data.MediaRepository
import app.wavy.player.data.Song

private val PERMISSIONS: Array<String> = if (Build.VERSION.SDK_INT >= 33) {
    arrayOf(
        Manifest.permission.READ_MEDIA_AUDIO,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.POST_NOTIFICATIONS,
    )
} else {
    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

/** Sichtbarer Ausschnitt mit runden Ecken (für das Herauswachsen des Players aus der Mini-Karte). */
private class RevealShape(
    private val l: Float,
    private val t: Float,
    private val r: Float,
    private val b: Float,
    private val rad: Float,
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline =
        Outline.Rounded(RoundRect(l, t, r, b, CornerRadius(rad, rad)))
}

@Composable
fun WavyApp(vm: MusicViewModel) {
    val ctx = LocalContext.current
    val songs by vm.songs.collectAsStateWithLifecycle()
    val loaded by vm.loaded.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val excluded by vm.excludedIds.collectAsStateWithLifecycle()
    val hidden by vm.hiddenIds.collectAsStateWithLifecycle()
    val ps by vm.player.collectAsStateWithLifecycle()
    val seed by vm.seed.collectAsStateWithLifecycle()
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val translation by vm.translation.collectAsStateWithLifecycle()
    val current by vm.currentSong.collectAsStateWithLifecycle()
    val apiKey by vm.settings.apiKey.collectAsStateWithLifecycle()
    val limit by vm.settings.monthlyLimit.collectAsStateWithLifecycle()
    val used by vm.settings.usedChars.collectAsStateWithLifecycle()
    val provider by vm.settings.provider.collectAsStateWithLifecycle()
    val modelPref by vm.settings.model.collectAsStateWithLifecycle()
    val keyStatus by vm.keyStatus.collectAsStateWithLifecycle()
    val crossfade by vm.settings.crossfadeSec.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var homeView by rememberSaveable { mutableIntStateOf(0) }
    var groupKey by rememberSaveable { mutableStateOf<String?>(null) }
    var openPlaylistId by rememberSaveable { mutableStateOf<Long?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var addSongId by rememberSaveable { mutableStateOf<Long?>(null) }
    var granted by remember { mutableStateOf(MediaRepository.hasPermission(ctx)) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = MediaRepository.hasPermission(ctx)
        if (granted) vm.refreshSongs()
    }

    LaunchedEffect(Unit) {
        if (granted) vm.refreshSongs() else launcher.launch(PERMISSIONS)
    }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.foreground = false }
    LaunchedEffect(showPlayer) { vm.playerOpen = showPlayer }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        vm.foreground = true
        granted = MediaRepository.hasPermission(ctx)
        if (granted) vm.refreshSongs()
    }

    val songsById = remember(songs) { songs.associateBy { it.id } }
    val librarySongs = remember(songs, hidden) { songs.filter { it.id !in hidden } }
    val openPlaylist = playlists.firstOrNull { it.id == openPlaylistId }
    val addSong = addSongId?.let { songsById[it] }

    // Schlüssel automatisch prüfen, sobald die Einstellungen offen sind oder sich etwas ändert
    LaunchedEffect(tab, apiKey, provider, modelPref) {
        if (tab == 2) vm.checkKey()
    }

    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && tab == 1 && openPlaylist != null) { openPlaylistId = null }
    BackHandler(enabled = !showPlayer && tab == 0 && groupKey != null) { groupKey = null }

    // Wischt man gerade auf einen anderen Song, übernimmt die App schon dessen Akzentfarbe
    var peek by remember { mutableStateOf<Song?>(null) }
    val peekSeed = peek?.let { rememberCoverSeed(it) }

    // Die Farben des aktuellen Covers färben die ganze App ein
    PlayerTheme(peekSeed ?: seed) {
        val cs = MaterialTheme.colorScheme
        val density = LocalDensity.current
        var barPx by remember { mutableIntStateOf(0) }
        val bottom = with(density) { barPx.toDp() }

        // Öffnen/Schließen: Fortschritt 0..1; per Finger direkt steuerbar, sonst federt er zum Ziel
        val prog = remember { androidx.compose.animation.core.Animatable(0f) }
        var dragging by remember { mutableStateOf(false) }
        var dragP by remember { mutableFloatStateOf(0f) }
        val hasSong = current != null
        LaunchedEffect(showPlayer, hasSong, dragging) {
            if (!dragging) prog.animateTo(if (showPlayer && hasSong) 1f else 0f, spring(dampingRatio = 1f, stiffness = 300f))
        }
        // Nur als Funktion gelesen (in Zeichen-/Layout-Phase), damit die Animation keine Neuberechnung der UI auslöst
        val openF: () -> Float = { if (dragging) dragP else prog.value }
        val overlayVisible by remember { derivedStateOf { (if (dragging) dragP else prog.value) > 0.001f } }
        val floatingVisible by remember { derivedStateOf { (if (dragging) dragP else prog.value) < 0.995f } }
        val sheetScope = rememberCoroutineScope()
        var screenPx by remember { mutableIntStateOf(0) }
        var screenW by remember { mutableIntStateOf(0) }
        var miniRect by remember { mutableStateOf(Rect.Zero) }
        var miniCover by remember { mutableStateOf(Rect.Zero) }
        var bigCover by remember { mutableStateOf(Rect.Zero) }

        Box(Modifier.fillMaxSize().onSizeChanged { screenPx = it.height; screenW = it.width }.background(cs.background)) {
            when (tab) {
                0 -> HomeScreen(
                    songs = librarySongs,
                    loaded = loaded,
                    granted = granted,
                    excluded = excluded,
                    currentId = ps.mediaId,
                    bottomPad = bottom,
                    view = homeView,
                    onView = { homeView = it; groupKey = null },
                    groupKey = groupKey,
                    onGroup = { groupKey = it },
                    onRequestPermission = { launcher.launch(PERMISSIONS) },
                    onPlayAll = { vm.playHome(it, shuffle = false) },
                    onShuffle = { vm.playHome(it, shuffle = true) },
                    onSongClick = { list, s -> vm.playFromHome(list, s) },
                    onMore = { addSongId = it.id },
                    onPlayGroup = { list, shuffle -> vm.playPlaylist(list, shuffle) },
                    onGroupSongClick = { list, s -> vm.playPlaylistSong(list, s) },
                    loadAlbum = { artist, album -> vm.albumTracks(artist, album) },
                    loadTop = { artist -> vm.topSongs(artist) },
                    onOpenLink = { url ->
                        try {
                            ctx.startActivity(
                                android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        } catch (_: Exception) {
                        }
                    },
                )
                1 -> if (openPlaylist == null) {
                    PlaylistsScreen(
                        playlists = playlists,
                        songsById = songsById,
                        bottomPad = bottom,
                        onOpen = { openPlaylistId = it },
                        onCreate = { openPlaylistId = vm.createPlaylist(it) },
                    )
                } else {
                    val plSongs: List<Song> = openPlaylist.songIds.mapNotNull { songsById[it] }
                    PlaylistDetailScreen(
                        playlist = openPlaylist,
                        songs = plSongs,
                        allSongs = songs,
                        currentId = ps.mediaId,
                        bottomPad = bottom,
                        onBack = { openPlaylistId = null },
                        onPlay = { shuffle -> vm.playPlaylist(plSongs, shuffle) },
                        onSongClick = { s -> vm.playPlaylistSong(plSongs, s) },
                        onToggleSong = { sid -> vm.toggleSong(openPlaylist.id, sid) },
                        onToggleExclude = { vm.setExclude(openPlaylist.id, it) },
                        onToggleHide = { vm.setHide(openPlaylist.id, it) },
                        onRename = { vm.renamePlaylist(openPlaylist.id, it) },
                        onDelete = {
                            val id = openPlaylist.id
                            openPlaylistId = null
                            vm.deletePlaylist(id)
                        },
                    )
                }
                else -> SettingsScreen(
                    apiKey = apiKey,
                    provider = provider,
                    modelPref = modelPref,
                    status = keyStatus,
                    limit = limit,
                    used = used,
                    crossfade = crossfade,
                    appPackage = vm.appPackage,
                    appSha1 = vm.appSha1,
                    bottomPad = bottom,
                    onSaveKey = vm.settings::setApiKey,
                    onProvider = vm.settings::setProvider,
                    onModel = vm.settings::setModel,
                    onRecheck = vm::checkKey,
                    onLimit = vm.settings::setLimit,
                    onCrossfade = vm.settings::setCrossfade,
                )
            }

            // Weicher Verlauf, damit die schwebende Leiste sich vom Inhalt abhebt
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(bottom + 24.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, cs.background.copy(alpha = 0.94f)))),
            )

            // Schwebende Navigation + Mini-Player
            FloatingNavBar(
                selected = tab,
                onSelect = { tab = it },
                song = current,
                isPlaying = ps.isPlaying,
                progress = {
                    val dur = if (ps.durationMs > 0) ps.durationMs else current?.durationMs ?: 0L
                    if (dur > 0) (vm.positionMs.longValue.toFloat() / dur).coerceIn(0f, 1f) else 0f
                },
                onOpenPlayer = { showPlayer = true },
                onToggle = vm::togglePlay,
                onNext = vm::next,
                onPrevTrack = vm::previousTrack,
                onMiniBounds = { miniRect = it },
                onMiniCover = { if (openF() < 0.01f) miniCover = it },
                prevSong = ps.prevId?.let { songsById[it] },
                nextSong = ps.nextId?.let { songsById[it] },
                onPeek = { peek = it },
                onSheetStart = { dragP = prog.value; dragging = true },
                onSheetDrag = { dy -> dragP = (dragP - dy / (screenPx * 0.7f).coerceAtLeast(1f)).coerceIn(0f, 1f) },
                onSheetEnd = { v ->
                    val target = when {
                        v < -700f -> true
                        v > 700f -> false
                        else -> dragP > 0.5f
                    }
                    sheetScope.launch { prog.snapTo(dragP); showPlayer = target; dragging = false }
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .onSizeChanged { barPx = it.height }
                    .graphicsLayer {
                        // Navigationsleiste tritt langsam in den Hintergrund, wenn der Player aufgeht
                        val o = openF().coerceIn(0f, 1f)
                        alpha = (1f - o * 1.15f).coerceIn(0f, 1f)
                        translationY = o * 48.dp.toPx()
                    }
                    .navigationBarsPadding(),
            )

            // Voller Player: der Hintergrund wächst aus der Mini-Karte, das Cover wandert als eigenes Element mit,
            // die übrigen Inhalte blenden erst am Ende ein (beim Schließen zuerst aus).
            if (overlayVisible) {
                current?.let { s ->
                    Box(
                        Modifier.fillMaxSize().graphicsLayer {
                            val o = openF().coerceIn(0f, 1f)
                            val w = screenW.coerceAtLeast(1).toFloat()
                            val h = screenPx.coerceAtLeast(1).toFloat()
                            val r = miniRect
                            val has = r.width > 1f
                            val l0 = if (has) r.left else w * 0.1f
                            val t0 = if (has) r.top else h * 0.88f
                            val r0 = if (has) r.right else w * 0.9f
                            val b0 = if (has) r.bottom else h * 0.97f
                            val rad = 36.dp.toPx() * ((1f - o) / 0.12f).coerceIn(0f, 1f)
                            shape = RevealShape(l0 * (1f - o), t0 * (1f - o), r0 + (w - r0) * o, b0 + (h - b0) * o, rad)
                            clip = true
                            alpha = (o * 6f).coerceAtMost(1f)
                        },
                    ) {
                        PlayerScreen(
                            song = s,
                            prevSong = ps.prevId?.let { songsById[it] },
                            nextSong = ps.nextId?.let { songsById[it] },
                            state = ps,
                            positionMs = vm.positionMs,
                            lyrics = lyrics,
                            translation = translation,
                            onTranslate = vm::translateLyrics,
                            onClose = { showPlayer = false },
                            onToggle = vm::togglePlay,
                            onNext = vm::next,
                            onPrev = vm::prev,
                            onPrevTrack = vm::previousTrack,
                            onAddToPlaylist = { addSongId = s.id },
                            onSeekFraction = vm::seekFraction,
                            onSeekStart = vm::beginSeek,
                            onSeekEnd = vm::endSeek,
                            onSeekMs = vm::seekToMs,
                            onShuffle = vm::toggleShuffle,
                            onRepeat = vm::cycleRepeat,
                            contentAlpha = { ((openF() - 0.6f) / 0.4f).coerceIn(0f, 1f) },
                            hideCover = { openF() < 0.995f },
                            onCoverBounds = { bigCover = it },
                            songsById = songsById,
                            onPeek = { peek = it },
                            onPlayQueueItem = vm::playQueueItem,
                            onMoveQueue = vm::moveQueueItem,
                            onPull = { dy ->
                                if (!dragging) { dragP = prog.value; dragging = true }
                                val old = dragP
                                dragP = (dragP - dy / (screenPx * 0.7f).coerceAtLeast(1f)).coerceIn(0f, 1f)
                                (old - dragP) * (screenPx * 0.7f).coerceAtLeast(1f)
                            },
                            onPullEnd = { v ->
                                val target = when {
                                    v > 1500f -> false
                                    v < -1500f -> true
                                    else -> dragP > 0.6f
                                }
                                sheetScope.launch { prog.snapTo(dragP); showPlayer = target; dragging = false }
                            },
                        )
                    }

                    // Das Cover als eigenes Element: wächst von der Mini-Position zur Position im großen Player
                    if (floatingVisible && miniCover.width > 1f && bigCover.width > 1f) {
                        val mc = miniCover
                        val bc = bigCover
                        Cover(
                            song = s,
                            px = 900,
                            modifier = Modifier
                                .offset {
                                    val o = openF().coerceIn(0f, 1f)
                                    androidx.compose.ui.unit.IntOffset(
                                        (mc.left + (bc.left - mc.left) * o).toInt(),
                                        (mc.top + (bc.top - mc.top) * o).toInt(),
                                    )
                                }
                                .layout { m, _ ->
                                    val o = openF().coerceIn(0f, 1f)
                                    val wpx = (mc.width + (bc.width - mc.width) * o).toInt().coerceAtLeast(1)
                                    val hpx = (mc.height + (bc.height - mc.height) * o).toInt().coerceAtLeast(1)
                                    val p = m.measure(androidx.compose.ui.unit.Constraints.fixed(wpx, hpx))
                                    layout(wpx, hpx) { p.place(0, 0) }
                                },
                            shape = RoundedCornerShape(14.dp),
                        )
                    }
                }
            }
        }

        // Song zu Playlist(s) hinzufügen (Drei-Punkte-Menü in der Songliste)
        if (addSong != null) {
            AddToPlaylistSheet(
                song = addSong,
                playlists = playlists,
                onToggle = { pid -> vm.toggleSong(pid, addSong.id) },
                onCreate = { name ->
                    val id = vm.createPlaylist(name)
                    vm.toggleSong(id, addSong.id)
                },
                onDismiss = { addSongId = null },
            )
        }
    }
}
