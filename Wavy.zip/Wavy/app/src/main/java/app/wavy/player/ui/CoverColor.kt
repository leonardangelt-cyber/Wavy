package app.wavy.player.ui

import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.ColorUtils
import app.wavy.player.data.CoverLoader
import app.wavy.player.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Ergebnis der Farberkennung: meistgenutzte Farbe (Fläche) und kräftigste Akzentfarbe des Covers. */
data class CoverPalette(val dominant: Int, val accent: Int) {
    /** Grundton für Hintergründe: die Hauptfarbe, bei fast farblosen Covern ein zarter Hauch der Akzentfarbe. */
    val tint: Int
        get() {
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(dominant, hsv)
            if (hsv[1] >= 0.18f && hsv[2] >= 0.20f) return dominant
            val a = FloatArray(3)
            android.graphics.Color.colorToHSV(accent, a)
            return if (a[1] < 0.12f) dominant else android.graphics.Color.HSVToColor(floatArrayOf(a[0], a[1] * 0.5f, a[2]))
        }
}

/**
 * Eigene Farberkennung in vier Schritten:
 * 1. Ränder/Balken (einfarbige oder unscharfe Streifen links/rechts bzw. oben/unten) werden abgeschnitten,
 *    danach zählt nur noch das eigentliche, quadratische Cover.
 * 2. Hauptfarbe: die Farbe, die über die meiste Fläche vorkommt (Schwarz/Weiß/Grau zählen mit).
 * 3. Akzentfarbe: der Farbton, der am kräftigsten und häufigsten vorkommt; steht die Hauptfarbe bunt da,
 *    wird ein Farbton bevorzugt, der sich von ihr abhebt.
 * 4. Beides zusammen färbt die App ein (Hintergründe aus der Hauptfarbe, Knöpfe/Balken aus der Akzentfarbe).
 */
object CoverColor {
    private val cache = ConcurrentHashMap<Long, CoverPalette>()

    fun cached(id: Long): CoverPalette? = cache[id]
    fun put(id: Long, p: CoverPalette) {
        cache[id] = p
    }

    private const val MAXD = 128

    /** Zahl der einfarbigen/ruhigen Randzeilen am Anfang (start=true) bzw. Ende des Bildes. */
    private fun bars(n: Int, mr: FloatArray, mg: FloatArray, mb: FloatArray, vr: FloatArray, start: Boolean): Int {
        val maxTrim = (n * 0.45f).toInt()
        val first = if (start) 0 else n - 1
        var cnt = 0
        while (cnt < maxTrim) {
            val i = if (start) cnt else n - 1 - cnt
            val dr = mr[i] - mr[first]
            val dg = mg[i] - mg[first]
            val db = mb[i] - mb[first]
            val dist = kotlin.math.sqrt(dr * dr + dg * dg + db * db)
            if (vr[i] > 110f || dist > 30f) break
            cnt++
        }
        return if (cnt >= 3) cnt else 0
    }

    fun analyze(src: Bitmap): CoverPalette {
        val sc = MAXD.toFloat() / maxOf(src.width, src.height)
        val w = (src.width * sc).toInt().coerceIn(8, MAXD)
        val h = (src.height * sc).toInt().coerceIn(8, MAXD)
        val bmp = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        // Zeilen-/Spaltenstatistik für die Balkenerkennung
        val cR = FloatArray(w); val cG = FloatArray(w); val cB = FloatArray(w); val cV = FloatArray(w)
        val rR = FloatArray(h); val rG = FloatArray(h); val rB = FloatArray(h); val rV = FloatArray(h)
        val lum = FloatArray(px.size)
        for (y in 0 until h) for (x in 0 until w) {
            val c = px[y * w + x]
            val r = ((c shr 16) and 0xFF).toFloat()
            val g = ((c shr 8) and 0xFF).toFloat()
            val b = (c and 0xFF).toFloat()
            cR[x] += r / h; cG[x] += g / h; cB[x] += b / h
            rR[y] += r / w; rG[y] += g / w; rB[y] += b / w
            lum[y * w + x] = 0.299f * r + 0.587f * g + 0.114f * b
        }
        for (y in 0 until h) for (x in 0 until w) {
            val l = lum[y * w + x]
            val lc = 0.299f * cR[x] + 0.587f * cG[x] + 0.114f * cB[x]
            val lr = 0.299f * rR[y] + 0.587f * rG[y] + 0.114f * rB[y]
            cV[x] += (l - lc) * (l - lc) / h
            rV[y] += (l - lr) * (l - lr) / w
        }
        var left = bars(w, cR, cG, cB, cV, true)
        var right = w - bars(w, cR, cG, cB, cV, false)
        var top = bars(h, rR, rG, rB, rV, true)
        var bottom = h - bars(h, rR, rG, rB, rV, false)
        // Cover sind quadratisch: bleibt der Ausschnitt breiter/höher, wird mittig ein Quadrat genommen
        var cw = right - left
        var ch = bottom - top
        if (cw > ch * 1.25f) {
            val cx = (left + right) / 2
            left = cx - ch / 2; right = left + ch
        } else if (ch > cw * 1.25f) {
            val cy = (top + bottom) / 2
            top = cy - cw / 2; bottom = top + cw
        }
        cw = right - left
        ch = bottom - top
        // kleiner Rand weg (dünne Rahmen/Kanten)
        val insX = (cw * 0.03f).toInt()
        val insY = (ch * 0.03f).toInt()
        left += insX; right -= insX; top += insY; bottom -= insY
        if (right - left < 4 || bottom - top < 4) {
            left = 0; right = w; top = 0; bottom = h
        }

        val hsv = FloatArray(3)
        // Hauptfarbe: grobe Fächer (24 Farbtöne x 3 Sättigungen x 3 Helligkeiten + 4 Graustufen)
        val chromN = 24 * 9
        val cnt = IntArray(chromN + 4)
        val sr = LongArray(chromN + 4)
        val sg = LongArray(chromN + 4)
        val sb = LongArray(chromN + 4)
        // Akzent: Farbtonverteilung (36 Stufen), gewichtet nach Kraft der Farbe
        val hb = FloatArray(36)
        val hs = FloatArray(36)
        val hv = FloatArray(36)
        val hx = DoubleArray(36)
        val hy = DoubleArray(36)
        var total = 0
        var chromW = 0f
        for (y in top until bottom) for (x in left until right) {
            val c = px[y * w + x]
            android.graphics.Color.colorToHSV(c, hsv)
            total++
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val key = if (hsv[1] < 0.15f || hsv[2] < 0.15f) {
                chromN + when {
                    hsv[2] < 0.20f -> 0
                    hsv[2] < 0.50f -> 1
                    hsv[2] < 0.80f -> 2
                    else -> 3
                }
            } else {
                val hbin = (hsv[0] / 15f).toInt().coerceIn(0, 23)
                val sbin = if (hsv[1] < 0.35f) 0 else if (hsv[1] < 0.65f) 1 else 2
                val vbin = if (hsv[2] < 0.40f) 0 else if (hsv[2] < 0.70f) 1 else 2
                hbin * 9 + sbin * 3 + vbin
            }
            cnt[key]++
            sr[key] += r.toLong(); sg[key] += g.toLong(); sb[key] += b.toLong()
            if (hsv[1] >= 0.22f && hsv[2] >= 0.22f) {
                val wgt = Math.pow(hsv[1].toDouble(), 1.3).toFloat() * (0.3f + 0.7f * hsv[2])
                val bin = (hsv[0] / 10f).toInt().coerceIn(0, 35)
                hb[bin] += wgt
                hs[bin] += hsv[1] * wgt
                hv[bin] += hsv[2] * wgt
                val rad = Math.toRadians(hsv[0].toDouble())
                hx[bin] += cos(rad) * wgt
                hy[bin] += sin(rad) * wgt
                chromW += wgt
            }
        }
        if (total == 0) return CoverPalette(0xFF808080.toInt(), 0xFF808080.toInt())

        // Hauptfarbe wählen (mit Nachbar-Farbtönen zusammengefasst)
        var bestKey = 0
        var bestCnt = -1
        for (k in 0 until chromN + 4) {
            var c = cnt[k]
            if (k < chromN) {
                val hbin = k / 9
                val rest = k % 9
                c += cnt[((hbin + 1) % 24) * 9 + rest] / 2 + cnt[((hbin + 23) % 24) * 9 + rest] / 2
            }
            if (c > bestCnt) { bestCnt = c; bestKey = k }
        }
        var dR = sr[bestKey]; var dG = sg[bestKey]; var dB = sb[bestKey]; var dN = cnt[bestKey].toLong()
        if (bestKey < chromN) {
            val hbin = bestKey / 9
            val rest = bestKey % 9
            for (nb in intArrayOf(((hbin + 1) % 24) * 9 + rest, ((hbin + 23) % 24) * 9 + rest)) {
                dR += sr[nb]; dG += sg[nb]; dB += sb[nb]; dN += cnt[nb]
            }
        }
        val dominant = if (dN > 0) android.graphics.Color.rgb((dR / dN).toInt(), (dG / dN).toInt(), (dB / dN).toInt()) else 0xFF808080.toInt()
        android.graphics.Color.colorToHSV(dominant, hsv)
        val domChromatic = hsv[1] >= 0.18f && hsv[2] >= 0.20f
        val domHue = hsv[0]

        // Akzentfarbe wählen
        if (chromW < total * 0.012f) return CoverPalette(dominant, dominant)
        var best = 0
        var bestScore = -1f
        for (k in 0 until 36) {
            var score = hb[(k + 35) % 36] + hb[k] * 1.5f + hb[(k + 1) % 36]
            if (domChromatic) {
                val centre = k * 10f + 5f
                val d = kotlin.math.abs(((centre - domHue + 540f) % 360f) - 180f)
                val dist = 180f - d
                score *= 1f + 0.6f * minOf(1f, dist / 80f)
            }
            if (score > bestScore) { bestScore = score; best = k }
        }
        var x = 0.0
        var y = 0.0
        var wsum = 0f
        var ssum = 0f
        var vsum = 0f
        for (k in intArrayOf((best + 35) % 36, best, (best + 1) % 36)) {
            x += hx[k]; y += hy[k]; wsum += hb[k]; ssum += hs[k]; vsum += hv[k]
        }
        if (wsum <= 0f) return CoverPalette(dominant, dominant)
        var hue = Math.toDegrees(atan2(y, x)).toFloat()
        if (hue < 0) hue += 360f
        val accent = android.graphics.Color.HSVToColor(
            floatArrayOf(hue, (ssum / wsum).coerceIn(0.25f, 1f), (vsum / wsum).coerceIn(0.40f, 1f)),
        )
        return CoverPalette(dominant, accent)
    }
}

/** Kachelfarben: Hintergrund aus der Hauptfarbe des Covers, kräftige Stellen aus der Akzentfarbe. */
object CoverTone {
    private fun hs(c: Int): Pair<Float, Float> {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(c, hsl)
        return hsl[0] to hsl[1]
    }

    fun container(p: CoverPalette, dark: Boolean): Color {
        val (h, s) = hs(p.tint)
        return if (dark) tone(h, (s * 0.7f).coerceIn(0.05f, 0.6f), 0.20f)
        else tone(h, (s + 0.1f).coerceIn(0.08f, 0.92f), 0.88f)
    }

    fun onContainer(p: CoverPalette, dark: Boolean): Color {
        val (h, s) = hs(p.tint)
        return if (dark) tone(h, (s * 0.6f).coerceIn(0.05f, 0.6f), 0.92f)
        else tone(h, s.coerceIn(0.05f, 0.9f), 0.14f)
    }

    fun strong(p: CoverPalette, dark: Boolean): Color {
        val (h, s) = hs(p.accent)
        val sat = s.coerceIn(0.05f, 0.85f)
        return if (dark) tone(h, sat, 0.62f) else tone(h, sat, 0.40f)
    }
}

@Composable
fun rememberCoverSeed(song: Song): CoverPalette? {
    val ctx = LocalContext.current
    var seed by remember(song.id) { mutableStateOf(CoverColor.cached(song.id)) }
    LaunchedEffect(song.id) {
        if (seed == null) {
            val bmp = CoverLoader.cached(song, 160) ?: CoverLoader.load(ctx, song, 160)
            if (bmp != null) {
                val c = withContext(Dispatchers.Default) { CoverColor.analyze(bmp) }
                CoverColor.put(song.id, c)
                seed = c
            }
        }
    }
    return seed
}
