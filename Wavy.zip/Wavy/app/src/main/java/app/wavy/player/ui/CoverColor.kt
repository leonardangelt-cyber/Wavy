package app.wavy.player.ui

import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.ColorUtils
import app.wavy.player.data.CoverLoader
import app.wavy.player.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Eigene Farberkennung: zählt über das ganze Cover, welcher Farbton (stufenlos, 36 Stufen mit Glättung)
 * am stärksten vorkommt. Graues/Schwarzes/Weißes zählt kaum, kräftige Farben zählen mehr.
 * Ist das Cover fast farblos, kommt eine neutrale Farbe heraus.
 */
object CoverColor {
    private val cache = ConcurrentHashMap<Long, Int>()

    fun cached(id: Long): Int? = cache[id]
    fun put(id: Long, color: Int) {
        cache[id] = color
    }

    fun seedOf(src: Bitmap): Int {
        val n = 56
        val small = Bitmap.createScaledBitmap(src, n, n, true)
        val px = IntArray(n * n)
        small.getPixels(px, 0, n, 0, 0, n, n)
        val hsv = FloatArray(3)
        val hue = FloatArray(px.size)
        val sat = FloatArray(px.size)
        val value = FloatArray(px.size)
        val weight = FloatArray(px.size)
        val bins = FloatArray(36)
        var chroma = 0f
        var r = 0L
        var g = 0L
        var b = 0L
        for (i in px.indices) {
            val c = px[i]
            r += (c shr 16) and 0xFF
            g += (c shr 8) and 0xFF
            b += c and 0xFF
            android.graphics.Color.colorToHSV(c, hsv)
            hue[i] = hsv[0]
            sat[i] = hsv[1]
            value[i] = hsv[2]
            val w = if (hsv[1] < 0.15f || hsv[2] < 0.15f) 0f else hsv[1] * (0.4f + 0.6f * hsv[2])
            weight[i] = w
            bins[(hsv[0] / 10f).toInt().coerceIn(0, 35)] += w
            chroma += w
        }
        val total = px.size
        if (chroma < total * 0.04f) {
            return android.graphics.Color.rgb((r / total).toInt(), (g / total).toInt(), (b / total).toInt())
        }
        var best = 0
        var bestScore = -1f
        for (k in 0 until 36) {
            val score = bins[(k + 35) % 36] + bins[k] * 1.5f + bins[(k + 1) % 36]
            if (score > bestScore) {
                bestScore = score
                best = k
            }
        }
        var x = 0.0
        var y = 0.0
        var sSum = 0f
        var vSum = 0f
        var wSum = 0f
        for (i in px.indices) {
            val w = weight[i]
            if (w <= 0f) continue
            val bin = (hue[i] / 10f).toInt().coerceIn(0, 35)
            val d = minOf((bin - best + 36) % 36, (best - bin + 36) % 36)
            if (d > 1) continue
            val rad = Math.toRadians(hue[i].toDouble())
            x += cos(rad) * w
            y += sin(rad) * w
            sSum += sat[i] * w
            vSum += value[i] * w
            wSum += w
        }
        if (wSum <= 0f) return android.graphics.Color.rgb((r / total).toInt(), (g / total).toInt(), (b / total).toInt())
        var h = Math.toDegrees(atan2(y, x)).toFloat()
        if (h < 0) h += 360f
        return android.graphics.Color.HSVToColor(floatArrayOf(h, (sSum / wSum).coerceIn(0.2f, 1f), (vSum / wSum).coerceIn(0.35f, 1f)))
    }
}

/** Kachelfarben, die exakt aus der Cover-Farbe abgeleitet werden. */
object CoverTone {
    private fun hs(seed: Int): Pair<Float, Float> {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(seed, hsl)
        return hsl[0] to hsl[1]
    }

    fun container(seed: Int, dark: Boolean): Color {
        val (h, s) = hs(seed)
        return if (dark) tone(h, (s * 0.7f).coerceIn(0.05f, 0.6f), 0.20f)
        else tone(h, (s + 0.1f).coerceIn(0.08f, 0.92f), 0.88f)
    }

    fun onContainer(seed: Int, dark: Boolean): Color {
        val (h, s) = hs(seed)
        return if (dark) tone(h, (s * 0.6f).coerceIn(0.05f, 0.6f), 0.92f)
        else tone(h, s.coerceIn(0.05f, 0.9f), 0.14f)
    }

    fun strong(seed: Int, dark: Boolean): Color {
        val (h, s) = hs(seed)
        val sat = s.coerceIn(0.05f, 0.85f)
        return if (dark) tone(h, sat, 0.62f) else tone(h, sat, 0.40f)
    }
}

@Composable
fun rememberCoverSeed(song: Song): Int? {
    val ctx = LocalContext.current
    var seed by remember(song.id) { mutableStateOf(CoverColor.cached(song.id)) }
    LaunchedEffect(song.id) {
        if (seed == null) {
            val bmp = CoverLoader.cached(song, 160) ?: CoverLoader.load(ctx, song, 160)
            if (bmp != null) {
                val c = withContext(Dispatchers.Default) { CoverColor.seedOf(bmp) }
                CoverColor.put(song.id, c)
                seed = c
            }
        }
    }
    return seed
}
