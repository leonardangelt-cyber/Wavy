package app.wavy.player.ui

import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.ColorUtils
import app.wavy.player.data.CoverLoader
import app.wavy.player.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Ergebnis der Farberkennung: meistgenutzte Farbe (Fläche) und kräftigste Akzentfarbe des Covers. */
data class CoverPalette(val dominant: Int, val accent: Int) {
    /** Grundton für Hintergründe: die Hauptfarbe, bei fast farblosen Covern ein zarter Hauch der Akzentfarbe. */
    val tint: Int
        get() {
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(dominant, hsv)
            if (hsv[1] >= 0.18f && hsv[2] >= 0.20f) return dominant
            val a = FloatArray(3)
            android.graphics.Color.colorToHSV(accent, a)
            return if (a[1] < 0.12f) dominant else android.graphics.Color.HSVToColor(floatArrayOf(a[0], a[1] * 0.5f, a[2]))
        }
}

/**
 * Eigene Farberkennung in vier Schritten:
 * 1. Ränder/Balken (einfarbige oder unscharfe Streifen links/rechts bzw. oben/unten) werden abgeschnitten,
 *    danach zählt nur noch das eigentliche, quadratische Cover.
 * 2. Hauptfarbe: die Farbe, die über die meiste Fläche vorkommt (Schwarz/Weiß/Grau zählen mit).
 * 3. Akzentfarbe: der Farbton, der am kräftigsten und häufigsten vorkommt; steht die Hauptfarbe bunt da,
 *    wird ein Farbton bevorzugt, der sich von ihr abhebt.
 * 4. Beides zusammen färbt die App ein (Hintergründe aus der Hauptfarbe, Knöpfe/Balken aus der Akzentfarbe).
 */
object CoverColor {
    private val cache = ConcurrentHashMap<Long, CoverPalette>()

    fun cached(id: Long): CoverPalette? = cache[id]
    fun put(id: Long, p: CoverPalette) {
        cache[id] = p
    }

    private const val MAXD = 128

    /** Zahl der einfarbigen/ruhigen Randzeilen am Anfang (start=true) bzw. Ende des Bildes. */
    private fun bars(n: Int, mr: FloatArray, mg: FloatArray, mb: FloatArray, vr: FloatArray, start: Boolean): Int {
        val maxTrim = (n * 0.45f).toInt()
        val first = if (start) 0 else n - 1
        var cnt = 0
        while (cnt < maxTrim) {
            val i = if (start) cnt else n - 1 - cnt
            val dr = mr[i] - mr[first]
            val dg = mg[i] - mg[first]
            val db = mb[i] - mb[first]
            val dist = kotlin.math.sqrt(dr * dr + dg * dg + db * db)
            if (vr[i] > 110f || dist > 30f) break
            cnt++
        }
        return if (cnt >= 3) cnt else 0
    }

    fun analyze(src: Bitmap): CoverPalette {
        val sc = MAXD.toFloat() / maxOf(src.width, src.height)
        val w = (src.width * sc).toInt().coerceIn(8, MAXD)
        val h = (src.height * sc).toInt().coerceIn(8, MAXD)
        val bmp = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        // Zeilen-/Spaltenstatistik für die Balkenerkennung
        val cR = FloatArray(w); val cG = FloatArray(w); val cB = FloatArray(w); val cV = FloatArray(w)
        val rR = FloatArray(h); val rG = FloatArray(h); val rB = FloatArray(h); val rV = FloatArray(h)
        val lum = FloatArray(px.size)
        for (y in 0 until h) for (x in 0 until w) {
            val c = px[y * w + x]
            val r = ((c shr 16) and 0xFF).toFloat()
            val g = ((c shr 8) and 0xFF).toFloat()
            val b = (c and 0xFF).toFloat()
            cR[x] += r / h; cG[x] += g / h; cB[x] += b / h
            rR[y] += r / w; rG[y] += g / w; rB[y] += b / w
            lum[y * w + x] = 0.299f * r + 0.587f * g + 0.114f * b
        }
        for (y in 0 until h) for (x in 0 until w) {
            val l = lum[y * w + x]
            val lc = 0.299f * cR[x] + 0.587f * cG[x] + 0.114f * cB[x]
            val lr = 0.299f * rR[y] + 0.587f * rG[y] + 0.114f * rB[y]
            cV[x] += (l - lc) * (l - lc) / h
            rV[y] += (l - lr) * (l - lr) / w
        }
        var left = bars(w, cR, cG, cB, cV, true)
        var right = w - bars(w, cR, cG, cB, cV, false)
        var top = bars(h, rR, rG, rB, rV, true)
        var bottom = h - bars(h, rR, rG, rB, rV, false)
        // Cover sind quadratisch: bleibt der Ausschnitt breiter/höher, wird mittig ein Quadrat genommen
        var cw = right - left
        var ch = bottom - top
        if (cw > ch * 1.25f) {
            val cx = (left + right) / 2
            left = cx - ch / 2; right = left + ch
        } else if (ch > cw * 1.25f) {
            val cy = (top + bottom) / 2
            top = cy - cw / 2; bottom = top + cw
        }
        cw = right - left
        ch = bottom - top
        // kleiner Rand weg (dünne Rahmen/Kanten)
        val insX = (cw * 0.03f).toInt()
        val insY = (ch * 0.03f).toInt()
        left += insX; right -= insX; top += insY; bottom -= insY
        if (right - left < 4 || bottom - top < 4) {
            left = 0; right = w; top = 0; bottom = h
        }

        return cluster(px, w, left, right, top, bottom)
    }

    private val lin = FloatArray(256) { i ->
        val c = i / 255f
        if (c <= 0.04045f) c / 12.92f else Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    }

    /** sRGB -> OKLab (wahrnehmungsgleich: gleiche Abstände = gleich sichtbare Unterschiede) */
    private fun oklab(c: Int, out: FloatArray) {
        val r = lin[(c shr 16) and 0xFF]
        val g = lin[(c shr 8) and 0xFF]
        val b = lin[c and 0xFF]
        val l = Math.cbrt((0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b).toDouble()).toFloat()
        val m = Math.cbrt((0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b).toDouble()).toFloat()
        val s = Math.cbrt((0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b).toDouble()).toFloat()
        out[0] = 0.2104542553f * l + 0.7936177850f * m - 0.0040720468f * s
        out[1] = 1.9779984951f * l - 2.4285922050f * m + 0.4505937099f * s
        out[2] = 0.0259040371f * l + 0.7827717662f * m - 0.8086757660f * s
    }

    /**
     * Farberkennung per Clusteranalyse (k-Means) im OKLab-Farbraum:
     * - Pixel in der Bildmitte zählen etwas mehr als am Rand,
     * - ähnliche Cluster werden zusammengelegt,
     * - Hauptfarbe = die Farbgruppe mit der größten Fläche,
     * - Akzentfarbe = die Gruppe mit der besten Mischung aus Kraft (Sättigung), Fläche und Abstand zur Hauptfarbe.
     */
    private fun cluster(px: IntArray, w: Int, left: Int, right: Int, top: Int, bottom: Int): CoverPalette {
        val cw = right - left
        val ch = bottom - top
        val step = maxOf(1, maxOf(cw, ch) / 64)
        val n0 = ((cw + step - 1) / step) * ((ch + step - 1) / step)
        val L = FloatArray(n0); val A = FloatArray(n0); val B = FloatArray(n0)
        val W = FloatArray(n0); val col = IntArray(n0)
        var n = 0
        val tmp = FloatArray(3)
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val c = px[y * w + x]
                oklab(c, tmp)
                val dx = ((x - left) / cw.toFloat() - 0.5f) * 2f
                val dy = ((y - top) / ch.toFloat() - 0.5f) * 2f
                L[n] = tmp[0]; A[n] = tmp[1]; B[n] = tmp[2]
                W[n] = 1f - 0.35f * minOf(1f, dx * dx + dy * dy)
                col[n] = c
                n++
                x += step
            }
            y += step
        }
        if (n == 0) return CoverPalette(0xFF808080.toInt(), 0xFF808080.toInt())

        val k = minOf(10, n)
        val cl = FloatArray(k); val ca = FloatArray(k); val cb = FloatArray(k)
        // Startpunkte: immer das Pixel, das den bisherigen Mittelpunkten am fernsten ist
        val first = n / 2
        cl[0] = L[first]; ca[0] = A[first]; cb[0] = B[first]
        val dmin = FloatArray(n) { Float.MAX_VALUE }
        for (j in 1 until k) {
            var far = 0
            var fd = -1f
            for (i in 0 until n) {
                val dl = L[i] - cl[j - 1]; val da = A[i] - ca[j - 1]; val db = B[i] - cb[j - 1]
                val d = dl * dl + da * da + db * db
                if (d < dmin[i]) dmin[i] = d
                if (dmin[i] > fd) { fd = dmin[i]; far = i }
            }
            cl[j] = L[far]; ca[j] = A[far]; cb[j] = B[far]
        }
        val assign = IntArray(n)
        repeat(10) {
            val sl = FloatArray(k); val sa = FloatArray(k); val sb = FloatArray(k); val sw = FloatArray(k)
            for (i in 0 until n) {
                var bj = 0
                var bd = Float.MAX_VALUE
                for (j in 0 until k) {
                    val dl = L[i] - cl[j]; val da = A[i] - ca[j]; val db = B[i] - cb[j]
                    val d = dl * dl + da * da + db * db
                    if (d < bd) { bd = d; bj = j }
                }
                assign[i] = bj
                sl[bj] += L[i] * W[i]; sa[bj] += A[i] * W[i]; sb[bj] += B[i] * W[i]; sw[bj] += W[i]
            }
            for (j in 0 until k) if (sw[j] > 0f) { cl[j] = sl[j] / sw[j]; ca[j] = sa[j] / sw[j]; cb[j] = sb[j] / sw[j] }
        }
        // Gruppen sammeln
        class G(var l: Float, var a: Float, var b: Float, var mass: Float, var r: Float, var g: Float, var bl: Float)
        val groups = ArrayList<G>()
        for (j in 0 until k) {
            var mass = 0f; var r = 0f; var g = 0f; var bl = 0f
            for (i in 0 until n) if (assign[i] == j) {
                mass += W[i]
                r += ((col[i] shr 16) and 0xFF) * W[i]
                g += ((col[i] shr 8) and 0xFF) * W[i]
                bl += (col[i] and 0xFF) * W[i]
            }
            if (mass > 0f) groups.add(G(cl[j], ca[j], cb[j], mass, r, g, bl))
        }
        // ähnliche Gruppen zusammenlegen
        var merged = true
        while (merged && groups.size > 1) {
            merged = false
            loop@ for (i in 0 until groups.size) for (j in i + 1 until groups.size) {
                val gi = groups[i]; val gj = groups[j]
                val dl = gi.l - gj.l; val da = gi.a - gj.a; val db = gi.b - gj.b
                if (dl * dl + da * da + db * db < 0.05f * 0.05f) {
                    val m = gi.mass + gj.mass
                    gi.l = (gi.l * gi.mass + gj.l * gj.mass) / m
                    gi.a = (gi.a * gi.mass + gj.a * gj.mass) / m
                    gi.b = (gi.b * gi.mass + gj.b * gj.mass) / m
                    gi.r += gj.r; gi.g += gj.g; gi.bl += gj.bl; gi.mass = m
                    groups.removeAt(j)
                    merged = true
                    break@loop
                }
            }
        }
        val total = groups.sumOf { it.mass.toDouble() }.toFloat()
        fun colorOf(g: G) = android.graphics.Color.rgb(
            (g.r / g.mass).toInt().coerceIn(0, 255), (g.g / g.mass).toInt().coerceIn(0, 255), (g.bl / g.mass).toInt().coerceIn(0, 255),
        )
        fun chroma(g: G) = kotlin.math.sqrt(g.a * g.a + g.b * g.b)

        val dom = groups.maxByOrNull { it.mass }!!
        val dominant = colorOf(dom)
        val domChroma = chroma(dom)

        // Akzent: kräftig, nicht winzig, möglichst anders als die Hauptfarbe
        var accentG: G? = null
        var best = 0f
        for (g in groups) {
            val c = chroma(g)
            val frac = g.mass / total
            if (c < 0.05f || frac < 0.012f || g.l < 0.22f || g.l > 0.97f) continue
            var score = Math.pow(frac.toDouble(), 0.45).toFloat() * Math.pow(c.toDouble(), 1.3).toFloat()
            if (domChroma >= 0.06f && g !== dom) {
                val dl = g.l - dom.l; val da = g.a - dom.a; val db = g.b - dom.b
                val dist = kotlin.math.sqrt(dl * dl + da * da + db * db)
                score *= 1f + 1.2f * minOf(1f, dist / 0.30f)
            } else if (g === dom) {
                score *= 0.9f
            }
            if (score > best) { best = score; accentG = g }
        }
        val ag = accentG ?: return CoverPalette(dominant, dominant)
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(colorOf(ag), hsv)
        hsv[1] = hsv[1].coerceIn(0.25f, 1f)
        hsv[2] = hsv[2].coerceIn(0.40f, 1f)
        return CoverPalette(dominant, android.graphics.Color.HSVToColor(hsv))
    }
}

/** Kachelfarben: Hintergrund aus der Hauptfarbe des Covers, kräftige Stellen aus der Akzentfarbe. */
object CoverTone {
    private fun hs(c: Int): Pair<Float, Float> {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(c, hsl)
        return hsl[0] to hsl[1]
    }

    fun container(p: CoverPalette, dark: Boolean): Color {
        val (h, s) = hs(p.tint)
        return if (dark) tone(h, (s * 0.7f).coerceIn(0.05f, 0.6f), 0.20f)
        else tone(h, (s + 0.1f).coerceIn(0.08f, 0.92f), 0.88f)
    }

    fun onContainer(p: CoverPalette, dark: Boolean): Color {
        val (h, s) = hs(p.tint)
        return if (dark) tone(h, (s * 0.6f).coerceIn(0.05f, 0.6f), 0.92f)
        else tone(h, s.coerceIn(0.05f, 0.9f), 0.14f)
    }

    fun strong(p: CoverPalette, dark: Boolean): Color {
        val (h, s) = hs(p.accent)
        val sat = s.coerceIn(0.05f, 0.85f)
        return if (dark) tone(h, sat, 0.62f) else tone(h, sat, 0.40f)
    }
}

@Composable
fun rememberCoverSeed(song: Song): CoverPalette? {
    val ctx = LocalContext.current
    var seed by remember(song.id) { mutableStateOf(CoverColor.cached(song.id)) }
    LaunchedEffect(song.id) {
        if (seed == null) {
            val bmp = CoverLoader.cached(song, 160) ?: CoverLoader.load(ctx, song, 160)
            if (bmp != null) {
                val c = withContext(Dispatchers.Default) { CoverColor.analyze(bmp) }
                CoverColor.put(song.id, c)
                seed = c
            }
        }
    }
    return seed
}
