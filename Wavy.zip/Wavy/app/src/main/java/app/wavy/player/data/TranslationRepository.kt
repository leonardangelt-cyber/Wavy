package app.wavy.player.data

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale

object Provider {
    const val GEMINI = "gemini"
    const val CLOUD = "cloud"
}

enum class KeyState { None, Checking, Ok, Bad, Offline }

/** Ergebnis der Schlüsselprüfung für die Einstellungen. */
data class KeyStatus(
    val state: KeyState = KeyState.None,
    val title: String = "",
    val detail: String = "",
    val model: String = "",
    val models: List<String> = emptyList(),
)

/** Paketname und SHA-1 der App-Signatur (nötig, wenn der API-Schlüssel auf Android-Apps eingeschränkt ist). */
object AppSig {
    fun sha1(ctx: Context): String = try {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        val sig = info.signingInfo?.apkContentsSigners?.firstOrNull()
        if (sig == null) "" else MessageDigest.getInstance("SHA-1").digest(sig.toByteArray())
            .joinToString("") { "%02X".format(it) }
    } catch (_: Exception) {
        ""
    }
}

/**
 * Übersetzt Songtexte – entweder mit Google Gemini (KI) oder mit Google Cloud Translation.
 * Sparsam: nur auf Knopfdruck, jede einzigartige Zeile nur einmal, Ergebnis wird gespeichert,
 * Monatslimit wird vor jeder Anfrage geprüft.
 */
class TranslationRepository(ctx: Context, private val settings: SettingsStore) {

    private val dir = File(ctx.filesDir, "translations").apply { mkdirs() }
    private val pkg = ctx.packageName
    private val sha = AppSig.sha1(ctx)

    private fun file(song: Song, lang: String) = File(dir, "${song.id}_$lang.json")

    /** Gespeichertes Ergebnis (kostet nichts) oder null. */
    fun cached(song: Song, lang: String): TranslationUi? {
        val f = file(song, lang)
        if (!f.exists()) return null
        return try {
            val o = JSONObject(f.readText())
            if (o.optBoolean("same")) {
                TranslationUi(TranslationStatus.Same, message = "Der Songtext ist schon in deiner Sprache.")
            } else {
                val m = o.getJSONObject("map")
                val map = HashMap<String, String>()
                m.keys().forEach { map[it] = m.getString(it) }
                TranslationUi(TranslationStatus.Done, map)
            }
        } catch (_: Exception) {
            null
        }
    }

    // ---------- HTTP ----------

    private class Resp(val code: Int, val body: String)

    private fun call(method: String, url: String, key: String, body: String? = null): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 10_000
            c.readTimeout = 60_000
            c.setRequestProperty("x-goog-api-key", key)
            // Für Schlüssel, die auf "Android-Apps" eingeschränkt sind
            c.setRequestProperty("X-Android-Package", pkg)
            if (sha.isNotBlank()) c.setRequestProperty("X-Android-Cert", sha)
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            return Resp(code, text)
        } finally {
            c.disconnect()
        }
    }

    private fun googleMsg(body: String): String = try {
        JSONObject(body).getJSONObject("error").optString("message")
    } catch (_: Exception) {
        ""
    }

    /** Verständliche Erklärung (Titel, Details) zu einem HTTP-Fehler. */
    private fun explain(code: Int, body: String, provider: String): Pair<String, String> {
        val msg = googleMsg(body)
        val low = msg.lowercase(Locale.ROOT)
        val gem = provider == Provider.GEMINI
        val (title, hint) = when {
            code == 400 && ("api key not valid" in low || "api_key_invalid" in body.lowercase(Locale.ROOT)) ->
                "Schlüssel ungültig (400)" to "Google kennt diesen Schlüssel nicht. Kopiere ihn noch einmal komplett, ohne Leerzeichen."
            code == 400 && "location" in low ->
                "Region nicht unterstützt (400)" to "Dieser Dienst ist in deiner Region für diesen Schlüssel nicht freigeschaltet."
            code == 400 -> "Anfrage abgelehnt (400)" to "Google hat die Anfrage nicht akzeptiert."
            code == 401 -> "Schlüssel nicht akzeptiert (401)" to
                (if (gem) "Meist ist es kein Gemini-Schlüssel oder er ist eingeschränkt. Erstelle einen Schlüssel in Google AI Studio (aistudio.google.com → „API-Schlüssel erstellen“), " +
                    "oder setze bei deinem Schlüssel die Einschränkung auf „Keine“ bzw. auf „Android-Apps“ mit der Kennung unten."
                else "Der Schlüssel ist nicht für Cloud Translation gültig oder eingeschränkt. Nimm einen Schlüssel aus der Google Cloud Console (APIs & Dienste → Anmeldedaten) " +
                    "und setze die Einschränkung auf „Keine“ bzw. auf „Android-Apps“ mit der Kennung unten.")
            code == 403 -> "Zugriff verweigert (403)" to
                (if (gem) "Der Schlüssel darf die Gemini-API nicht nutzen (API nicht aktiviert oder durch eine Einschränkung blockiert)."
                else "Aktiviere im Google-Cloud-Projekt die „Cloud Translation API“ und prüfe, dass die Abrechnung eingerichtet und der Schlüssel nicht blockiert ist.")
            code == 404 -> "Nicht gefunden (404)" to "Das gewählte Modell gibt es nicht (mehr). Wähle in den Einstellungen „Automatisch“."
            code == 429 -> "Kontingent erreicht (429)" to "Zu viele Anfragen oder das Gratis-Kontingent ist aufgebraucht. Versuche es später noch einmal."
            code >= 500 -> "Google-Server-Fehler ($code)" to "Das liegt bei Google. Versuche es in ein paar Minuten noch einmal."
            else -> "Fehler $code" to "Unerwartete Antwort von Google."
        }
        val extra = if (msg.isNotBlank()) " Google sagt: „${msg.take(220)}“" else ""
        return title to hint + extra
    }

    // ---------- Schlüsselprüfung ----------

    suspend fun checkKey(provider: String, key: String, pref: String): KeyStatus = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext KeyStatus(KeyState.None, "Noch kein Schlüssel gespeichert")
        try {
            if (provider == Provider.CLOUD) checkCloud(key) else checkGemini(key, pref)
        } catch (_: Exception) {
            KeyStatus(KeyState.Offline, "Keine Verbindung", "Google ist gerade nicht erreichbar. Prüfe dein Internet und tippe auf „Erneut prüfen“.")
        }
    }

    private fun checkCloud(key: String): KeyStatus {
        val body = JSONObject().put("q", JSONArray(listOf("Hallo"))).put("target", "en").put("format", "text").toString()
        val r = call("POST", "https://translation.googleapis.com/language/translate/v2", key, body)
        if (r.code !in 200..299) {
            val (t, d) = explain(r.code, r.body, Provider.CLOUD)
            return KeyStatus(KeyState.Bad, t, d)
        }
        return KeyStatus(
            KeyState.Ok,
            "Schlüssel funktioniert",
            "Wavy nutzt Google Cloud Translation (neuronale Übersetzung, kein KI-Chatmodell).",
            model = "Cloud Translation v2",
        )
    }

    private fun usable(name: String): Boolean {
        if (!name.startsWith("gemini-")) return false
        return listOf("tts", "image", "audio", "live", "embedding", "robotics", "computer", "vision").none { it in name }
    }

    private fun score(name: String): Int {
        var s = when {
            "flash-lite" in name -> 30
            "flash" in name -> 20
            "pro" in name -> 5
            else -> 0
        }
        if ("preview" in name || "exp" in name) s -= 3
        return s
    }

    private fun checkGemini(key: String, pref: String): KeyStatus {
        val r = call("GET", "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", key)
        if (r.code !in 200..299) {
            val (t, d) = explain(r.code, r.body, Provider.GEMINI)
            return KeyStatus(KeyState.Bad, t, d)
        }
        val arr = JSONObject(r.body).optJSONArray("models") ?: JSONArray()
        val names = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("name").removePrefix("models/")
            val methods = o.optJSONArray("supportedGenerationMethods")
            var gen = false
            if (methods != null) for (j in 0 until methods.length()) if (methods.optString(j) == "generateContent") gen = true
            if (gen && usable(name)) names += name
        }
        if (names.isEmpty()) {
            return KeyStatus(KeyState.Bad, "Kein Modell verfügbar", "Der Schlüssel wird erkannt, aber Google meldet kein nutzbares Gemini-Modell dafür.")
        }
        val sorted = names.sortedWith(compareByDescending<String> { score(it) }.thenByDescending { it })
        val chosen = if (pref.isNotBlank() && pref in names) pref else sorted.first()
        settings.setResolvedModel(chosen)
        return KeyStatus(
            KeyState.Ok,
            "Schlüssel funktioniert",
            "Zum Übersetzen nutzt Wavy das KI-Modell $chosen (Google Gemini).",
            model = chosen,
            models = sorted.take(8),
        )
    }

    // ---------- Übersetzen ----------

    suspend fun translate(song: Song, lines: List<String>, lang: String): TranslationUi = withContext(Dispatchers.IO) {
        cached(song, lang)?.let { return@withContext it }

        val key = settings.apiKey.value
        if (key.isBlank()) {
            return@withContext err("Trage zuerst in den Einstellungen deinen Google-API-Schlüssel ein.")
        }
        val unique = lines.map { it.trim() }
            .filter { line -> line.isNotBlank() && line.any { it.isLetter() } }
            .distinct()
        if (unique.isEmpty()) return@withContext err("Keine Textzeilen zum Übersetzen gefunden.")

        settings.refresh()
        val total = unique.sumOf { it.length }
        val used = settings.usedChars.value
        val limit = settings.monthlyLimit.value
        if (used + total > limit) {
            return@withContext err(
                "Monatslimit würde überschritten (Verbrauch $used + dieser Song $total von $limit Zeichen). " +
                    "Du kannst das Limit in den Einstellungen erhöhen.",
            )
        }

        val provider = settings.provider.value
        var model = ""
        if (provider == Provider.GEMINI) {
            model = settings.model.value.ifBlank { settings.resolvedModel.value }
            if (model.isBlank()) {
                val st = try {
                    checkGemini(key, "")
                } catch (_: Exception) {
                    return@withContext err("Keine Internetverbindung. Versuche es später noch einmal.")
                }
                if (st.state != KeyState.Ok) return@withContext err("${st.title}. ${st.detail}")
                model = st.model
            }
        }

        val result = LinkedHashMap<String, String>()
        var sameCount = 0
        var checked = 0
        var i = 0
        while (i < unique.size) {
            val chunk = ArrayList<String>()
            var chars = 0
            while (i < unique.size && chunk.size < 100 && chars + unique[i].length <= 8_000) {
                chunk += unique[i]
                chars += unique[i].length
                i++
            }
            if (chunk.isEmpty()) { // einzelne Zeile ist zu lang – überspringen
                i++
                continue
            }
            val r = try {
                if (provider == Provider.CLOUD) postCloud(key, chunk, lang) else postGemini(key, model, chunk, lang)
            } catch (_: Exception) {
                Post.Fail("Keine Internetverbindung. Versuche es später noch einmal.")
            }
            when (r) {
                is Post.Fail -> return@withContext err(r.message)
                is Post.Ok -> {
                    settings.addUsage(chars)
                    chunk.forEachIndexed { idx, orig ->
                        val t = r.items.getOrNull(idx) ?: return@forEachIndexed
                        result[orig] = t.first
                        checked++
                        if (t.second.substringBefore('-').equals(lang, ignoreCase = true)) sameCount++
                    }
                }
            }
        }

        val same = checked > 0 && sameCount * 10 >= checked * 7
        try {
            val o = JSONObject().put("same", same)
            val m = JSONObject()
            if (!same) result.forEach { (k, v) -> m.put(k, v) }
            o.put("map", m)
            file(song, lang).writeText(o.toString())
        } catch (_: Exception) {
        }
        if (same) {
            TranslationUi(TranslationStatus.Same, message = "Der Songtext ist schon in deiner Sprache.")
        } else {
            TranslationUi(TranslationStatus.Done, result)
        }
    }

    // ---------- KI-Playlist ----------

    data class AiPlaylist(val name: String = "", val ids: List<Long> = emptyList(), val error: String? = null)

    /** Lässt Gemini aus der eigenen Bibliothek passende Songs zu einer Beschreibung auswählen. */
    suspend fun suggestPlaylist(request: String, songs: List<Song>): AiPlaylist = withContext(Dispatchers.IO) {
        val key = settings.apiKey.value
        if (key.isBlank()) return@withContext AiPlaylist(error = "Trage zuerst in den Einstellungen deinen Google-API-Schlüssel ein.")
        if (settings.provider.value != Provider.GEMINI) {
            return@withContext AiPlaylist(error = "KI-Playlists brauchen Gemini. Stelle in den Einstellungen unter Übersetzung „Gemini“ ein.")
        }
        val model = settings.model.value.ifBlank { settings.resolvedModel.value }
        if (model.isBlank()) return@withContext AiPlaylist(error = "Prüfe zuerst in den Einstellungen deinen Schlüssel.")
        val pool = songs.take(700)
        if (pool.isEmpty()) return@withContext AiPlaylist(error = "Keine Songs gefunden.")
        val lib = pool.joinToString("\n") { "${it.id}|${it.title}|${it.artistLabel}" }
        val prompt = "You curate playlists from a user's personal music library. Request: \"$request\". " +
            "Pick between 8 and 40 songs from the library below that fit the request best (use title, artist and what you know about the songs). " +
            "Reply ONLY with a JSON object {\"name\":\"<short playlist name in the language of the request>\",\"ids\":[<song ids>]}. " +
            "Use only ids from the library.\n\nLibrary (id|title|artist):\n" + lib
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("temperature", 0.4).put("responseMimeType", "application/json"))
            .toString()
        try {
            val r = call("POST", "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", key, body)
            if (r.code !in 200..299) return@withContext AiPlaylist(error = "Die KI-Anfrage ist fehlgeschlagen (Fehler ${r.code}).")
            val root = JSONObject(r.body)
            val parts = root.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (k in 0 until parts.length()) sb.append(parts.getJSONObject(k).optString("text"))
            val txt = sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val o = JSONObject(txt)
            val valid = pool.map { it.id }.toSet()
            val arr = o.getJSONArray("ids")
            val ids = List(arr.length()) { arr.optLong(it) }.filter { it in valid }.distinct()
            if (ids.isEmpty()) AiPlaylist(error = "Die KI hat keine passenden Songs gefunden.")
            else AiPlaylist(o.optString("name").ifBlank { request.take(30) }, ids)
        } catch (_: Exception) {
            AiPlaylist(error = "Die Antwort war nicht lesbar oder es gibt keine Verbindung. Bitte noch einmal versuchen.")
        }
    }

    private fun err(msg: String) = TranslationUi(TranslationStatus.Error, message = msg)

    private sealed interface Post {
        /** Paare aus (Übersetzung, erkannte Quellsprache) */
        data class Ok(val items: List<Pair<String, String>>) : Post
        data class Fail(val message: String) : Post
    }

    private fun fail(r: Resp, provider: String): Post.Fail {
        val (t, d) = explain(r.code, r.body, provider)
        if (r.code == 404) settings.setResolvedModel("")
        return Post.Fail("$t. $d")
    }

    private fun postCloud(key: String, texts: List<String>, lang: String): Post {
        val body = JSONObject().put("q", JSONArray(texts)).put("target", lang).put("format", "text").toString()
        val r = call("POST", "https://translation.googleapis.com/language/translate/v2", key, body)
        if (r.code !in 200..299) return fail(r, Provider.CLOUD)
        val arr = JSONObject(r.body).getJSONObject("data").getJSONArray("translations")
        return Post.Ok(
            List(arr.length()) {
                val o = arr.getJSONObject(it)
                o.getString("translatedText") to o.optString("detectedSourceLanguage", "")
            },
        )
    }

    private fun postGemini(key: String, model: String, texts: List<String>, lang: String): Post {
        val langName = Locale(lang).getDisplayLanguage(Locale.ENGLISH).ifBlank { lang }
        val prompt = "Translate these song lyric lines into $langName. Keep meaning and tone, stay close to the original, " +
            "do not add notes. Reply ONLY with a JSON object {\"source\":\"<ISO 639-1 code of the original language>\"," +
            "\"lines\":[...]} where lines contains exactly ${texts.size} strings in the same order. " +
            "If a line is already in $langName, return it unchanged.\n\nLines:\n" + JSONArray(texts).toString()
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put(
                "generationConfig",
                JSONObject().put("temperature", 0).put("responseMimeType", "application/json"),
            )
            .toString()
        val r = call("POST", "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", key, body)
        if (r.code !in 200..299) return fail(r, Provider.GEMINI)
        return try {
            val root = JSONObject(r.body)
            val cands = root.optJSONArray("candidates")
            if (cands == null || cands.length() == 0) {
                val why = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
                return Post.Fail("Gemini hat keine Antwort geliefert" + if (why.isNotBlank()) " (blockiert: $why)." else ".")
            }
            val parts = cands.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (k in 0 until parts.length()) sb.append(parts.getJSONObject(k).optString("text"))
            val txt = sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val o = JSONObject(txt)
            val out = o.getJSONArray("lines")
            val src = o.optString("source", "")
            if (out.length() != texts.size) {
                return Post.Fail("Gemini hat eine unvollständige Übersetzung geliefert (${out.length()} von ${texts.size} Zeilen). Bitte noch einmal versuchen.")
            }
            Post.Ok(List(out.length()) { out.getString(it) to src })
        } catch (_: Exception) {
            Post.Fail("Die Antwort von Gemini war nicht lesbar. Bitte noch einmal versuchen.")
        }
    }
}
