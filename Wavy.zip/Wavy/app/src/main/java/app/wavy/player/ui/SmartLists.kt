package app.wavy.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.wavy.player.data.PlayStat
import app.wavy.player.data.Song

/** Eine sich selbst füllende Liste. */
data class SmartList(val key: String, val title: String, val songs: List<Song>)

private const val DAY = 24L * 60 * 60 * 1000

fun buildSmartLists(songs: List<Song>, stats: Map<Long, PlayStat>): List<SmartList> {
    val out = ArrayList<SmartList>()
    val recent = songs.filter { it.dateAdded > 0 }.sortedByDescending { it.dateAdded }.take(50)
    if (recent.isNotEmpty()) out += SmartList("recent", "Zuletzt hinzugefügt", recent)
    val most = songs.filter { (stats[it.id]?.count ?: 0) >= 2 }.sortedByDescending { stats[it.id]?.count ?: 0 }.take(50)
    if (most.isNotEmpty()) out += SmartList("most", "Am häufigsten gespielt", most)
    if (stats.isNotEmpty()) {
        val now = System.currentTimeMillis()
        val old = songs.filter { (stats[it.id]?.lastMs ?: 0L) < now - 30 * DAY }
            .sortedBy { stats[it.id]?.lastMs ?: 0L }.take(50)
        if (old.isNotEmpty()) out += SmartList("old", "Lange nicht gehört", old)
    }
    fun norm(s: String) = s.lowercase().replace(Regex("""[^\p{L}\p{N}]+"""), "")
    val dups = songs.groupBy { norm(it.title) + "|" + norm(it.artist) }
        .values.filter { it.size > 1 }.flatten()
    if (dups.isNotEmpty()) out += SmartList("dups", "Doppelte Songs", dups)
    return out
}

/** Kleine Auswahl der automatischen Listen (bewusst unauffällig als Reihe aus Pillen). */
@Composable
fun SmartListChips(lists: List<SmartList>, onOpen: (String) -> Unit) {
    if (lists.isEmpty()) return
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(bottom = 12.dp),
    ) {
        itemsIndexed(lists) { _, l ->
            Surface(
                onClick = { onOpen(l.key) },
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(l.title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp))
                    Text("${l.songs.size}", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
fun SmartListScreen(
    list: SmartList,
    currentId: Long?,
    bottomPad: Dp,
    onBack: () -> Unit,
    onPlay: (Boolean) -> Unit,
    onSongClick: (Song) -> Unit,
    onMore: (Song) -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BackButton(onBack)
            Spacer(Modifier.width(12.dp))
            Text(list.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onPlay(false) }, shape = PlayShape) {
                Icon(Icons.Rounded.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text("Abspielen")
            }
            FilledTonalButton(onClick = { onPlay(true) }, shape = ShuffleShape) {
                Icon(Icons.Rounded.Shuffle, null)
                Spacer(Modifier.width(6.dp))
                Text("Shuffle")
            }
        }
        Box(Modifier.fillMaxSize()) {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = bottomPad + 24.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                itemsIndexed(list.songs, key = { i, s -> "${s.id}_$i" }) { i, s ->
                    SongRow(
                        song = s,
                        index = i,
                        count = list.songs.size,
                        isCurrent = s.id == currentId,
                        onClick = { onSongClick(s) },
                        onMore = { onMore(s) },
                    )
                }
            }
        }
    }
}
