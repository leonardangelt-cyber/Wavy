package app.wavy.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Lädt Cover: System-Thumbnail -> eingebettetes Bild -> (bei MP4) Videoframe. Begrenzt parallel, damit nichts ruckelt. */
object CoverLoader {

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 6).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing = ConcurrentHashMap.newKeySet<String>()
    private val gate = Semaphore(3)

    private fun key(song: Song, px: Int) = "${song.id}@$px"

    fun cached(song: Song, px: Int): Bitmap? = cache.get(key(song, px))

    suspend fun load(ctx: Context, song: Song, px: Int): Bitmap? {
        val k = key(song, px)
        cache.get(k)?.let { return it }
        if (k in missing) return null
        val bmp = gate.withPermit { withContext(Dispatchers.IO) { decode(ctx, song, px) } }
        if (bmp == null) {
            missing.add(k)
            return null
        }
        cache.put(k, bmp)
        return bmp
    }

    private fun Bitmap.soft(): Bitmap =
        if (config == Bitmap.Config.HARDWARE) copy(Bitmap.Config.ARGB_8888, false) ?: this else this

    private fun decode(ctx: Context, song: Song, px: Int): Bitmap? {
        try {
            return ctx.contentResolver.loadThumbnail(song.uri, Size(px, px), null).soft()
        } catch (_: Exception) {
        }
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, song.uri)
            val bytes = r.embeddedPicture
            if (bytes != null) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.let { return it.soft() }
            }
            if (song.isVideo) {
                r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { return it.soft() }
            }
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        return null
    }
}
