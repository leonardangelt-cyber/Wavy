package app.wavy.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Speichert Playlists als JSON-Datei im App-Speicher. */
class PlaylistStore(ctx: Context) {
    private val file = File(ctx.filesDir, "playlists.json")
    private val _playlists = MutableStateFlow(load())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    private fun load(): List<Playlist> = try {
        val arr = JSONArray(file.readText())
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("songs")
            Playlist(
                id = o.getLong("id"),
                name = o.getString("name"),
                excludeFromHome = o.optBoolean("exclude", false),
                songIds = List(ids.length()) { ids.getLong(it) },
                hideFromHome = o.optBoolean("hide", false),
            )
        }
    } catch (_: Exception) {
        emptyList()
    }

    private fun save() {
        try {
            val arr = JSONArray()
            _playlists.value.forEach { p ->
                arr.put(
                    JSONObject()
                        .put("id", p.id)
                        .put("name", p.name)
                        .put("exclude", p.excludeFromHome)
                        .put("hide", p.hideFromHome)
                        .put("songs", JSONArray(p.songIds)),
                )
            }
            file.writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    private fun mutate(block: (List<Playlist>) -> List<Playlist>) {
        _playlists.update(block)
        save()
    }

    private fun change(id: Long, block: (Playlist) -> Playlist) =
        mutate { list -> list.map { if (it.id == id) block(it) else it } }

    fun create(name: String): Long {
        val id = System.currentTimeMillis()
        mutate { it + Playlist(id, name, false, emptyList()) }
        return id
    }

    fun rename(id: Long, name: String) = change(id) { it.copy(name = name) }

    fun delete(id: Long) = mutate { list -> list.filter { it.id != id } }

    fun setExclude(id: Long, exclude: Boolean) = change(id) { it.copy(excludeFromHome = exclude) }

    fun setHide(id: Long, hide: Boolean) = change(id) { it.copy(hideFromHome = hide) }

    fun toggleSong(id: Long, songId: Long) = change(id) {
        if (songId in it.songIds) it.copy(songIds = it.songIds - songId) else it.copy(songIds = it.songIds + songId)
    }

    fun addSongs(id: Long, ids: List<Long>) = change(id) { it.copy(songIds = it.songIds + ids.filter { x -> x !in it.songIds }) }

    /** Alle Playlists als JSON-Text (für die Sicherung). */
    fun exportJson(): JSONArray {
        val arr = JSONArray()
        _playlists.value.forEach { p ->
            arr.put(
                JSONObject().put("id", p.id).put("name", p.name).put("exclude", p.excludeFromHome)
                    .put("hide", p.hideFromHome).put("songs", JSONArray(p.songIds)),
            )
        }
        return arr
    }

    /** Ersetzt alle Playlists durch die gesicherten. */
    fun importJson(arr: JSONArray) {
        val list = List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("songs")
            Playlist(
                id = o.getLong("id"),
                name = o.getString("name"),
                excludeFromHome = o.optBoolean("exclude", false),
                songIds = List(ids.length()) { ids.getLong(it) },
                hideFromHome = o.optBoolean("hide", false),
            )
        }
        mutate { list }
    }

    // ---------- Wiederverknüpfen ----------
    // Playlists merken sich nur die interne Android-ID eines Songs. Ändert Android diese (z. B. nach einem Neuscan
    // der Medien), wären die Songs "weg". Darum wird zu jeder ID eine Signatur (Titel|Interpret|Länge) gemerkt;
    // fehlt eine ID, wird der Song über die Signatur wiedergefunden.
    private val metaFile = File(file.parentFile, "playlist_meta.json")

    private fun sig(s: Song): String {
        fun n(x: String) = x.lowercase().replace(Regex("""[^\p{L}\p{N}]+"""), "")
        return n(s.title) + "|" + n(s.artist) + "|" + (s.durationMs / 1000)
    }

    @Synchronized
    fun relink(songs: List<Song>) {
        if (songs.isEmpty()) return
        val meta = HashMap<Long, String>()
        try {
            val o = JSONObject(metaFile.readText())
            for (k in o.keys()) meta[k.toLong()] = o.getString(k)
        } catch (_: Exception) {
        }
        val byId = songs.associateBy { it.id }
        val bySig = songs.groupBy { sig(it) }
        var metaChanged = false
        var listsChanged = false
        val updated = _playlists.value.map { p ->
            val ids = p.songIds.toMutableList()
            var changed = false
            for (i in ids.indices) {
                val id = ids[i]
                val s = byId[id]
                if (s != null) {
                    val sg = sig(s)
                    if (meta[id] != sg) { meta[id] = sg; metaChanged = true }
                } else {
                    val sg = meta[id] ?: continue
                    val cand = bySig[sg]?.firstOrNull { it.id !in ids }
                    if (cand != null) {
                        ids[i] = cand.id
                        meta[cand.id] = sg
                        meta.remove(id)
                        changed = true
                        metaChanged = true
                    }
                }
            }
            if (changed) { listsChanged = true; p.copy(songIds = ids.distinct()) } else p
        }
        if (metaChanged) {
            try {
                val o = JSONObject()
                meta.forEach { (k, v) -> o.put(k.toString(), v) }
                metaFile.writeText(o.toString())
            } catch (_: Exception) {
            }
        }
        if (listsChanged) mutate { updated }
    }

    fun removeSong(id: Long, songId: Long) = change(id) { it.copy(songIds = it.songIds - songId) }
}
