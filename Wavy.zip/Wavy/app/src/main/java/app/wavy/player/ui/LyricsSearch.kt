package app.wavy.player.ui

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.shape.RoundedCornerShape
import org.json.JSONArray
import java.net.URLEncoder

/**
 * Songtext im Web suchen: Die Seite öffnet sich in der App. Man markiert den Text und übernimmt ihn
 * (oder die ganze Seite). Vor dem Speichern kann der Text noch bearbeitet werden.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LyricsWebDialog(
    title: String,
    artist: String,
    onUse: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var web by remember { mutableStateOf<WebView?>(null) }
    var progress by remember { mutableIntStateOf(100) }
    var draft by remember { mutableStateOf<String?>(null) }
    val q = URLEncoder.encode("$artist $title lyrics".trim(), "UTF-8")
    val start = "https://duckduckgo.com/?q=$q"

    fun grab(js: String) {
        web?.evaluateJavascript(js) { raw ->
            val text = try {
                JSONArray("[${raw ?: "null"}]").optString(0, "")
            } catch (_: Exception) {
                ""
            }
            draft = tidy(text)
        }
    }

    BackHandler {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else onDismiss()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = cs.surface) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalIconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Rounded.Close, "Schließen")
                    }
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text("Songtext suchen", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "Text markieren (lang drücken, Griffe ziehen), dann übernehmen",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
                if (progress < 100) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                AndroidView(
                    modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            webViewClient = WebViewClient()
                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    progress = newProgress
                                }
                            }
                            loadUrl(start)
                            web = this
                        }
                    },
                    onRelease = { it.destroy(); web = null },
                )
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(
                        onClick = { grab("(function(){return window.getSelection().toString();})()") },
                        modifier = Modifier.weight(1f).height(52.dp),
                    ) { Text("Auswahl übernehmen") }
                    FilledTonalButton(
                        onClick = { grab("(function(){return document.body.innerText;})()") },
                        modifier = Modifier.weight(1f).height(52.dp),
                    ) { Text("Ganze Seite") }
                }
            }
        }
    }

    draft?.let { d ->
        var text by remember(d) { mutableStateOf(d) }
        AlertDialog(
            onDismissRequest = { draft = null },
            title = { Text("Diesen Songtext verwenden?") },
            text = {
                Column {
                    Text(
                        "Überflüssiges kannst du hier noch löschen.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.fillMaxWidth().height(320.dp),
                        shape = RoundedCornerShape(20.dp),
                    )
                }
            },
            confirmButton = {
                Button(onClick = { if (text.isNotBlank()) onUse(text.trim()) }, enabled = text.isNotBlank()) { Text("Verwenden") }
            },
            dismissButton = { TextButton(onClick = { draft = null }) { Text("Zurück") } },
            shape = RoundedCornerShape(32.dp),
        )
    }
}

private fun tidy(s: String): String =
    s.replace("\r", "")
        .lines()
        .map { it.trim() }
        .joinToString("\n")
        .replace(Regex("\n{3,}"), "\n\n")
        .trim()
