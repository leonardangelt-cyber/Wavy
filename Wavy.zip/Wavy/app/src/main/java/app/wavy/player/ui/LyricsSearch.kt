package app.wavy.player.ui

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Findet auf einer Webseite den Songtext: bekannte Seiten (Genius u. a.) direkt, sonst über ein Muster
 * (viele kurze Zeilen, kaum Links). Zurück kommt nur der Text mit Zeilen und Absätzen.
 */
private const val DETECT_JS = """
(function(){
  function vis(e){ var r=e.getBoundingClientRect(); var s=getComputedStyle(e); return s.display!=='none' && s.visibility!=='hidden' && (r.width>0 || r.height>0); }
  function txt(e){ return (e.innerText||'').replace(/\r/g,''); }
  function lines(t){ return t.split('\n').map(function(x){return x.trim();}); }
  function nonEmpty(t){ return lines(t).filter(function(x){return x.length>0;}); }
  function linkLen(e){ var n=0; var a=e.querySelectorAll('a,button'); for(var i=0;i<a.length;i++){ n+=(a[i].innerText||'').length; } return n; }
  var site=location.hostname, text='', how='';
  var g=document.querySelectorAll('[data-lyrics-container="true"]');
  if(g.length){ var p=[]; for(var i=0;i<g.length;i++){ p.push(txt(g[i])); } text=p.join('\n\n'); how='genius'; }
  if(!text){
    var ml=document.querySelectorAll('.lyrics__content__ok, .mxm-lyrics__content, [class*="lyrics__content"]');
    if(ml.length){ var q=[]; for(var j=0;j<ml.length;j++){ q.push(txt(ml[j])); } text=q.join('\n'); how='musixmatch'; }
  }
  if(!text){
    var cands=document.querySelectorAll('div,pre,article,section,p,td');
    var best=null, bestScore=0;
    function stat(e){
      if(e.closest('nav,header,footer,aside,script,style,form,select,textarea')) return null;
      if(!vis(e)) return null;
      var t=txt(e); if(t.length<120 || t.length>9000) return null;
      var ls=nonEmpty(t); var n=ls.length; if(n<8 || n>260) return null;
      var short=0, sumLen=0; for(var k=0;k<ls.length;k++){ if(ls[k].length<=70) short++; sumLen+=ls[k].length; }
      var ratio=short/n; var avg=sumLen/n; if(ratio<0.92 || avg<8 || avg>60) return null;
      var ld=linkLen(e)/Math.max(1,t.length); if(ld>0.12) return null;
      return {n:n, score:n*ratio*Math.pow(1-ld,3)};
    }
    for(var c=0;c<cands.length;c++){
      var s=stat(cands[c]); if(!s) continue;
      if(s.score>bestScore){ bestScore=s.score; best=cands[c]; }
    }
    if(best){
      var cur=best, curN=stat(best).n, moved=true;
      while(moved){
        moved=false; var ch=cur.children;
        for(var m=0;m<ch.length;m++){ var sc=stat(ch[m]); if(sc && sc.n>=curN*0.85){ cur=ch[m]; curN=sc.n; moved=true; break; } }
      }
      text=txt(cur); how='pattern';
    }
  }
  return JSON.stringify({text:text, how:how, site:site});
})()
"""

/** Entfernt alles, was kein Gesang ist (Abschnitts-Kennungen, Seitenreste) und ordnet die Absätze. */
fun cleanLyrics(raw: String): String {
    val junk = listOf(
        Regex("""^\[[^\]]*]$"""),
        Regex("""^\((?:verse|chorus|hook|bridge|intro|outro|refrain|pre-chorus|strophe|interlude)[^)]*\)$""", RegexOption.IGNORE_CASE),
        Regex("""^(?:verse|chorus|hook|bridge|intro|outro|refrain|pre-chorus|strophe|interlude)\s*\d*\s*:?$""", RegexOption.IGNORE_CASE),
        Regex("""^\d*\s*Embed$""", RegexOption.IGNORE_CASE),
        Regex("""^You might also like$""", RegexOption.IGNORE_CASE),
        Regex("""^\d+\s+Contributors?.*$""", RegexOption.IGNORE_CASE),
        Regex("""^.*\bLyrics$""", RegexOption.IGNORE_CASE),
        Regex("""^See .* Live$""", RegexOption.IGNORE_CASE),
        Regex("""^Get tickets as low as.*$""", RegexOption.IGNORE_CASE),
        Regex("""^(?:Submit Corrections|Read More)$""", RegexOption.IGNORE_CASE),
    )
    val out = ArrayList<String>()
    var lastBlank = true
    for (l0 in raw.replace("\r", "").replace(' ', ' ').lines()) {
        val l = l0.trim()
        if (l.isEmpty()) {
            if (!lastBlank) { out.add(""); lastBlank = true }
            continue
        }
        if (junk.any { it.matches(l) }) continue
        out.add(l)
        lastBlank = false
    }
    while (out.isNotEmpty() && out.last().isEmpty()) out.removeAt(out.lastIndex)
    return out.joinToString("\n")
}

private fun parseDetect(raw: String?): String? {
    return try {
        val inner = JSONArray("[${raw ?: "null"}]").optString(0, "")
        if (inner.isBlank()) return null
        val t = cleanLyrics(JSONObject(inner).optString("text", ""))
        if (t.lines().count { it.isNotBlank() } >= 6) t else null
    } catch (_: Exception) {
        null
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LyricsWebDialog(
    title: String,
    artist: String,
    onUse: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var web by remember { mutableStateOf<WebView?>(null) }
    var progress by remember { mutableIntStateOf(100) }
    var detected by remember { mutableStateOf<String?>(null) }
    var draft by remember { mutableStateOf<String?>(null) }
    val q = URLEncoder.encode("$artist $title lyrics".trim(), "UTF-8")
    val start = "https://duckduckgo.com/?q=$q"

    fun detect(v: WebView) {
        v.evaluateJavascript(DETECT_JS) { raw -> detected = parseDetect(raw) }
    }

    BackHandler {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else onDismiss()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = cs.surface) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalIconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Rounded.Close, "Schließen")
                    }
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text("Songtext suchen", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            if (detected != null) "Songtext auf dieser Seite erkannt" else "Öffne eine Seite mit dem Songtext",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (detected != null) cs.primary else cs.onSurfaceVariant,
                        )
                    }
                }
                if (progress < 100) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                AndroidView(
                    modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                                    detected = null
                                }

                                override fun onPageFinished(view: WebView, url: String?) {
                                    detect(view)
                                    // Manche Seiten laden den Text erst nachträglich
                                    view.postDelayed({ detect(view) }, 1500)
                                    view.postDelayed({ detect(view) }, 3500)
                                }
                            }
                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    progress = newProgress
                                }
                            }
                            loadUrl(start)
                            web = this
                        }
                    },
                    onRelease = { it.destroy(); web = null },
                )
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { detected?.let(onUse) },
                        enabled = detected != null,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                    ) { Text("Diesen Songtext verwenden") }
                    FilledTonalButton(
                        onClick = {
                            web?.evaluateJavascript("(function(){return window.getSelection().toString();})()") { raw ->
                                val t = try { JSONArray("[${raw ?: "null"}]").optString(0, "") } catch (_: Exception) { "" }
                                draft = cleanLyrics(t)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                    ) { Text("Markierten Text übernehmen") }
                }
            }
        }
    }

    draft?.let { d ->
        LyricsEditDialog(
            title = "Diesen Songtext verwenden?",
            initial = d,
            confirm = "Verwenden",
            onDismiss = { draft = null },
            onConfirm = { onUse(it) },
        )
    }
}

/** Songtext bearbeiten bzw. vor dem Übernehmen prüfen. */
@Composable
fun LyricsEditDialog(
    title: String,
    initial: String,
    confirm: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var text by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(
                    "Zeilen und Leerzeilen bleiben genau so erhalten.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().height(320.dp),
                    shape = RoundedCornerShape(20.dp),
                )
            }
        },
        confirmButton = {
            Button(onClick = { if (text.isNotBlank()) onConfirm(cleanLyrics(text)) }, enabled = text.isNotBlank()) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
        shape = RoundedCornerShape(32.dp),
    )
}
