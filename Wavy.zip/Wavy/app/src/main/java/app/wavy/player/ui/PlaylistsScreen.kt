package app.wavy.player.ui

import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Playlist
import app.wavy.player.data.Song

@Composable
fun PlaylistsScreen(
    playlists: List<Playlist>,
    songsById: Map<Long, Song>,
    bottomPad: Dp,
    onOpen: (Long) -> Unit,
    onCreate: (String) -> Unit,
    smart: List<SmartList> = emptyList(),
    onOpenSmart: (String) -> Unit = {},
) {
    var showCreate by remember { mutableStateOf(false) }
    val dark = isSystemInDarkTheme()
    val cs = MaterialTheme.colorScheme

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                modifier = Modifier.padding(bottom = bottomPad),
                onClick = { showCreate = true },
                shape = RoundedCornerShape(24.dp),
                containerColor = cs.primaryContainer,
                contentColor = cs.onPrimaryContainer,
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text("Neue Playlist") },
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            Text(
                "Playlists",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.statusBarsPadding().padding(start = 20.dp, top = 16.dp, bottom = 16.dp),
            )
            SmartListChips(smart, onOpenSmart)
            if (playlists.isEmpty()) {
                EmptyState(
                    title = "Noch keine Playlists",
                    text = "Erstelle eine Playlist und gruppiere darin deine Songs.",
                    modifier = Modifier.weight(1f),
                    buttonText = "Playlist erstellen",
                    onButton = { showCreate = true },
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 96.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    itemsIndexed(playlists, key = { _, p -> p.id }) { i, p ->
                        val first = p.songIds.firstNotNullOfOrNull { songsById[it] }
                        val count = p.songIds.count { it in songsById }
                        val key = p.id % 1000
                        val container = Vivid.container(key, dark)
                        val content = readable(container, Vivid.onContainer(key, dark))
                        val src = remember { MutableInteractionSource() }
                        Surface(
                            onClick = { onOpen(p.id) },
                            shape = segShape(i, playlists.size),
                            color = container,
                            contentColor = content,
                            interactionSource = src,
                            modifier = Modifier.fillMaxWidth().pressScale(src, 0.97f),
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Cover(first, 192, Modifier.size(72.dp), RoundedCornerShape(24.dp))
                                Spacer(Modifier.width(16.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        p.name,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        "$count Songs" + (if (p.excludeFromHome) " · nicht in Auto-Wiedergabe" else "") + (if (p.hideFromHome) " · in Bibliothek ausgeblendet" else ""),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = content.copy(alpha = 0.85f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        NameDialog(
            title = "Neue Playlist",
            initial = "",
            confirm = "Erstellen",
            onDismiss = { showCreate = false },
            onConfirm = { showCreate = false; onCreate(it) },
        )
    }
}

@Composable
fun PlaylistDetailScreen(
    playlist: Playlist,
    songs: List<Song>,
    allSongs: List<Song>,
    currentId: Long?,
    bottomPad: Dp,
    onBack: () -> Unit,
    onPlay: (Boolean) -> Unit,
    onSongClick: (Song) -> Unit,
    onToggleSong: (Long) -> Unit,
    onToggleExclude: (Boolean) -> Unit,
    onToggleHide: (Boolean) -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
) {
    var showAdd by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                modifier = Modifier.padding(bottom = bottomPad),
                onClick = { showAdd = true },
                shape = RoundedCornerShape(24.dp),
                containerColor = cs.primaryContainer,
                contentColor = cs.onPrimaryContainer,
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text("Songs hinzufügen") },
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { inner ->
        LazyColumn(
            modifier = Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 96.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            item {
                Row(
                    Modifier.statusBarsPadding().padding(top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BackButton(onBack, Modifier.padding(start = 4.dp))
                    Text(
                        playlist.name,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(start = 14.dp),
                    )
                    Box {
                        androidx.compose.material3.FilledTonalIconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.size(48.dp),
                            shape = RoundedCornerShape(16.dp),
                        ) { Icon(Icons.Rounded.MoreVert, "Mehr") }
                        WavyMenu(expanded = showMenu, onDismiss = { showMenu = false }) {
                            WavyMenuItem(
                                Icons.Rounded.Shuffle, "Bei „Alle abspielen“ auslassen",
                                "Diese Songs kommen bei Play/Shuffle der Bibliothek nicht vor",
                                checked = playlist.excludeFromHome,
                            ) { onToggleExclude(!playlist.excludeFromHome) }
                            WavyMenuItem(
                                Icons.Rounded.Visibility, "In der Bibliothek ausblenden",
                                "Diese Songs werden auf Home gar nicht angezeigt",
                                checked = playlist.hideFromHome,
                            ) { onToggleHide(!playlist.hideFromHome) }
                            WavyMenuItem(Icons.Rounded.Edit, "Umbenennen") { showMenu = false; showRename = true }
                            WavyMenuItem(Icons.Rounded.Delete, "Löschen", danger = true) { showMenu = false; showDelete = true }
                        }
                    }
                }
            }
            if (songs.isNotEmpty()) {
                item {
                    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        val s1 = remember { MutableInteractionSource() }
                        val s2 = remember { MutableInteractionSource() }
                        Button(
                            onClick = { onPlay(false) },
                            interactionSource = s1,
                            modifier = Modifier.weight(1f).height(56.dp).pressScale(s1),
                            shape = PlayShape,
                        ) {
                            Icon(Icons.Rounded.PlayArrow, null, Modifier.size(ButtonDefaults.IconSize))
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Text("Abspielen")
                        }
                        FilledTonalButton(
                            onClick = { onPlay(true) },
                            interactionSource = s2,
                            modifier = Modifier.weight(1f).height(56.dp).pressScale(s2),
                            shape = ShuffleShape,
                        ) {
                            Icon(Icons.Rounded.Shuffle, null, Modifier.size(ButtonDefaults.IconSize))
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Text("Shuffle")
                        }
                    }
                }
            } else {
                item {
                    Text(
                        "Diese Playlist ist noch leer. Tippe auf \"Songs hinzufügen\".",
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(8.dp),
                    )
                }
            }
            itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                SongRow(
                    song = s,
                    index = i,
                    count = songs.size,
                    isCurrent = s.id == currentId,
                    onClick = { onSongClick(s) },
                    trailing = {
                        IconButton(onClick = { onToggleSong(s.id) }) { Icon(Icons.Rounded.Close, "Entfernen") }
                    },
                )
            }
        }
    }

    if (showAdd) {
        SongPickerSheet(
            allSongs = allSongs,
            selected = playlist.songIds.toSet(),
            onToggle = onToggleSong,
            onDismiss = { showAdd = false },
        )
    }

    if (showRename) {
        NameDialog(
            title = "Playlist umbenennen",
            initial = playlist.name,
            confirm = "Speichern",
            onDismiss = { showRename = false },
            onConfirm = { showRename = false; onRename(it) },
        )
    }

    if (showDelete) {
        WavyDialog(
            icon = Icons.Rounded.Delete,
            title = "Playlist löschen?",
            confirm = "Löschen",
            danger = true,
            onDismiss = { showDelete = false },
            onConfirm = { showDelete = false; onDelete() },
        ) { Text("\"${playlist.name}\" wird gelöscht. Deine Songs bleiben auf dem Handy.") }
    }
}
