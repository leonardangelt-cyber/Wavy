package app.wavy.player.ui

import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Playlist
import app.wavy.player.data.Song

/** Quadratische Kachel mit den ersten vier Covern, darunter der Name. */
@Composable
private fun CoverTile(title: String, subtitle: String, covers: List<Song>, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    Column(
        Modifier
            .width(152.dp)
            .pressScale(src, 0.96f)
            .clip(RoundedCornerShape(28.dp))
            .clickable(interactionSource = src, indication = null, onClick = onClick),
    ) {
        Box(Modifier.size(152.dp).clip(RoundedCornerShape(28.dp)).background(cs.surfaceContainerHighest)) {
            when {
                covers.isEmpty() -> Icon(
                    Icons.AutoMirrored.Rounded.QueueMusic, null,
                    tint = cs.onSurfaceVariant, modifier = Modifier.align(Alignment.Center).size(40.dp),
                )
                covers.size < 4 -> Cover(covers[0], 320, Modifier.fillMaxSize(), RoundedCornerShape(0.dp))
                else -> Column(Modifier.fillMaxSize()) {
                    for (r in 0..1) Row(Modifier.weight(1f)) {
                        for (c in 0..1) Cover(covers[r * 2 + c], 160, Modifier.weight(1f).fillMaxSize(), RoundedCornerShape(0.dp))
                    }
                }
            }
        }
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 8.dp),
        )
        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 6.dp, end = 6.dp, bottom = 4.dp),
        )
    }
}

@Composable
private fun NewTile(onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    Column(Modifier.width(152.dp).pressScale(src, 0.96f)) {
        Box(
            Modifier
                .size(152.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(cs.primaryContainer)
                .clickable(interactionSource = src, indication = null, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Add, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(44.dp))
        }
        Text(
            "Neue Playlist",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 6.dp, top = 8.dp),
        )
        Text("Manuell oder mit KI", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 6.dp))
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun PlaylistsScreen(
    playlists: List<Playlist>,
    songsById: Map<Long, Song>,
    bottomPad: Dp,
    onOpen: (Long) -> Unit,
    onCreate: (String) -> Unit,
    smart: List<SmartList> = emptyList(),
    onOpenSmart: (String) -> Unit = {},
    onCreateAi: (String, (String?) -> Unit) -> Unit = { _, d -> d(null) },
) {
    var showChoice by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var showAi by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    LazyColumn(
        contentPadding = PaddingValues(bottom = bottomPad + 24.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item {
            Text(
                "Bibliothek",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.statusBarsPadding().padding(start = 20.dp, top = 16.dp, bottom = 16.dp),
            )
        }
        item {
            Text(
                "Deine Playlists",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = cs.primary,
                modifier = Modifier.padding(start = 20.dp, bottom = 10.dp),
            )
            androidx.compose.foundation.lazy.LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item { NewTile { showChoice = true } }
                items(playlists.size, key = { playlists[it].id }) { i ->
                    val p = playlists[i]
                    val covers = p.songIds.mapNotNull { songsById[it] }
                    CoverTile(p.name, "${covers.size} Songs", covers.take(4)) { onOpen(p.id) }
                }
            }
        }
        if (smart.isNotEmpty()) {
            item {
                Text(
                    "Automatisch für dich",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = cs.primary,
                    modifier = Modifier.padding(start = 20.dp, top = 28.dp, bottom = 10.dp),
                )
                androidx.compose.foundation.lazy.LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(smart.size, key = { smart[it].key }) { i ->
                        val l = smart[i]
                        CoverTile(l.title, "${l.songs.size} Songs", l.songs.take(4)) { onOpenSmart(l.key) }
                    }
                }
            }
        }
    }

    if (showChoice) {
        androidx.compose.material3.ModalBottomSheet(
            onDismissRequest = { showChoice = false },
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            containerColor = cs.surfaceContainerLow,
        ) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Neue Playlist", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Button(
                    onClick = { showChoice = false; showCreate = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(28.dp),
                ) { Text("Leere Playlist anlegen") }
                FilledTonalButton(
                    onClick = { showChoice = false; showAi = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(28.dp),
                ) { Text("Mit KI erstellen") }
            }
        }
    }

    if (showCreate) {
        NameDialog(
            title = "Neue Playlist",
            initial = "",
            confirm = "Erstellen",
            onDismiss = { showCreate = false },
            onConfirm = { showCreate = false; onCreate(it) },
        )
    }

    if (showAi) {
        var text by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { if (!busy) showAi = false },
            title = { Text("Playlist mit KI") },
            text = {
                Column {
                    Text(
                        "Beschreibe, was du hören willst. Die KI sucht passende Songs aus deiner Bibliothek.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.material3.OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        placeholder = { Text("z. B. ruhige Songs zum Lernen") },
                        enabled = !busy,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (busy) {
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text("Die KI wählt Songs aus …", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    error?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall, color = cs.error)
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = text.isNotBlank() && !busy,
                    onClick = {
                        busy = true
                        error = null
                        onCreateAi(text.trim()) { err ->
                            busy = false
                            if (err == null) showAi = false else error = err
                        }
                    },
                ) { Text("Erstellen") }
            },
            dismissButton = { TextButton(onClick = { if (!busy) showAi = false }) { Text("Abbrechen") } },
            shape = RoundedCornerShape(32.dp),
        )
    }
}

@Composable
fun PlaylistDetailScreen(
    playlist: Playlist,
    songs: List<Song>,
    allSongs: List<Song>,
    currentId: Long?,
    bottomPad: Dp,
    onBack: () -> Unit,
    onPlay: (Boolean) -> Unit,
    onSongClick: (Song) -> Unit,
    onToggleSong: (Long) -> Unit,
    onToggleExclude: (Boolean) -> Unit,
    onToggleHide: (Boolean) -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
) {
    var showAdd by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                modifier = Modifier.padding(bottom = bottomPad),
                onClick = { showAdd = true },
                shape = RoundedCornerShape(24.dp),
                containerColor = cs.primaryContainer,
                contentColor = cs.onPrimaryContainer,
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text("Songs hinzufügen") },
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { inner ->
        LazyColumn(
            modifier = Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 96.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            item {
                Row(
                    Modifier.statusBarsPadding().padding(top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BackButton(onBack, Modifier.padding(start = 4.dp))
                    Text(
                        playlist.name,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(start = 14.dp),
                    )
                    Box {
                        androidx.compose.material3.FilledTonalIconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.size(48.dp),
                            shape = RoundedCornerShape(16.dp),
                        ) { Icon(Icons.Rounded.MoreVert, "Mehr") }
                        WavyMenu(expanded = showMenu, onDismiss = { showMenu = false }) {
                            WavyMenuItem(
                                Icons.Rounded.Shuffle, "Bei „Alle abspielen“ auslassen",
                                "Diese Songs kommen bei Play/Shuffle der Bibliothek nicht vor",
                                checked = playlist.excludeFromHome,
                            ) { onToggleExclude(!playlist.excludeFromHome) }
                            WavyMenuItem(
                                Icons.Rounded.Visibility, "In der Bibliothek ausblenden",
                                "Diese Songs werden auf Home gar nicht angezeigt",
                                checked = playlist.hideFromHome,
                            ) { onToggleHide(!playlist.hideFromHome) }
                            WavyMenuItem(Icons.Rounded.Edit, "Umbenennen") { showMenu = false; showRename = true }
                            WavyMenuItem(Icons.Rounded.Delete, "Löschen", danger = true) { showMenu = false; showDelete = true }
                        }
                    }
                }
            }
            if (songs.isNotEmpty()) {
                item {
                    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        val s1 = remember { MutableInteractionSource() }
                        val s2 = remember { MutableInteractionSource() }
                        Button(
                            onClick = { onPlay(false) },
                            interactionSource = s1,
                            modifier = Modifier.weight(1f).height(56.dp).pressScale(s1),
                            shape = PlayShape,
                        ) {
                            Icon(Icons.Rounded.PlayArrow, null, Modifier.size(ButtonDefaults.IconSize))
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Text("Abspielen")
                        }
                        FilledTonalButton(
                            onClick = { onPlay(true) },
                            interactionSource = s2,
                            modifier = Modifier.weight(1f).height(56.dp).pressScale(s2),
                            shape = ShuffleShape,
                        ) {
                            Icon(Icons.Rounded.Shuffle, null, Modifier.size(ButtonDefaults.IconSize))
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Text("Shuffle")
                        }
                    }
                }
            } else {
                item {
                    Text(
                        "Diese Playlist ist noch leer. Tippe auf \"Songs hinzufügen\".",
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(8.dp),
                    )
                }
            }
            itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                SongRow(
                    song = s,
                    index = i,
                    count = songs.size,
                    isCurrent = s.id == currentId,
                    onClick = { onSongClick(s) },
                    trailing = {
                        IconButton(onClick = { onToggleSong(s.id) }) { Icon(Icons.Rounded.Close, "Entfernen") }
                    },
                )
            }
        }
    }

    if (showAdd) {
        SongPickerSheet(
            allSongs = allSongs,
            selected = playlist.songIds.toSet(),
            onToggle = onToggleSong,
            onDismiss = { showAdd = false },
        )
    }

    if (showRename) {
        NameDialog(
            title = "Playlist umbenennen",
            initial = playlist.name,
            confirm = "Speichern",
            onDismiss = { showRename = false },
            onConfirm = { showRename = false; onRename(it) },
        )
    }

    if (showDelete) {
        WavyDialog(
            icon = Icons.Rounded.Delete,
            title = "Playlist löschen?",
            confirm = "Löschen",
            danger = true,
            onDismiss = { showDelete = false },
            onConfirm = { showDelete = false; onDelete() },
        ) { Text("\"${playlist.name}\" wird gelöscht. Deine Songs bleiben auf dem Handy.") }
    }
}
