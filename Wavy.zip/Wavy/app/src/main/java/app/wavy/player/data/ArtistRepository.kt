package app.wavy.player.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

data class DiscAlbum(val title: String, val cover: String, val year: String)
data class RelatedArtist(val name: String, val picture: String)
data class ArtistInfo(val albums: List<DiscAlbum>, val related: List<RelatedArtist>)

/** Diskografie und ähnliche Künstler aus der öffentlichen Deezer-Schnittstelle (ohne Schlüssel). */
object ArtistRepository {
    private val cache = ConcurrentHashMap<String, ArtistInfo>()

    private fun http(url: String): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "Wavy/1.0")
            if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
        } catch (_: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    suspend fun info(artist: String): ArtistInfo? = withContext(Dispatchers.IO) {
        val key = artist.lowercase()
        cache[key]?.let { return@withContext it }
        val s = http("https://api.deezer.com/search/artist?q=${enc(artist)}&limit=1") ?: return@withContext null
        val id = try {
            JSONObject(s).optJSONArray("data")?.optJSONObject(0)?.optLong("id", 0L) ?: 0L
        } catch (_: Exception) {
            0L
        }
        if (id == 0L) return@withContext ArtistInfo(emptyList(), emptyList())
        val albums = ArrayList<DiscAlbum>()
        http("https://api.deezer.com/artist/$id/albums?limit=60")?.let { body ->
            try {
                val arr = JSONObject(body).optJSONArray("data")
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val t = o.optString("title")
                    if (t.isBlank() || albums.any { it.title.equals(t, true) }) continue
                    albums += DiscAlbum(t, o.optString("cover_medium"), o.optString("release_date").take(4))
                }
            } catch (_: Exception) {
            }
        }
        albums.sortByDescending { it.year }
        val related = ArrayList<RelatedArtist>()
        http("https://api.deezer.com/artist/$id/related?limit=12")?.let { body ->
            try {
                val arr = JSONObject(body).optJSONArray("data")
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    related += RelatedArtist(o.optString("name"), o.optString("picture_medium"))
                }
            } catch (_: Exception) {
            }
        }
        val r = ArtistInfo(albums, related)
        cache[key] = r
        r
    }
}

/** Kleiner Bildlader für Bilder aus dem Netz (mit Zwischenspeicher im Arbeitsspeicher). */
object RemoteImages {
    private val cache = LruCache<String, Bitmap>(40)

    fun cached(url: String): Bitmap? = cache.get(url)

    suspend fun load(url: String): Bitmap? = withContext(Dispatchers.IO) {
        cache.get(url)?.let { return@withContext it }
        var c: HttpURLConnection? = null
        try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
            if (bmp != null) cache.put(url, bmp)
            bmp
        } catch (_: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }
}
