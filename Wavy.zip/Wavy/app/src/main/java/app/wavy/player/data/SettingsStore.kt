package app.wavy.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Einstellungen im privaten App-Speicher (nicht in Backups): API-Schlüssel, Monatslimit, Verbrauch. */
class SettingsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _apiKey = MutableStateFlow(sp.getString("api_key", "") ?: "")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    /** "gemini" (KI) oder "cloud" (Google Cloud Translation) */
    private val _provider = MutableStateFlow(sp.getString("provider", Provider.GEMINI) ?: Provider.GEMINI)
    val provider: StateFlow<String> = _provider.asStateFlow()

    /** Vom Nutzer gewähltes Modell, leer = automatisch */
    private val _model = MutableStateFlow(sp.getString("model", "") ?: "")
    val model: StateFlow<String> = _model.asStateFlow()

    /** Zuletzt automatisch gewähltes Modell */
    private val _resolved = MutableStateFlow(sp.getString("resolved_model", "") ?: "")
    val resolvedModel: StateFlow<String> = _resolved.asStateFlow()

    /** Überblenden zwischen Songs in Sekunden (0 = aus). Der Wiedergabe-Dienst liest den Wert direkt. */
    private val _crossfade = MutableStateFlow(sp.getInt("crossfade", 1))
    val crossfadeSec: StateFlow<Int> = _crossfade.asStateFlow()

    private val _limit = MutableStateFlow(sp.getInt("limit", 50_000))
    val monthlyLimit: StateFlow<Int> = _limit.asStateFlow()

    private val _used = MutableStateFlow(readUsed())
    val usedChars: StateFlow<Int> = _used.asStateFlow()

    private fun month(): String = SimpleDateFormat("yyyyMM", Locale.US).format(Date())

    private fun readUsed(): Int =
        if (sp.getString("used_month", "") == month()) sp.getInt("used", 0) else 0

    fun setApiKey(key: String) {
        val k = key.trim()
        sp.edit().putString("api_key", k).apply()
        _apiKey.value = k
    }

    fun setProvider(p: String) {
        sp.edit().putString("provider", p).putString("model", "").putString("resolved_model", "").apply()
        _provider.value = p
        _model.value = ""
        _resolved.value = ""
    }

    fun setModel(m: String) {
        sp.edit().putString("model", m).apply()
        _model.value = m
    }

    fun setResolvedModel(m: String) {
        sp.edit().putString("resolved_model", m).apply()
        _resolved.value = m
    }

    fun setCrossfade(sec: Int) {
        sp.edit().putInt("crossfade", sec).apply()
        _crossfade.value = sec
    }

    fun setLimit(limit: Int) {
        sp.edit().putInt("limit", limit).apply()
        _limit.value = limit
    }

    fun addUsage(chars: Int) {
        val now = readUsed() + chars
        sp.edit().putString("used_month", month()).putInt("used", now).apply()
        _used.value = now
    }

    /** Aktuellen Wert neu einlesen (z. B. nach Monatswechsel). */
    fun refresh() {
        _used.value = readUsed()
    }
}
