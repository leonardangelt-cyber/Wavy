package app.wavy.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Einstellungen im privaten App-Speicher (nicht in Backups): API-Schlüssel, Monatslimit, Verbrauch. */
class SettingsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _apiKey = MutableStateFlow(sp.getString("api_key", "") ?: "")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    /** "gemini" (KI) oder "cloud" (Google Cloud Translation) */
    private val _provider = MutableStateFlow(sp.getString("provider", Provider.GEMINI) ?: Provider.GEMINI)
    val provider: StateFlow<String> = _provider.asStateFlow()

    /** Vom Nutzer gewähltes Modell, leer = automatisch */
    private val _model = MutableStateFlow(sp.getString("model", "") ?: "")
    val model: StateFlow<String> = _model.asStateFlow()

    /** Zuletzt automatisch gewähltes Modell */
    private val _resolved = MutableStateFlow(sp.getString("resolved_model", "") ?: "")
    val resolvedModel: StateFlow<String> = _resolved.asStateFlow()

    /** Überblenden zwischen Songs in Sekunden (0 = aus). Der Wiedergabe-Dienst liest den Wert direkt. */
    private val _crossfade = MutableStateFlow(sp.getInt("crossfade", 1))
    val crossfadeSec: StateFlow<Int> = _crossfade.asStateFlow()

    private val _lyricsOn = MutableStateFlow(sp.getBoolean("lyrics_on", true))
    val lyricsEnabled: StateFlow<Boolean> = _lyricsOn.asStateFlow()
    private val _karaoke = MutableStateFlow(sp.getBoolean("karaoke", true))
    val karaoke: StateFlow<Boolean> = _karaoke.asStateFlow()
    private val _resumeOn = MutableStateFlow(sp.getBoolean("resume_on", true))
    val resumeEnabled: StateFlow<Boolean> = _resumeOn.asStateFlow()
    private val _stopOnClose = MutableStateFlow(sp.getBoolean("stop_on_close", true))
    val stopOnClose: StateFlow<Boolean> = _stopOnClose.asStateFlow()

    private val _eqOn = MutableStateFlow(sp.getBoolean("eq_on", false))
    val eqOn: StateFlow<Boolean> = _eqOn.asStateFlow()
    private val _eqPreset = MutableStateFlow(sp.getInt("eq_preset", 0))
    val eqPreset: StateFlow<Int> = _eqPreset.asStateFlow()
    private val _normalize = MutableStateFlow(sp.getBoolean("normalize", false))
    val normalize: StateFlow<Boolean> = _normalize.asStateFlow()
    private val _reduce = MutableStateFlow(sp.getBoolean("reduce_motion", false))
    val reduceMotion: StateFlow<Boolean> = _reduce.asStateFlow()
    private val _haptics = MutableStateFlow(sp.getBoolean("haptics", true))
    val haptics: StateFlow<Boolean> = _haptics.asStateFlow()
    private val _lyricsSize = MutableStateFlow(sp.getInt("lyrics_size", 1))
    val lyricsSize: StateFlow<Int> = _lyricsSize.asStateFlow()

    fun setEqOn(b: Boolean) { sp.edit().putBoolean("eq_on", b).apply(); _eqOn.value = b }
    fun setEqPreset(i: Int) { sp.edit().putInt("eq_preset", i).apply(); _eqPreset.value = i }
    fun setNormalize(b: Boolean) { sp.edit().putBoolean("normalize", b).apply(); _normalize.value = b }
    fun setReduceMotion(b: Boolean) { sp.edit().putBoolean("reduce_motion", b).apply(); _reduce.value = b; Perf.reduceMotion = b }
    fun setHaptics(b: Boolean) { sp.edit().putBoolean("haptics", b).apply(); _haptics.value = b; Perf.haptics = b }
    fun setLyricsSize(i: Int) { sp.edit().putInt("lyrics_size", i).apply(); _lyricsSize.value = i }

    /** Einstellungen als JSON für die Sicherung (ohne Schlüssel und Verbrauchszähler). */
    fun exportJson(): org.json.JSONObject {
        val o = org.json.JSONObject()
        val skip = setOf("api_key", "used", "used_month", "resolved_model")
        for ((k, v) in sp.all) {
            if (k in skip || v == null) continue
            o.put(k, org.json.JSONObject().put("t", when (v) { is Boolean -> "b"; is Int -> "i"; is Long -> "l"; is Float -> "f"; else -> "s" }).put("v", v.toString()))
        }
        return o
    }

    fun importJson(o: org.json.JSONObject) {
        val e = sp.edit()
        for (k in o.keys()) {
            if (k == "api_key") continue
            val d = o.optJSONObject(k) ?: continue
            val v = d.optString("v")
            when (d.optString("t")) {
                "b" -> e.putBoolean(k, v == "true")
                "i" -> e.putInt(k, v.toIntOrNull() ?: continue)
                "l" -> e.putLong(k, v.toLongOrNull() ?: continue)
                "f" -> e.putFloat(k, v.toFloatOrNull() ?: continue)
                else -> e.putString(k, v)
            }
        }
        e.apply()
        _eqOn.value = sp.getBoolean("eq_on", false)
        _eqPreset.value = sp.getInt("eq_preset", 0)
        _normalize.value = sp.getBoolean("normalize", false)
        _reduce.value = sp.getBoolean("reduce_motion", false); Perf.reduceMotion = _reduce.value
        _haptics.value = sp.getBoolean("haptics", true); Perf.haptics = _haptics.value
        _lyricsSize.value = sp.getInt("lyrics_size", 1)
        _crossfade.value = sp.getInt("crossfade", 1)
        _lyricsOn.value = sp.getBoolean("lyrics_on", true)
        _karaoke.value = sp.getBoolean("karaoke", true)
        _resumeOn.value = sp.getBoolean("resume_on", true)
        _stopOnClose.value = sp.getBoolean("stop_on_close", true)
        _provider.value = sp.getString("provider", Provider.GEMINI) ?: Provider.GEMINI
        _model.value = sp.getString("model", "") ?: ""
        _limit.value = sp.getInt("limit", 50_000)
    }

    /** Zuletzt gewählte Überblend-Dauer (> 0), damit der Schalter sie wiederherstellen kann */
    val lastCrossfade: Int get() = sp.getInt("last_crossfade", 3).coerceAtLeast(1)

    fun setLyricsEnabled(b: Boolean) { sp.edit().putBoolean("lyrics_on", b).apply(); _lyricsOn.value = b }
    fun setKaraoke(b: Boolean) { sp.edit().putBoolean("karaoke", b).apply(); _karaoke.value = b }
    fun setResumeEnabled(b: Boolean) { sp.edit().putBoolean("resume_on", b).apply(); _resumeOn.value = b }
    fun setStopOnClose(b: Boolean) { sp.edit().putBoolean("stop_on_close", b).apply(); _stopOnClose.value = b }

    private val _limit = MutableStateFlow(sp.getInt("limit", 50_000))
    val monthlyLimit: StateFlow<Int> = _limit.asStateFlow()

    private val _used = MutableStateFlow(readUsed())
    val usedChars: StateFlow<Int> = _used.asStateFlow()

    private fun month(): String = SimpleDateFormat("yyyyMM", Locale.US).format(Date())

    private fun readUsed(): Int =
        if (sp.getString("used_month", "") == month()) sp.getInt("used", 0) else 0

    fun setApiKey(key: String) {
        val k = key.trim()
        sp.edit().putString("api_key", k).apply()
        _apiKey.value = k
    }

    fun setProvider(p: String) {
        sp.edit().putString("provider", p).putString("model", "").putString("resolved_model", "").apply()
        _provider.value = p
        _model.value = ""
        _resolved.value = ""
    }

    fun setModel(m: String) {
        sp.edit().putString("model", m).apply()
        _model.value = m
    }

    fun setResolvedModel(m: String) {
        sp.edit().putString("resolved_model", m).apply()
        _resolved.value = m
    }

    fun setCrossfade(sec: Int) {
        sp.edit().putInt("crossfade", sec).also { if (sec > 0) it.putInt("last_crossfade", sec) }.apply()
        _crossfade.value = sec
    }

    fun setLimit(limit: Int) {
        sp.edit().putInt("limit", limit).apply()
        _limit.value = limit
    }

    fun addUsage(chars: Int) {
        val now = readUsed() + chars
        sp.edit().putString("used_month", month()).putInt("used", now).apply()
        _used.value = now
    }

    /** Aktuellen Wert neu einlesen (z. B. nach Monatswechsel). */
    fun refresh() {
        _used.value = readUsed()
    }
}
