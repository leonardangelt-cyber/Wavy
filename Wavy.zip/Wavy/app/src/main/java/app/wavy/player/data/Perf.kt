package app.wavy.player.data

import android.app.ActivityManager
import android.content.Context

/** Erkennt schwache Geräte, damit die App dort sparsamer animiert und weniger Speicher belegt. */
object Perf {
    @Volatile
    private var deviceLow: Boolean = false

    /** Schalter "Weniger Animationen" in den Einstellungen */
    @Volatile
    var reduceMotion: Boolean = false

    /** Schalter "Vibrationsfeedback" */
    @Volatile
    var haptics: Boolean = true

    val low: Boolean get() = deviceLow || reduceMotion

    fun init(ctx: Context) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        deviceLow = am?.isLowRamDevice == true || (am?.memoryClass ?: 256) <= 192
        val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        reduceMotion = sp.getBoolean("reduce_motion", false)
        haptics = sp.getBoolean("haptics", true)
    }

    /** Pause zwischen Fortschrittsaktualisierungen bei geöffnetem Player (ms). */
    val positionTickMs: Long get() = if (low) 100L else 50L

    /** Kantenlänge großer Cover in Pixeln. */
    val bigCoverPx: Int get() = if (low) 480 else 640
}
