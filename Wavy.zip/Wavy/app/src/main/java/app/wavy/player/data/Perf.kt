package app.wavy.player.data

import android.app.ActivityManager
import android.content.Context

/** Erkennt schwache Geräte, damit die App dort sparsamer animiert und weniger Speicher belegt. */
object Perf {
    @Volatile
    var low: Boolean = false
        private set

    fun init(ctx: Context) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        low = am?.isLowRamDevice == true || (am?.memoryClass ?: 256) <= 192
    }

    /** Pause zwischen Fortschrittsaktualisierungen bei geöffnetem Player (ms). */
    val positionTickMs: Long get() = if (low) 100L else 50L

    /** Kantenlänge großer Cover in Pixeln. */
    val bigCoverPx: Int get() = if (low) 480 else 640
}
