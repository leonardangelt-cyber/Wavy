package app.wavy.player

import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.mutableLongStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.palette.graphics.Palette
import app.wavy.player.data.AppSig
import app.wavy.player.data.CoverLoader
import app.wavy.player.data.KeyState
import app.wavy.player.data.KeyStatus
import app.wavy.player.data.LyricsRepository
import app.wavy.player.data.LyricsUi
import app.wavy.player.data.MediaRepository
import app.wavy.player.data.PlaylistStore
import app.wavy.player.data.SettingsStore
import app.wavy.player.data.Song
import app.wavy.player.data.TranslationRepository
import app.wavy.player.data.TranslationStatus
import app.wavy.player.data.TranslationUi
import java.util.Locale
import app.wavy.player.playback.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

data class PlayerUi(
    val mediaId: Long? = null,
    val isPlaying: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val shuffle: Boolean = false,
    val durationMs: Long = 0L,
    val prevId: Long? = null,
    val nextId: Long? = null,
)

class MusicViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val store = PlaylistStore(ctx)
    private val lyricsRepo = LyricsRepository(ctx)
    val settings = SettingsStore(ctx)
    private val translationRepo = TranslationRepository(ctx, settings)

    private val _translation = MutableStateFlow(TranslationUi())
    val translation: StateFlow<TranslationUi> = _translation.asStateFlow()

    private fun targetLang(): String = Locale.getDefault().language

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    val playlists = store.playlists

    /** Songs, die in mindestens einer "nicht auf Startseite abspielen"-Playlist stecken. */
    val excludedIds: StateFlow<Set<Long>> = playlists
        .map { l -> l.filter { it.excludeFromHome }.flatMap { it.songIds }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private val _player = MutableStateFlow(PlayerUi())
    val player: StateFlow<PlayerUi> = _player.asStateFlow()

    /** Aktuelle Position. Wird nur in Zeichen-/Mini-Bereichen gelesen, damit nichts neu komponiert wird. */
    val positionMs = mutableLongStateOf(0L)

    private val _seed = MutableStateFlow<Int?>(null)
    val seed: StateFlow<Int?> = _seed.asStateFlow()

    private val _lyrics = MutableStateFlow(LyricsUi())
    val lyrics: StateFlow<LyricsUi> = _lyrics.asStateFlow()

    val currentSong: StateFlow<Song?> = combine(_songs, _player) { s, p -> s.firstOrNull { it.id == p.mediaId } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private var controller: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            syncState(player)
        }
    }

    init {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                syncState(c)
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(ctx))

        // Fortschritt aktualisieren
        viewModelScope.launch {
            while (true) {
                delay(16)
                controller?.let { if (it.isPlaying) positionMs.longValue = it.currentPosition.coerceAtLeast(0L) }
            }
        }

        // Cover-Farbe + Songtext, sobald sich der Song ändert (alles im Hintergrund)
        viewModelScope.launch {
            currentSong.map { it?.id }.distinctUntilChanged().collectLatest {
                val song = currentSong.value
                if (song == null) {
                    _seed.value = null
                    _lyrics.value = LyricsUi()
                    return@collectLatest
                }
                _lyrics.value = LyricsUi(loading = true)
                _translation.value = TranslationUi()
                coroutineScope {
                    launch { _seed.value = computeSeed(song) }
                    var result = LyricsUi(error = true)
                    for (attempt in 0 until 4) {
                        result = lyricsRepo.get(song)
                        if (!result.error) break
                        _lyrics.value = result // zeigt "offline", wird im Hintergrund erneut versucht
                        delay(10_000)
                    }
                    _lyrics.value = result
                    translationRepo.cached(song, targetLang())?.let { _translation.value = it }
                }
            }
        }
    }

    private fun neighborId(p: Player, index: Int): Long? =
        if (index == C.INDEX_UNSET || index < 0 || index >= p.mediaItemCount) null
        else p.getMediaItemAt(index).mediaId.toLongOrNull()

    private fun syncState(p: Player) {
        _player.value = PlayerUi(
            mediaId = p.currentMediaItem?.mediaId?.toLongOrNull(),
            isPlaying = p.isPlaying,
            repeat = p.repeatMode,
            shuffle = p.shuffleModeEnabled,
            durationMs = p.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L,
            prevId = neighborId(p, p.previousMediaItemIndex),
            nextId = neighborId(p, p.nextMediaItemIndex),
        )
        positionMs.longValue = p.currentPosition.coerceAtLeast(0L)
    }

    private suspend fun computeSeed(song: Song): Int? {
        val bmp = CoverLoader.load(ctx, song, 128) ?: return null
        return withContext(Dispatchers.Default) {
            val p = Palette.from(bmp).maximumColorCount(16).generate()
            (p.vibrantSwatch ?: p.dominantSwatch ?: p.mutedSwatch)?.rgb
        }
    }

    // ---------- Bibliothek ----------

    fun refreshSongs() {
        viewModelScope.launch {
            if (!MediaRepository.hasPermission(ctx)) return@launch
            _songs.value = withContext(Dispatchers.IO) { MediaRepository.loadSongs(ctx) }
            _loaded.value = true
        }
    }

    // ---------- Wiedergabe ----------

    private fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artistLabel)
                .setAlbumTitle(album.ifBlank { null })
                .build(),
        )
        .build()

    private fun playQueue(list: List<Song>, startId: Long?, shuffle: Boolean?) {
        val c = controller ?: return
        if (list.isEmpty()) return
        val idx = when {
            startId != null -> list.indexOfFirst { it.id == startId }.coerceAtLeast(0)
            shuffle == true -> Random.nextInt(list.size)
            else -> 0
        }
        if (shuffle != null) c.shuffleModeEnabled = shuffle
        c.setMediaItems(list.map { it.toMediaItem() }, idx, 0L)
        c.prepare()
        c.play()
    }

    /** Startbildschirm: "Alle abspielen" / "Shuffle" – ohne Songs aus ausgeschlossenen Playlists. */
    fun playHome(list: List<Song>, shuffle: Boolean) {
        val ex = excludedIds.value
        playQueue(list.filter { it.id !in ex }, null, shuffle)
    }

    /** Startbildschirm: Tippen auf einen Song. */
    fun playFromHome(list: List<Song>, tapped: Song) {
        val ex = excludedIds.value
        playQueue(list.filter { it.id !in ex || it.id == tapped.id }, tapped.id, null)
    }

    fun playPlaylist(list: List<Song>, shuffle: Boolean) = playQueue(list, null, shuffle)

    fun playPlaylistSong(list: List<Song>, tapped: Song) = playQueue(list, tapped.id, null)

    fun togglePlay() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0)
            c.play()
        }
    }

    fun next() { controller?.seekToNext() }
    fun prev() { controller?.seekToPrevious() }

    /** Wisch-Geste: wirklich zum vorherigen Titel (nicht nur an den Anfang). */
    fun previousTrack() { controller?.seekToPreviousMediaItem() }

    fun seekFraction(f: Float) {
        val c = controller ?: return
        val dur = _player.value.durationMs.takeIf { it > 0 } ?: currentSong.value?.durationMs ?: return
        val target = (dur * f).toLong()
        c.seekTo(target)
        positionMs.longValue = target
    }

    fun seekToMs(ms: Long) {
        controller?.seekTo(ms)
        positionMs.longValue = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    /** Aus -> Immer -> Einmal -> Aus */
    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // ---------- KI-Schlüssel ----------

    private val _keyStatus = MutableStateFlow(KeyStatus())
    val keyStatus: StateFlow<KeyStatus> = _keyStatus.asStateFlow()
    private var checkJob: Job? = null

    val appPackage: String = ctx.packageName
    val appSha1: String = AppSig.sha1(ctx)

    /** Prüft Schlüssel + Anbieter + Modell im Hintergrund und aktualisiert die Anzeige in den Einstellungen. */
    fun checkKey() {
        checkJob?.cancel()
        val key = settings.apiKey.value
        if (key.isBlank()) {
            _keyStatus.value = KeyStatus()
            return
        }
        _keyStatus.value = KeyStatus(KeyState.Checking, "Schlüssel wird geprüft …")
        checkJob = viewModelScope.launch {
            _keyStatus.value = translationRepo.checkKey(settings.provider.value, key, settings.model.value)
        }
    }

    // ---------- Übersetzung (nur auf Knopfdruck) ----------

    fun translateLyrics() {
        val song = currentSong.value ?: return
        val l = _lyrics.value
        val lines = when {
            l.lines.isNotEmpty() -> l.lines.map { it.text }
            l.plain != null -> l.plain.lines()
            else -> return
        }
        if (_translation.value.status == TranslationStatus.Loading) return
        _translation.value = TranslationUi(TranslationStatus.Loading)
        viewModelScope.launch {
            val r = translationRepo.translate(song, lines, targetLang())
            if (currentSong.value?.id == song.id) _translation.value = r
        }
    }

    // ---------- Playlists ----------

    fun createPlaylist(name: String): Long = store.create(name)
    fun renamePlaylist(id: Long, name: String) = store.rename(id, name)
    fun deletePlaylist(id: Long) = store.delete(id)
    fun setExclude(id: Long, exclude: Boolean) = store.setExclude(id, exclude)
    fun toggleSong(playlistId: Long, songId: Long) = store.toggleSong(playlistId, songId)
    fun removeSong(playlistId: Long, songId: Long) = store.removeSong(playlistId, songId)

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}
