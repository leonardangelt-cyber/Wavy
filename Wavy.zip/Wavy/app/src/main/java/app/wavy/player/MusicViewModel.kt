package app.wavy.player

import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.mutableLongStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.palette.graphics.Palette
import app.wavy.player.data.StatsStore
import app.wavy.player.data.ArtistRepository
import app.wavy.player.data.AlbumRepository
import app.wavy.player.data.AppSig
import app.wavy.player.data.CoverLoader
import app.wavy.player.data.Perf
import app.wavy.player.playback.SquareBitmapLoader
import app.wavy.player.ui.CoverColor
import app.wavy.player.ui.CoverPalette
import app.wavy.player.data.KeyState
import app.wavy.player.data.KeyStatus
import app.wavy.player.data.LyricsRepository
import app.wavy.player.data.WordAligner
import app.wavy.player.data.LyricsUi
import app.wavy.player.data.MediaRepository
import app.wavy.player.data.PlaylistStore
import app.wavy.player.data.SettingsStore
import app.wavy.player.data.Song
import app.wavy.player.data.TranslationRepository
import app.wavy.player.data.TranslationStatus
import app.wavy.player.data.TranslationUi
import java.util.Locale
import app.wavy.player.playback.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

data class PlayerUi(
    val mediaId: Long? = null,
    val isPlaying: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val shuffle: Boolean = false,
    val durationMs: Long = 0L,
    val prevId: Long? = null,
    val nextId: Long? = null,
    /** Kommende Titel in Abspielreihenfolge */
    val queue: List<Long> = emptyList(),
)

class MusicViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val store = PlaylistStore(ctx)
    private val lyricsRepo = LyricsRepository(ctx)
    private val aligner = WordAligner(ctx)
    private val statsStore = StatsStore(ctx)
    val stats = statsStore.stats
    val settings = SettingsStore(ctx)
    private val translationRepo = TranslationRepository(ctx, settings)
    private val albumRepo = AlbumRepository(ctx)

    suspend fun albumTracks(artist: String, album: String) = albumRepo.get(artist, album)
    suspend fun topSongs(artist: String) = albumRepo.topSongs(artist)
    suspend fun artistInfo(artist: String) = ArtistRepository.info(artist)

    private val _translation = MutableStateFlow(TranslationUi())
    val translation: StateFlow<TranslationUi> = _translation.asStateFlow()

    private fun targetLang(): String = Locale.getDefault().language

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    val playlists = store.playlists

    /** Songs, die in mindestens einer "nicht auf Startseite abspielen"-Playlist stecken. */
    val excludedIds: StateFlow<Set<Long>> = playlists
        .map { l -> l.filter { it.excludeFromHome }.flatMap { it.songIds }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    /** Songs, die in mindestens einer "in Bibliothek ausblenden"-Playlist stecken. */
    val hiddenIds: StateFlow<Set<Long>> = playlists
        .map { l -> l.filter { it.hideFromHome }.flatMap { it.songIds }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private val _player = MutableStateFlow(PlayerUi())
    val player: StateFlow<PlayerUi> = _player.asStateFlow()

    /** Aktuelle Position. Wird nur in Zeichen-/Mini-Bereichen gelesen, damit nichts neu komponiert wird. */
    val positionMs = mutableLongStateOf(0L)

    private val _seed = MutableStateFlow<CoverPalette?>(null)
    val seed: StateFlow<CoverPalette?> = _seed.asStateFlow()

    private val _lyrics = MutableStateFlow(LyricsUi())
    val lyrics: StateFlow<LyricsUi> = _lyrics.asStateFlow()

    val currentSong: StateFlow<Song?> = combine(_songs, _player) { s, p -> s.firstOrNull { it.id == p.mediaId } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private var controller: MediaController? = null

    /** Von der Oberfläche gesetzt: nur im Vordergrund wird der Fortschritt laufend aktualisiert. */
    @Volatile var foreground: Boolean = true
    @Volatile var playerOpen: Boolean = false

    /** Spulen: Musik wird weich leiser, beim Loslassen wieder lauter. */
    fun beginSeek() { controller?.volume = 0f }
    fun endSeek() { controller?.volume = 1f }

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
            mediaItem?.mediaId?.toLongOrNull()?.let { statsStore.record(it) }
        }

        override fun onEvents(player: Player, events: Player.Events) {
            // Nur bei echten Änderungen neu berechnen (Lautstärke-Rampen lösen sehr viele Ereignisse aus)
            if (events.containsAny(
                    Player.EVENT_PLAYBACK_STATE_CHANGED,
                    Player.EVENT_IS_PLAYING_CHANGED,
                    Player.EVENT_PLAY_WHEN_READY_CHANGED,
                    Player.EVENT_MEDIA_ITEM_TRANSITION,
                    Player.EVENT_TIMELINE_CHANGED,
                    Player.EVENT_REPEAT_MODE_CHANGED,
                    Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED,
                    Player.EVENT_POSITION_DISCONTINUITY,
                )
            ) {
                syncState(player)
            }
        }
    }

    init {
        Perf.init(ctx)
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                syncState(c)
                tryRestore()
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(ctx))

        // Fortschritt aktualisieren
        viewModelScope.launch {
            while (true) {
                val c = controller
                if (c != null && c.isPlaying && foreground) {
                    positionMs.longValue = c.currentPosition.coerceAtLeast(0L)
                    // Großer Player offen: flüssig; sonst reicht selten (spart Strom)
                    delay(if (playerOpen) Perf.positionTickMs else 250L)
                } else {
                    delay(300L)
                }
            }
        }

        // Cover-Farbe + Songtext, sobald sich der Song ändert (alles im Hintergrund)
        viewModelScope.launch {
            kotlinx.coroutines.flow.combine(currentSong.map { it?.id }.distinctUntilChanged(), settings.lyricsEnabled) { _, on -> on }.collectLatest { lyricsOn ->
                val song = currentSong.value
                if (song == null) {
                    _seed.value = null
                    _lyrics.value = LyricsUi()
                    return@collectLatest
                }
                _lyrics.value = if (lyricsOn) LyricsUi(loading = true) else LyricsUi(notFound = true)
                _translation.value = TranslationUi()
                coroutineScope {
                    launch { _seed.value = computeSeed(song) }
                    if (!lyricsOn) return@coroutineScope
                    var result = LyricsUi(error = true)
                    for (attempt in 0 until 4) {
                        result = lyricsRepo.get(song)
                        if (!result.error) break
                        _lyrics.value = result // zeigt "offline", wird im Hintergrund erneut versucht
                        delay(10_000)
                    }
                    _lyrics.value = result
                    // Wort-Zeiten aus dem Audio berechnen (im Hintergrund, wird pro Song gespeichert)
                    if (result.lines.isNotEmpty()) launch {
                        val w = try { aligner.align(song, result.lines) } catch (_: Throwable) { null }
                        if (w != null && currentSong.value?.id == song.id && _lyrics.value.lines === result.lines) {
                            _lyrics.value = _lyrics.value.copy(words = w)
                        }
                    }
                    translationRepo.cached(song, targetLang())?.let { _translation.value = it }
                    Unit
                }
            }
        }
    }

    private fun neighborId(p: Player, index: Int): Long? =
        if (index == C.INDEX_UNSET || index < 0 || index >= p.mediaItemCount) null
        else p.getMediaItemAt(index).mediaId.toLongOrNull()

    private fun upcoming(p: Player): List<Long> {
        val tl = p.currentTimeline
        if (tl.isEmpty) return emptyList()
        val start = p.currentMediaItemIndex
        val out = ArrayList<Long>()
        var i = tl.getNextWindowIndex(start, p.repeatMode, p.shuffleModeEnabled)
        while (i != C.INDEX_UNSET && i != start && out.size < 50) {
            p.getMediaItemAt(i).mediaId.toLongOrNull()?.let { out += it }
            i = tl.getNextWindowIndex(i, p.repeatMode, p.shuffleModeEnabled)
        }
        return out
    }

    // ---------- Fortsetzen nach Neustart ----------

    private var restored = false

    private fun saveResume() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return
        val sb = StringBuilder()
        for (i in 0 until c.mediaItemCount) {
            if (i > 0) sb.append(',')
            sb.append(c.getMediaItemAt(i).mediaId)
        }
        ctx.getSharedPreferences("resume", android.content.Context.MODE_PRIVATE).edit()
            .putString("ids", sb.toString())
            .putLong("cur", c.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L)
            .putLong("pos", c.currentPosition.coerceAtLeast(0L))
            .putBoolean("shuf", c.shuffleModeEnabled)
            .putInt("rep", c.repeatMode)
            .apply()
    }

    /** Stellt Warteschlange und Position vom letzten Mal wieder her (pausiert, nichts startet von selbst). */
    private fun tryRestore() {
        if (restored) return
        val c = controller ?: return
        if (!_loaded.value) return
        restored = true
        if (!settings.resumeEnabled.value) return
        if (c.mediaItemCount > 0) return
        val sp = ctx.getSharedPreferences("resume", android.content.Context.MODE_PRIVATE)
        val ids = (sp.getString("ids", "") ?: "").split(',').mapNotNull { it.toLongOrNull() }
        if (ids.isEmpty()) return
        val byId = _songs.value.associateBy { it.id }
        val list = ids.mapNotNull { byId[it] }
        if (list.isEmpty()) return
        val cur = sp.getLong("cur", -1L)
        val idx = list.indexOfFirst { it.id == cur }.coerceAtLeast(0)
        c.shuffleModeEnabled = sp.getBoolean("shuf", false)
        c.repeatMode = sp.getInt("rep", Player.REPEAT_MODE_OFF)
        c.setMediaItems(list.map { it.toMediaItem() }, idx, sp.getLong("pos", 0L))
        c.prepare()
    }

    // ---------- Schlaftimer ----------

    private val _sleepLeftMin = MutableStateFlow(0)
    val sleepLeftMin: StateFlow<Int> = _sleepLeftMin.asStateFlow()
    private var sleepJob: kotlinx.coroutines.Job? = null

    /** 0 = aus. Am Ende wird die Musik acht Sekunden lang leiser und dann pausiert. */
    fun setSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        _sleepLeftMin.value = 0
        if (minutes <= 0) return
        sleepJob = viewModelScope.launch {
            val end = android.os.SystemClock.elapsedRealtime() + minutes * 60_000L
            while (true) {
                val left = end - android.os.SystemClock.elapsedRealtime()
                if (left <= 8_000L) break
                _sleepLeftMin.value = ((left + 59_999L) / 60_000L).toInt()
                delay(minOf(10_000L, left - 8_000L).coerceAtLeast(200L))
            }
            _sleepLeftMin.value = 1
            val t0 = android.os.SystemClock.elapsedRealtime()
            while (true) {
                val f = (android.os.SystemClock.elapsedRealtime() - t0) / 8_000f
                if (f >= 1f) break
                controller?.volume = 1f - f
                delay(50L)
            }
            controller?.pause()
            delay(700L)
            controller?.volume = 1f
            _sleepLeftMin.value = 0
        }
    }

    /** Nimmt einen Titel aus der Warteschlange. */
    fun removeQueueItem(id: Long) {
        val c = controller ?: return
        for (i in 0 until c.mediaItemCount) {
            if (c.getMediaItemAt(i).mediaId == id.toString()) {
                if (i != c.currentMediaItemIndex) c.removeMediaItem(i)
                return
            }
        }
    }

    /** Verschiebt einen Titel der Warteschlange auf den Platz des Titels [toId]; mit Shuffle ändert es die Shuffle-Reihenfolge. */
    fun moveQueueItem(id: Long, toId: Long) {
        val c = controller ?: return
        if (c.shuffleModeEnabled) {
            c.sendCustomCommand(
                androidx.media3.session.SessionCommand(PlaybackService.CMD_MOVE_SHUFFLE, android.os.Bundle.EMPTY),
                android.os.Bundle().apply { putString("id", id.toString()); putString("to", toId.toString()) },
            )
            return
        }
        var from = -1
        var to = -1
        for (i in 0 until c.mediaItemCount) {
            val m = c.getMediaItemAt(i).mediaId
            if (m == id.toString()) from = i
            if (m == toId.toString()) to = i
        }
        if (from >= 0 && to >= 0 && from != to) c.moveMediaItem(from, to)
    }

    /** Springt in der aktuellen Warteschlange zu diesem Titel. */
    /** "Als Nächstes spielen" bzw. "Ans Ende der Warteschlange". */
    fun enqueue(song: Song, next: Boolean) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playQueue(listOf(song), song.id, false)
            return
        }
        if (next) {
            val firstUpcoming = _player.value.queue.firstOrNull()
            c.addMediaItem((c.currentMediaItemIndex + 1).coerceAtMost(c.mediaItemCount), song.toMediaItem())
            if (c.shuffleModeEnabled && firstUpcoming != null && firstUpcoming != song.id) moveQueueItem(song.id, firstUpcoming)
        } else {
            c.addMediaItem(song.toMediaItem())
        }
    }

    /** Aktuelle Warteschlange (laufender Titel + kommende) als neue Playlist speichern. */
    fun saveQueueAsPlaylist(name: String) {
        val ids = listOfNotNull(_player.value.mediaId) + _player.value.queue
        val pid = store.create(name)
        store.addSongs(pid, ids)
    }

    fun playQueueItem(id: Long) {
        val c = controller ?: return
        for (i in 0 until c.mediaItemCount) {
            if (c.getMediaItemAt(i).mediaId == id.toString()) {
                c.seekTo(i, 0L)
                c.play()
                return
            }
        }
    }

    private fun syncState(p: Player) {
        _player.value = PlayerUi(
            mediaId = p.currentMediaItem?.mediaId?.toLongOrNull(),
            isPlaying = p.playWhenReady && p.playbackState != Player.STATE_ENDED && p.playbackState != Player.STATE_IDLE,
            repeat = p.repeatMode,
            shuffle = p.shuffleModeEnabled,
            durationMs = p.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L,
            prevId = neighborId(p, p.previousMediaItemIndex),
            nextId = neighborId(p, p.nextMediaItemIndex),
            queue = upcoming(p),
        )
        positionMs.longValue = p.currentPosition.coerceAtLeast(0L)
    }

    private suspend fun computeSeed(song: Song): CoverPalette? {
        val bmp = CoverLoader.load(ctx, song, 160) ?: return null
        return withContext(Dispatchers.Default) {
            CoverColor.cached(song.id) ?: CoverColor.analyze(bmp).also { CoverColor.put(song.id, it) }
        }
    }

    // ---------- Bibliothek ----------

    private var mediaObserver: android.database.ContentObserver? = null
    private var refreshJob: kotlinx.coroutines.Job? = null

    /** Neue/gelöschte Dateien werden automatisch erkannt, die Listen aktualisieren sich damit von selbst. */
    private fun watchMedia() {
        if (mediaObserver != null) return
        val obs = object : android.database.ContentObserver(android.os.Handler(android.os.Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                refreshJob?.cancel()
                refreshJob = viewModelScope.launch {
                    delay(1500)
                    refreshSongs()
                }
            }
        }
        try {
            ctx.contentResolver.registerContentObserver(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, obs)
            mediaObserver = obs
        } catch (_: Exception) {
        }
    }

    fun refreshSongs() {
        watchMedia()
        viewModelScope.launch {
            if (!MediaRepository.hasPermission(ctx)) return@launch
            _songs.value = withContext(Dispatchers.IO) { MediaRepository.loadSongs(ctx) }
            _loaded.value = true
            tryRestore()
        }
    }

    // ---------- Wiedergabe ----------

    private fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artistLabel)
                .setAlbumTitle(album.ifBlank { null })
                .setDurationMs(durationMs)
                .setArtworkUri(SquareBitmapLoader.artworkUri(this@toMediaItem))
                .setIsPlayable(true)
                .setIsBrowsable(false)
                .build(),
        )
        .build()

    private fun playQueue(list: List<Song>, startId: Long?, shuffle: Boolean?) {
        val c = controller ?: return
        if (list.isEmpty()) return
        val idx = when {
            startId != null -> list.indexOfFirst { it.id == startId }.coerceAtLeast(0)
            shuffle == true -> Random.nextInt(list.size)
            else -> 0
        }
        if (shuffle != null) c.shuffleModeEnabled = shuffle
        c.setMediaItems(list.map { it.toMediaItem() }, idx, 0L)
        c.prepare()
        c.play()
    }

    /** Startbildschirm: "Alle abspielen" / "Shuffle" – ohne Songs aus ausgeschlossenen Playlists. */
    fun playHome(list: List<Song>, shuffle: Boolean) {
        val ex = excludedIds.value
        playQueue(list.filter { it.id !in ex }, null, shuffle)
    }

    /** Startbildschirm: Tippen auf einen Song. */
    fun playFromHome(list: List<Song>, tapped: Song) {
        val ex = excludedIds.value
        playQueue(list.filter { it.id !in ex || it.id == tapped.id }, tapped.id, null)
    }

    fun playPlaylist(list: List<Song>, shuffle: Boolean) = playQueue(list, null, shuffle)

    fun playPlaylistSong(list: List<Song>, tapped: Song) = playQueue(list, tapped.id, null)

    fun togglePlay() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return
        if (c.playWhenReady && c.playbackState != Player.STATE_ENDED) c.pause() else {
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0)
            c.play()
        }
    }

    fun next() { controller?.seekToNext() }
    fun prev() { controller?.seekToPrevious() }

    /** Wisch-Geste: wirklich zum vorherigen Titel (nicht nur an den Anfang). */
    fun previousTrack() { controller?.seekToPreviousMediaItem() }

    fun seekFraction(f: Float) {
        val c = controller ?: return
        val dur = _player.value.durationMs.takeIf { it > 0 } ?: currentSong.value?.durationMs ?: return
        val target = (dur * f).toLong()
        c.seekTo(target)
        positionMs.longValue = target
    }

    fun seekToMs(ms: Long) {
        controller?.seekTo(ms)
        positionMs.longValue = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    /** Aus -> Immer -> Einmal -> Aus */
    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // ---------- KI-Schlüssel ----------

    private val _keyStatus = MutableStateFlow(KeyStatus())
    val keyStatus: StateFlow<KeyStatus> = _keyStatus.asStateFlow()
    private var checkJob: Job? = null

    val appPackage: String = ctx.packageName
    val appSha1: String = AppSig.sha1(ctx)

    /** Prüft Schlüssel + Anbieter + Modell im Hintergrund und aktualisiert die Anzeige in den Einstellungen. */
    fun checkKey() {
        checkJob?.cancel()
        val key = settings.apiKey.value
        if (key.isBlank()) {
            _keyStatus.value = KeyStatus()
            return
        }
        _keyStatus.value = KeyStatus(KeyState.Checking, "Schlüssel wird geprüft …")
        checkJob = viewModelScope.launch {
            _keyStatus.value = translationRepo.checkKey(settings.provider.value, key, settings.model.value)
        }
    }

    // ---------- Übersetzung (nur auf Knopfdruck) ----------

    fun saveCustomLyrics(text: String) {
        val song = currentSong.value ?: return
        viewModelScope.launch { _lyrics.value = lyricsRepo.saveCustom(song, text) }
    }

    /** Erstellt per KI eine Playlist aus der eigenen Bibliothek. onDone: Fehlertext oder null bei Erfolg. */
    fun createAiPlaylist(request: String, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            val r = translationRepo.suggestPlaylist(request, _songs.value)
            if (r.error != null) {
                onDone(r.error)
            } else {
                val pid = store.create(r.name)
                store.addSongs(pid, r.ids)
                onDone(null)
            }
        }
    }

    fun deleteCustomLyrics() {
        val song = currentSong.value ?: return
        lyricsRepo.deleteCustom(song)
        _lyrics.value = LyricsUi(loading = true)
        viewModelScope.launch {
            val r = try { lyricsRepo.get(song) } catch (_: Exception) { LyricsUi(notFound = true) }
            if (currentSong.value?.id == song.id) _lyrics.value = r
        }
    }

    fun translateLyrics() {
        val song = currentSong.value ?: return
        val l = _lyrics.value
        val lines = when {
            l.lines.isNotEmpty() -> l.lines.map { it.text }
            l.plain != null -> l.plain.lines()
            else -> return
        }
        if (_translation.value.status == TranslationStatus.Loading) return
        _translation.value = TranslationUi(TranslationStatus.Loading)
        viewModelScope.launch {
            val r = translationRepo.translate(song, lines, targetLang())
            if (currentSong.value?.id == song.id) _translation.value = r
        }
    }

    // ---------- Playlists ----------

    fun exportBackup(uri: android.net.Uri): Boolean {
        return try {
            val o = org.json.JSONObject().put("app", "wavy").put("version", 1)
                .put("playlists", store.exportJson()).put("settings", settings.exportJson())
            val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: return false
            out.use { it.write(o.toString().toByteArray()) }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun importBackup(uri: android.net.Uri): Boolean {
        return try {
            val txt = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return false
            val o = org.json.JSONObject(txt)
            if (o.optString("app") != "wavy") return false
            store.importJson(o.getJSONArray("playlists"))
            settings.importJson(o.getJSONObject("settings"))
            true
        } catch (_: Exception) {
            false
        }
    }

    fun createPlaylist(name: String): Long = store.create(name)
    fun renamePlaylist(id: Long, name: String) = store.rename(id, name)
    fun deletePlaylist(id: Long) = store.delete(id)
    fun setExclude(id: Long, exclude: Boolean) = store.setExclude(id, exclude)
    fun setHide(id: Long, hide: Boolean) = store.setHide(id, hide)
    fun toggleSong(playlistId: Long, songId: Long) = store.toggleSong(playlistId, songId)
    fun removeSong(playlistId: Long, songId: Long) = store.removeSong(playlistId, songId)

    override fun onCleared() {
        mediaObserver?.let { try { ctx.contentResolver.unregisterContentObserver(it) } catch (_: Exception) {} }
        saveResume()
        sleepJob?.cancel()
        // App wird wirklich beendet: Wiedergabe stoppen (außer die Einstellung sagt etwas anderes)
        if (settings.stopOnClose.value) {
            controller?.run {
                pause()
                stop()
                clearMediaItems()
            }
        }
        controller?.release()
        controller = null
        super.onCleared()
    }
}
