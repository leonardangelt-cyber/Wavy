package app.wavy.player.ui

import android.app.RecoverableSecurityException
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Mehrere Dateien, die derselbe Song zu sein scheinen (gleicher Titel + Interpret, fast gleiche Länge). */
data class DupGroup(val key: String, val songs: List<Song>)

fun findDuplicates(songs: List<Song>): List<DupGroup> {
    fun norm(s: String) = s.lowercase().replace(Regex("""[^\p{L}\p{N}]+"""), "")
    val out = ArrayList<DupGroup>()
    songs.filter { !it.isVideo }.groupBy { norm(it.title) + "|" + norm(it.artist) }.forEach { (k, l) ->
        if (l.size < 2 || k.startsWith("|")) return@forEach
        var cur = ArrayList<Song>()
        for (s in l.sortedBy { it.durationMs }) {
            if (cur.isEmpty() || s.durationMs - cur.last().durationMs <= 3000L) {
                cur.add(s)
            } else {
                if (cur.size > 1) out += DupGroup(k, cur.sortedBy { it.dateAdded })
                cur = arrayListOf(s)
            }
        }
        if (cur.size > 1) out += DupGroup(k, cur.sortedBy { it.dateAdded })
    }
    return out.sortedBy { it.songs.first().title.lowercase() }
}

private fun ignored(ctx: Context): Set<String> =
    ctx.getSharedPreferences("dups", Context.MODE_PRIVATE).getStringSet("ignored", emptySet()) ?: emptySet()

private fun ignore(ctx: Context, keys: Collection<String>) {
    val sp = ctx.getSharedPreferences("dups", Context.MODE_PRIVATE)
    sp.edit().putStringSet("ignored", ignored(ctx) + keys).apply()
}

/** Fragt nach dem Start einmal, ob doppelte Songs gelöscht werden sollen. */
@Composable
fun DuplicateHost(songs: List<Song>, loaded: Boolean, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var asked by rememberSaveable { mutableStateOf(false) }
    var groups by remember { mutableStateOf<List<DupGroup>>(emptyList()) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { onChanged() }

    LaunchedEffect(loaded, songs.size) {
        if (loaded && !asked && songs.isNotEmpty()) {
            asked = true
            val ign = ignored(ctx)
            groups = withContext(Dispatchers.Default) { findDuplicates(songs).filter { it.key !in ign } }
        }
    }
    if (groups.isEmpty()) return

    // Standard: der älteste Eintrag jeder Gruppe bleibt, alle weiteren sind zum Löschen vorgemerkt
    val selected = remember(groups) {
        mutableStateListOf<Long>().also { l -> groups.forEach { g -> g.songs.drop(1).forEach { l.add(it.id) } } }
    }
    val count = groups.sumOf { it.songs.size }

    AlertDialog(
        onDismissRequest = { groups = emptyList() },
        title = { Text("Doppelte Songs gefunden") },
        text = {
            Column {
                Text(
                    "$count Dateien gehören zu ${groups.size} Songs, die mehrfach vorhanden sind. Markierte Dateien werden gelöscht, der älteste Eintrag bleibt standardmäßig erhalten.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                LazyColumn(Modifier.heightIn(max = 340.dp).padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    groups.forEach { g ->
                        item(key = "h" + g.key + g.songs.first().id) {
                            Text(
                                g.songs.first().title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                        items(g.songs, key = { "s" + it.id }) { s ->
                            val on = s.id in selected
                            Row(
                                Modifier.fillMaxWidth().clickable { if (on) selected.remove(s.id) else selected.add(s.id) },
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Checkbox(checked = on, onCheckedChange = { if (on) selected.remove(s.id) else selected.add(s.id) })
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        s.relativePath.ifBlank { "Unbekannter Ordner" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    val sec = s.durationMs / 1000
                                    Text(
                                        "%d:%02d · %s".format(sec / 60, sec % 60, s.artistLabel),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selected.isNotEmpty(),
                onClick = {
                    val del = groups.flatMap { it.songs }.filter { it.id in selected }
                    groups = emptyList()
                    deleteSongs(ctx, del, { launcher.launch(it) }, onChanged)
                },
            ) { Text("Markierte löschen (${selected.size})") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { ignore(ctx, groups.map { it.key }); groups = emptyList() }) { Text("Nicht mehr fragen") }
                TextButton(onClick = { groups = emptyList() }) { Text("Später") }
            }
        },
    )
}

/** Android fragt beim Löschen fremder Dateien selbst um Erlaubnis; danach wird die Bibliothek neu geladen. */
private fun deleteSongs(ctx: Context, list: List<Song>, launch: (IntentSenderRequest) -> Unit, done: () -> Unit) {
    if (list.isEmpty()) return
    try {
        if (Build.VERSION.SDK_INT >= 30) {
            val pi = MediaStore.createDeleteRequest(ctx.contentResolver, list.map { it.uri })
            launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            for (s in list) {
                try {
                    ctx.contentResolver.delete(s.uri, null, null)
                } catch (e: SecurityException) {
                    val rse = e as? RecoverableSecurityException
                    if (rse != null) {
                        launch(IntentSenderRequest.Builder(rse.userAction.actionIntent.intentSender).build())
                        return
                    }
                }
            }
            done()
        }
    } catch (_: Exception) {
        done()
    }
}
