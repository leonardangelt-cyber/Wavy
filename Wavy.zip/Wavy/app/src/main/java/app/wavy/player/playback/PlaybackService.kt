package app.wavy.player.playback

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Spielt Musik im Hintergrund.
 *
 * - Weiches Ein-/Ausblenden bei Play, Pause und Spulen (kurze Lautstärke-Rampe statt hartem Schnitt).
 * - Überblenden: Ein zweiter Player ("Ausläufer") spielt das Ende des alten Songs weiter, während der neue
 *   im Hauptplayer startet. Der alte Song läuft mit voller Lautstärke, bis der neue wirklich hörbar spielt;
 *   erst dann wird (Equal-Power) übergeblendet. So gibt es keine Lücke.
 * - Der Taktgeber läuft nur so oft wie nötig (spart Akku).
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var main: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    // Lautstärke = Rampe (Play/Pause/Spulen) * Überblendung
    private var userGain = 1f
    private var userTarget = 1f
    private var pendingPause = false
    private var rampLast = 0L
    private var xGain = 1f

    // Überblenden
    private var tail: ExoPlayer? = null
    private var armedId: String? = null
    private var fading = false
    private var fadeStart = 0L
    private var fadeClock = -1L
    private var fadeMs = 0L
    private var fadeTargetId: String? = null

    private val tick = object : Runnable {
        override fun run() {
            val next = try {
                step()
            } catch (_: Exception) {
                abortFade()
                500L
            }
            handler.postDelayed(this, next)
        }
    }

    private fun kick() {
        rampLast = SystemClock.elapsedRealtime()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun applyVolume() {
        val g = userGain * userGain
        main?.volume = (g * xGain).coerceIn(0f, 1f)
    }

    private fun requestPlay() {
        val p = main ?: return
        pendingPause = false
        if (!p.playWhenReady) {
            userGain = 0f
            applyVolume()
        }
        userTarget = 1f
        p.play()
        kick()
    }

    private fun requestPause() {
        val p = main ?: return
        if (!p.playWhenReady) return
        if (!p.isPlaying) {
            p.pause()
            return
        }
        userTarget = 0f
        pendingPause = true
        kick()
    }

    private inner class FadingPlayer(p: ExoPlayer) : ForwardingPlayer(p) {
        override fun play() = requestPlay()
        override fun pause() = requestPause()
        override fun setPlayWhenReady(playWhenReady: Boolean) {
            if (playWhenReady) requestPlay() else requestPause()
        }
        /** Die App senkt beim Spulen die Lautstärke (0) und hebt sie danach wieder an (1). */
        override fun setVolume(volume: Float) {
            if (!pendingPause) userTarget = volume.coerceIn(0f, 1f)
            kick()
        }
        override fun getVolume(): Float = userTarget
    }

    /** @return true, solange die Rampe noch läuft */
    private fun rampStep(now: Long): Boolean {
        if (userGain == userTarget) return false
        val dt = (now - rampLast).coerceAtLeast(0L)
        rampLast = now
        val down = userTarget < userGain
        val step = dt / (if (down) 200f else 280f)
        userGain = if (down) max(userTarget, userGain - step) else min(userTarget, userGain + step)
        applyVolume()
        if (pendingPause && userGain <= 0.001f) {
            pendingPause = false
            main?.pause()
        }
        return userGain != userTarget
    }

    private fun audioAttrs() = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .build()

    private fun fadeSeconds(): Int =
        getSharedPreferences("settings", Context.MODE_PRIVATE).getInt("crossfade", 1)

    private fun ensureTail(): ExoPlayer {
        tail?.let { return it }
        val t = ExoPlayer.Builder(this).setAudioAttributes(audioAttrs(), false).build()
        t.trackSelectionParameters = t.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()
        tail = t
        return t
    }

    private fun disarm() {
        armedId = null
        tail?.let {
            it.playWhenReady = false
            it.stop()
            it.clearMediaItems()
        }
    }

    private fun abortFade() {
        fading = false
        fadeTargetId = null
        xGain = 1f
        applyVolume()
        disarm()
    }

    /** @return Wartezeit bis zum nächsten Takt in ms */
    private fun step(): Long {
        val now = SystemClock.elapsedRealtime()
        var next = 1500L
        if (rampStep(now)) next = 16L
        val p = main ?: return next
        val t = tail

        // --- Überblendung läuft ---
        if (fading && t != null) {
            if (p.currentMediaItem?.mediaId != fadeTargetId) { // Nutzer hat in der Zwischenzeit gewechselt
                abortFade()
                return 16L
            }
            val ug = userGain * userGain
            if (fadeClock < 0L) {
                // Alter Song läuft voll weiter, bis der neue wirklich spielt
                if ((p.isPlaying && p.currentPosition > 40L) || now - fadeStart > 1000L) fadeClock = now
                xGain = 0f
                t.volume = ug
            } else {
                val f = ((now - fadeClock).toFloat() / fadeMs).coerceIn(0f, 1f)
                val ang = f * (Math.PI / 2).toFloat()
                xGain = sin(ang)
                t.volume = cos(ang) * ug
                if (f >= 1f || t.playbackState == Player.STATE_ENDED) {
                    fading = false
                    fadeTargetId = null
                    xGain = 1f
                    disarm()
                }
            }
            applyVolume()
            t.playWhenReady = p.playWhenReady
            return 16L
        }

        val sec = fadeSeconds()
        val cur = p.currentMediaItem
        val dur = p.duration
        val ok = sec > 0 && cur != null && p.hasNextMediaItem() && p.repeatMode != Player.REPEAT_MODE_ONE &&
            dur != C.TIME_UNSET && dur >= sec * 4000L + 5000L
        if (!ok) {
            if (armedId != null) disarm()
            return if (p.isPlaying) 1000L else next
        }
        val ms = sec * 1000L
        val trigger = dur - ms - 700L // 700 ms Vorlauf, bis der neue Song im Hauptplayer hörbar spielt
        val pos = p.currentPosition

        if (armedId != null && (armedId != cur!!.mediaId || pos < trigger - 7000L || pos > trigger + 600L)) disarm()
        if (armedId == null && p.isPlaying && pos >= trigger - 4000L && pos < trigger) {
            val tl = ensureTail()
            tl.volume = 1f
            tl.playWhenReady = false
            tl.setMediaItem(cur!!)
            tl.prepare()
            tl.seekTo(trigger)
            armedId = cur.mediaId
        }

        val a = tail
        if (armedId != null && a != null && p.isPlaying && pos >= trigger && pos <= trigger + 600L &&
            a.playbackState == Player.STATE_READY
        ) {
            val nextIdx = p.nextMediaItemIndex
            if (nextIdx != C.INDEX_UNSET) {
                fadeTargetId = p.getMediaItemAt(nextIdx).mediaId
                fadeMs = ms
                fadeStart = now
                fadeClock = -1L
                fading = true
                a.volume = userGain * userGain
                a.playWhenReady = true
                xGain = 0f
                applyVolume()
                p.seekToNextMediaItem()
                return 16L
            }
        }

        if (!p.isPlaying) return next
        if (armedId != null) return 30L
        val toWindow = trigger - 4000L - pos
        return if (toWindow <= 0L) 30L else (toWindow / 2).coerceIn(100L, 2000L)
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttrs(), true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        // MP4-Dateien: nur die Tonspur abspielen
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .build()
        main = player
        kick()

        session = MediaSession.Builder(this, FadingPlayer(player))
            .setCallback(object : MediaSession.Callback {
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>,
                ): ListenableFuture<MutableList<MediaItem>> {
                    val resolved = mediaItems.map {
                        it.buildUpon()
                            .setUri(it.requestMetadata.mediaUri ?: it.localConfiguration?.uri)
                            .build()
                    }.toMutableList()
                    return Futures.immediateFuture(resolved)
                }
            })
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** App aus der Übersicht gewischt: Wiedergabe beenden. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        abortFade()
        main?.run {
            pause()
            stop()
            clearMediaItems()
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tail?.release()
        tail = null
        session?.run {
            player.release()
            release()
        }
        session = null
        main = null
        super.onDestroy()
    }
}
