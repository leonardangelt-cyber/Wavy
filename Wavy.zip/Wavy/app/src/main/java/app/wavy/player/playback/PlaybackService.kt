package app.wavy.player.playback

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ShuffleOrder
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.LibraryResult
import com.google.common.collect.ImmutableList
import app.wavy.player.data.MediaRepository
import app.wavy.player.data.Song
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Spielt Musik im Hintergrund.
 *
 * - Weiches Ein-/Ausblenden bei Play, Pause und Spulen (kurze Lautstärke-Rampe statt hartem Schnitt).
 * - Überblenden: Ein zweiter Player ("Ausläufer") spielt das Ende des alten Songs weiter, während der neue
 *   im Hauptplayer startet. Der alte Song läuft mit voller Lautstärke, bis der neue wirklich hörbar spielt;
 *   erst dann wird (Equal-Power) übergeblendet. So gibt es keine Lücke.
 * - Der Taktgeber läuft nur so oft wie nötig (spart Akku).
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class PlaybackService : MediaLibraryService() {

    private var session: MediaLibrarySession? = null
    @Volatile private var songsCache: List<Song> = emptyList()
    @Volatile private var loadingSongs = false
    private var main: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    // Lautstärke = Rampe (Play/Pause/Spulen) * Überblendung
    private var userGain = 1f
    private var userTarget = 1f
    private var pendingPause = false
    private var ducked = false
    private var rampLast = 0L
    private var xGain = 1f
    private var rgGain = 1f
    private var eq: android.media.audiofx.Equalizer? = null
    private var eqSession = -1

    // Überblenden
    private var tail: ExoPlayer? = null
    private var tailStarted = false
    private var tailLat = 90L
    private var armedId: String? = null
    private var fading = false
    private var fadeStart = 0L
    private var fadeClock = -1L
    private var fadeMs = 0L
    private var fadeTargetId: String? = null

    private val tick = object : Runnable {
        override fun run() {
            val next = try {
                step()
            } catch (_: Exception) {
                abortFade()
                500L
            }
            handler.postDelayed(this, next)
        }
    }

    private fun kick() {
        rampLast = SystemClock.elapsedRealtime()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun applyVolume() {
        val g = userGain * userGain
        main?.volume = (g * xGain * rgGain).coerceIn(0f, 1f)
    }

    private val fxPrefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private val fxListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "eq_on" || key == "eq_preset") applyEq()
        if (key == "normalize") { updateReplayGain(); applyVolume() }
    }

    // Equalizer-Voreinstellungen in dB für fünf Frequenzbereiche (tief -> hoch)
    private val presets = arrayOf(
        floatArrayOf(0f, 0f, 0f, 0f, 0f),
        floatArrayOf(6f, 4f, 1f, 0f, 0f),
        floatArrayOf(-2f, 0f, 3f, 3f, 1f),
        floatArrayOf(0f, 0f, 0f, 4f, 6f),
        floatArrayOf(5f, 3f, -1f, 3f, 5f),
        floatArrayOf(-1f, 2f, 4f, 2f, -1f),
        floatArrayOf(4f, 2f, -2f, 2f, 4f),
    )

    private fun applyEq() {
        try {
            val sid = main?.audioSessionId ?: return
            if (sid == C.AUDIO_SESSION_ID_UNSET || sid == 0) return
            if (eq == null || eqSession != sid) {
                eq?.release()
                eq = android.media.audiofx.Equalizer(0, sid)
                eqSession = sid
            }
            val e = eq ?: return
            val on = fxPrefs.getBoolean("eq_on", false)
            e.enabled = on
            if (!on) return
            val pr = presets[fxPrefs.getInt("eq_preset", 0).coerceIn(0, presets.lastIndex)]
            val n = e.numberOfBands.toInt()
            val range = e.bandLevelRange
            for (b in 0 until n) {
                val pos = if (n <= 1) 0f else b.toFloat() / (n - 1) * 4f
                val lo = pos.toInt().coerceIn(0, 3)
                val db = pr[lo] + (pr[lo + 1] - pr[lo]) * (pos - lo)
                e.setBandLevel(b.toShort(), (db * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
        } catch (_: Exception) {
        }
    }

    private val gainRegex = Regex("-?[0-9]+(?:[.,][0-9]+)?")

    /** Liest ReplayGain-Angaben aus den Datei-Tags (falls vorhanden) und senkt zu laute Titel ab. */
    private fun updateReplayGain() {
        var f = 1f
        try {
            if (fxPrefs.getBoolean("normalize", false)) {
                val groups = main?.currentTracks?.groups
                if (groups != null) {
                    loop@ for (g in groups) {
                        for (i in 0 until g.length) {
                            val md = g.getTrackFormat(i).metadata ?: continue
                            for (j in 0 until md.length()) {
                                val en = md.get(j)
                                var key: String? = null
                                var value: String? = null
                                if (en is androidx.media3.extractor.metadata.id3.TextInformationFrame) {
                                    key = en.description
                                    value = en.values.firstOrNull()
                                } else if (en is androidx.media3.extractor.metadata.vorbis.VorbisComment) {
                                    key = en.key
                                    value = en.value
                                }
                                if (key != null && value != null && key.equals("REPLAYGAIN_TRACK_GAIN", true)) {
                                    val db = gainRegex.find(value)?.value?.replace(',', '.')?.toFloatOrNull()
                                    if (db != null) {
                                        f = Math.pow(10.0, db / 20.0).toFloat().coerceIn(0.05f, 1f)
                                        break@loop
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
        rgGain = f
    }

    private fun requestPlay() {
        val p = main ?: return
        pendingPause = false
        if (!p.playWhenReady) {
            userGain = 0f
            applyVolume()
        }
        userTarget = 1f
        p.play()
        kick()
    }

    private fun requestPause() {
        val p = main ?: return
        if (!p.playWhenReady) return
        if (!p.isPlaying) {
            p.pause()
            return
        }
        userTarget = 0f
        pendingPause = true
        kick()
    }

    private inner class FadingPlayer(p: ExoPlayer) : ForwardingPlayer(p) {
        override fun play() = requestPlay()
        override fun pause() = requestPause()
        override fun setPlayWhenReady(playWhenReady: Boolean) {
            if (playWhenReady) requestPlay() else requestPause()
        }
        /** Die App senkt beim Spulen die Lautstärke (0) und hebt sie danach wieder an (1). */
        override fun setVolume(volume: Float) {
            ducked = volume < 0.01f
            if (!pendingPause) userTarget = volume.coerceIn(0f, 1f)
            kick()
        }
        override fun getVolume(): Float = userTarget
    }

    /** @return true, solange die Rampe noch läuft */
    private fun rampStep(now: Long): Boolean {
        // Spielt der Player von selbst weiter (z. B. nach Anruf/Audiofokus), darf er nicht stumm bleiben
        val pl = main
        if (pl != null && pl.isPlaying && userTarget == 0f && !pendingPause && !ducked) userTarget = 1f
        if (userGain == userTarget) return false
        val dt = (now - rampLast).coerceAtLeast(0L)
        rampLast = now
        val down = userTarget < userGain
        val step = dt / (if (down) 150f else 250f)
        userGain = if (down) max(userTarget, userGain - step) else min(userTarget, userGain + step)
        applyVolume()
        if (pendingPause && userGain <= 0.001f) {
            pendingPause = false
            main?.pause()
        }
        return userGain != userTarget
    }

    private fun audioAttrs() = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .build()

    private fun fadeSeconds(): Int =
        getSharedPreferences("settings", Context.MODE_PRIVATE).getInt("crossfade", 1)

    private fun ensureTail(): ExoPlayer {
        tail?.let { return it }
        val t = ExoPlayer.Builder(this).setAudioAttributes(audioAttrs(), false).build()
        t.trackSelectionParameters = t.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()
        tail = t
        return t
    }

    private fun disarm() {
        armedId = null
        tailStarted = false
        tail?.let {
            it.playWhenReady = false
            it.stop()
            it.clearMediaItems()
        }
    }

    private fun abortFade() {
        fading = false
        fadeTargetId = null
        xGain = 1f
        applyVolume()
        disarm()
    }

    /** @return Wartezeit bis zum nächsten Takt in ms (läuft eine Rampe, immer ~16 ms, damit Fades exakt sind) */
    private var lastSave = 0L

    /** Verschiebt einen Titel innerhalb der Shuffle-Reihenfolge (landet an der Stelle des Zieltitels). */
    private fun moveInShuffle(id: String, toId: String) {
        val p = main ?: return
        val tl = p.currentTimeline
        if (tl.isEmpty) return
        val order = ArrayList<Int>()
        var i = tl.getFirstWindowIndex(true)
        while (i != C.INDEX_UNSET) {
            order.add(i)
            i = tl.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, true)
        }
        fun idxOf(mid: String): Int {
            for (k in 0 until p.mediaItemCount) if (p.getMediaItemAt(k).mediaId == mid) return k
            return -1
        }
        val from = idxOf(id)
        val to = idxOf(toId)
        if (from < 0 || to < 0) return
        val fp = order.indexOf(from)
        val tp = order.indexOf(to)
        if (fp < 0 || tp < 0 || fp == tp) return
        order.removeAt(fp)
        order.add(tp, from)
        p.setShuffleOrder(ShuffleOrder.DefaultShuffleOrder(order.toIntArray(), System.nanoTime()))
    }

    /**
     * Shuffle: der laufende Titel steht an erster Stelle, danach kommen ALLE anderen in zufälliger Reihenfolge.
     * (ExoPlayer würfelt sonst die Reihenfolge samt laufendem Titel – Titel davor würden nie gespielt.)
     */
    private fun shuffleFromCurrent() {
        val p = main ?: return
        val n = p.mediaItemCount
        if (n == 0) return
        val cur = p.currentMediaItemIndex.coerceIn(0, n - 1)
        val rest = (0 until n).filter { it != cur }.shuffled()
        p.setShuffleOrder(ShuffleOrder.DefaultShuffleOrder((listOf(cur) + rest).toIntArray(), System.nanoTime()))
    }

    companion object {
        const val CMD_SHUFFLE_FROM_CURRENT = "wavy.shuffle_current"
        const val CMD_MOVE_SHUFFLE = "wavy.move_shuffle"
        const val ROOT_ID = "wavy_root"
    }

    /** Merkt sich Warteschlange und Position, damit die Wiedergabe nach einem Neustart weitergehen kann. */
    private fun saveResume(withQueue: Boolean) {
        val p = main ?: return
        if (p.mediaItemCount == 0) return
        val e = getSharedPreferences("resume", Context.MODE_PRIVATE).edit()
        if (withQueue) {
            val sb = StringBuilder()
            for (i in 0 until p.mediaItemCount) {
                if (i > 0) sb.append(',')
                sb.append(p.getMediaItemAt(i).mediaId)
            }
            e.putString("ids", sb.toString())
        }
        e.putLong("cur", p.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L)
            .putLong("pos", p.currentPosition.coerceAtLeast(0L))
            .putBoolean("shuf", p.shuffleModeEnabled)
            .putInt("rep", p.repeatMode)
            .apply()
    }

    private fun step(): Long {
        val now = SystemClock.elapsedRealtime()
        if (now - lastSave > 10_000L && main?.isPlaying == true) {
            lastSave = now
            saveResume(false)
        }
        val ramping = rampStep(now)
        val d = stepCore(now)
        return if (ramping) minOf(d, 16L) else d
    }

    private fun stepCore(now: Long): Long {
        val next = 1500L
        val p = main ?: return next
        val t = tail

        // --- Überblendung läuft ---
        if (fading && t != null) {
            if (p.currentMediaItem?.mediaId != fadeTargetId) { // Nutzer hat in der Zwischenzeit gewechselt
                abortFade()
                return 16L
            }
            val ug = userGain * userGain
            if (fadeClock < 0L) {
                // Alter Song läuft voll weiter, bis der neue wirklich spielt
                if ((p.isPlaying && p.currentPosition > 40L) || now - fadeStart > 1000L) fadeClock = now
                xGain = 0f
                t.volume = ug
            } else {
                val f = ((now - fadeClock).toFloat() / fadeMs).coerceIn(0f, 1f)
                val ang = f * (Math.PI / 2).toFloat()
                xGain = sin(ang)
                t.volume = cos(ang) * ug
                if (f >= 1f || t.playbackState == Player.STATE_ENDED) {
                    fading = false
                    fadeTargetId = null
                    xGain = 1f
                    disarm()
                }
            }
            applyVolume()
            t.playWhenReady = p.playWhenReady
            return 16L
        }

        val sec = fadeSeconds()
        val cur = p.currentMediaItem
        val dur = p.duration
        val ok = sec > 0 && cur != null && p.hasNextMediaItem() && p.repeatMode != Player.REPEAT_MODE_ONE &&
            dur != C.TIME_UNSET && dur >= sec * 4000L + 5000L
        if (!ok) {
            if (armedId != null) disarm()
            return if (p.isPlaying) 1000L else next
        }
        val ms = sec * 1000L
        val trigger = dur - ms - 700L // 700 ms Vorlauf, bis der neue Song im Hauptplayer hörbar spielt
        val pos = p.currentPosition

        if (armedId != null && (armedId != cur!!.mediaId || pos < trigger - 7000L || pos > trigger + 600L)) disarm()
        if (armedId == null && p.isPlaying && pos >= trigger - 4000L && pos < trigger) {
            val tl = ensureTail()
            tl.volume = 1f
            tl.playWhenReady = false
            tl.setMediaItem(cur!!)
            tl.prepare()
            tl.seekTo(trigger)
            armedId = cur.mediaId
        }

        val a = tail
        // Der Nachspieler läuft schon (stumm), kurz bevor der Wechsel kommt, damit beim Tausch keine Lücke entsteht
        if (armedId != null && a != null && !tailStarted && p.isPlaying && pos >= trigger - 350L && pos < trigger &&
            a.playbackState == Player.STATE_READY
        ) {
            a.volume = 0f
            a.seekTo(pos + tailLat)
            a.playWhenReady = true
            tailStarted = true
        }
        if (tailStarted && !p.isPlaying) disarm()
        if (armedId != null && a != null && tailStarted && p.isPlaying && pos >= trigger && pos <= trigger + 600L &&
            a.isPlaying
        ) {
            val nextIdx = p.nextMediaItemIndex
            if (nextIdx != C.INDEX_UNSET) {
                // Versatz lernen: hinkt der Nachspieler hinterher, beim nächsten Mal früher starten
                val err = pos - a.currentPosition
                tailLat = (tailLat + err / 2).coerceIn(0L, 500L)
                fadeTargetId = p.getMediaItemAt(nextIdx).mediaId
                fadeMs = ms
                fadeStart = now
                fadeClock = -1L
                fading = true
                a.volume = userGain * userGain
                xGain = 0f
                applyVolume()
                p.seekToNextMediaItem()
                return 16L
            }
        }

        if (!p.isPlaying) return next
        if (armedId != null) return if (pos >= trigger - 500L) 16L else 30L
        val toWindow = trigger - 4000L - pos
        return if (toWindow <= 0L) 30L else (toWindow / 2).coerceIn(100L, 2000L)
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttrs(), true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        // MP4-Dateien: nur die Tonspur abspielen
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .build()
        main = player
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                applyEq()
            }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                updateReplayGain()
                applyVolume()
            }

            override fun onEvents(p: Player, events: Player.Events) {
                if (events.containsAny(Player.EVENT_MEDIA_METADATA_CHANGED, Player.EVENT_IS_PLAYING_CHANGED, Player.EVENT_MEDIA_ITEM_TRANSITION)) {
                    WidgetProvider.push(
                        applicationContext,
                        p.mediaMetadata.title?.toString().orEmpty(),
                        p.mediaMetadata.artist?.toString().orEmpty(),
                        p.playWhenReady,
                    )
                }
                if (events.containsAny(Player.EVENT_TIMELINE_CHANGED)) saveResume(true)
                else if (events.containsAny(
                        Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_IS_PLAYING_CHANGED,
                        Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED, Player.EVENT_REPEAT_MODE_CHANGED,
                        Player.EVENT_POSITION_DISCONTINUITY,
                    )
                ) saveResume(false)
            }
        })
        fxPrefs.registerOnSharedPreferenceChangeListener(fxListener)
        applyEq()
        kick()

        // Antippen der Benachrichtigung / Hyper Island öffnet die App
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val openApp = PendingIntent.getActivity(
            this, 0, launch ?: Intent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaLibrarySession.Builder(this, FadingPlayer(player), object : MediaLibrarySession.Callback {
                override fun onGetLibraryRoot(
                    session: MediaLibrarySession,
                    browser: MediaSession.ControllerInfo,
                    params: LibraryParams?,
                ): ListenableFuture<LibraryResult<MediaItem>> {
                    loadSongsAsync()
                    val root = MediaItem.Builder()
                        .setMediaId(ROOT_ID)
                        .setMediaMetadata(
                            MediaMetadata.Builder().setTitle("Wavy").setIsBrowsable(true).setIsPlayable(false)
                                .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED).build(),
                        )
                        .build()
                    return Futures.immediateFuture(LibraryResult.ofItem(root, params))
                }

                override fun onGetChildren(
                    session: MediaLibrarySession,
                    browser: MediaSession.ControllerInfo,
                    parentId: String,
                    page: Int,
                    pageSize: Int,
                    params: LibraryParams?,
                ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
                    if (songsCache.isEmpty()) loadSongsAsync()
                    val all = if (parentId == ROOT_ID) songsCache else emptyList()
                    val part = all.drop(page * pageSize).take(pageSize).map { songItem(it) }
                    return Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(part), params))
                }

                override fun onGetItem(
                    session: MediaLibrarySession,
                    browser: MediaSession.ControllerInfo,
                    mediaId: String,
                ): ListenableFuture<LibraryResult<MediaItem>> {
                    val sg = songsCache.firstOrNull { it.id.toString() == mediaId }
                        ?: return Futures.immediateFuture(LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE))
                    return Futures.immediateFuture(LibraryResult.ofItem(songItem(sg), null))
                }

                override fun onSetMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>,
                    startIndex: Int,
                    startPositionMs: Long,
                ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
                    // Ein einzelner Song aus der Liste (z. B. im Auto): die ganze Liste ab diesem Song abspielen
                    val first = mediaItems.singleOrNull()
                    val cache = songsCache
                    if (first != null && first.localConfiguration == null && cache.size > 1) {
                        val idx = cache.indexOfFirst { it.id.toString() == first.mediaId }
                        if (idx >= 0) {
                            return Futures.immediateFuture(
                                MediaSession.MediaItemsWithStartPosition(cache.map { songItem(it) }, idx, 0L),
                            )
                        }
                    }
                    return super.onSetMediaItems(mediaSession, controller, mediaItems, startIndex, startPositionMs)
                }

                override fun onConnect(
                    session: MediaSession,
                    controller: MediaSession.ControllerInfo,
                ): MediaSession.ConnectionResult {
                    val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                        .add(SessionCommand(CMD_MOVE_SHUFFLE, Bundle.EMPTY))
                        .add(SessionCommand(CMD_SHUFFLE_FROM_CURRENT, Bundle.EMPTY))
                        .build()
                    return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                        .setAvailableSessionCommands(cmds)
                        .build()
                }

                override fun onCustomCommand(
                    session: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    customCommand: SessionCommand,
                    args: Bundle,
                ): ListenableFuture<SessionResult> {
                    if (customCommand.customAction == CMD_SHUFFLE_FROM_CURRENT) {
                        shuffleFromCurrent()
                    }
                    if (customCommand.customAction == CMD_MOVE_SHUFFLE) {
                        moveInShuffle(args.getString("id").orEmpty(), args.getString("to").orEmpty())
                    }
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }

                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>,
                ): ListenableFuture<MutableList<MediaItem>> {
                    val resolved = mediaItems.map {
                        val known = songsCache.firstOrNull { sg -> sg.id.toString() == it.mediaId }
                        if (known != null && it.localConfiguration == null && it.requestMetadata.mediaUri == null) {
                            songItem(known)
                        } else {
                            it.buildUpon()
                                .setUri(it.requestMetadata.mediaUri ?: it.localConfiguration?.uri)
                                .build()
                        }
                    }.toMutableList()
                    return Futures.immediateFuture(resolved)
                }
            })
            .setSessionActivity(openApp)
            .setBitmapLoader(SquareBitmapLoader(this))
            .build()
        loadSongsAsync()
    }

    private fun loadSongsAsync() {
        if (loadingSongs) return
        loadingSongs = true
        Thread {
            try {
                if (MediaRepository.hasPermission(applicationContext)) {
                    songsCache = MediaRepository.loadSongs(applicationContext).take(1000)
                }
            } catch (_: Exception) {
            } finally {
                loadingSongs = false
            }
        }.start()
    }

    private fun songItem(sg: Song): MediaItem = MediaItem.Builder()
        .setMediaId(sg.id.toString())
        .setUri(sg.uri)
        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(sg.uri).build())
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(sg.title)
                .setArtist(sg.artistLabel)
                .setAlbumTitle(sg.album.ifBlank { null })
                .setDurationMs(sg.durationMs)
                .setArtworkUri(SquareBitmapLoader.artworkUri(sg))
                .setIsPlayable(true)
                .setIsBrowsable(false)
                .build(),
        )
        .build()

    /** Knöpfe des Homescreen-Widgets. */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = main
        if (p != null) {
            when (intent?.action) {
                WidgetProvider.ACTION_TOGGLE -> if (p.playWhenReady) requestPause() else requestPlay()
                WidgetProvider.ACTION_NEXT -> p.seekToNextMediaItem()
                WidgetProvider.ACTION_PREV -> p.seekToPreviousMediaItem()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    /** App aus der Übersicht gewischt: Wiedergabe beenden. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        saveResume(true)
        if (!getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("stop_on_close", true)) return
        abortFade()
        main?.run {
            pause()
            stop()
            clearMediaItems()
        }
        stopSelf()
    }

    override fun onDestroy() {
        try { fxPrefs.unregisterOnSharedPreferenceChangeListener(fxListener) } catch (_: Exception) {}
        eq?.release()
        eq = null
        handler.removeCallbacksAndMessages(null)
        tail?.release()
        tail = null
        session?.run {
            player.release()
            release()
        }
        session = null
        main = null
        super.onDestroy()
    }
}
