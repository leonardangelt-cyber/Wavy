package app.wavy.player.playback

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.cos
import kotlin.math.sin

/**
 * Spielt Musik im Hintergrund. Überblenden: Ein zweiter Player ("Ausläufer") wird kurz vor dem Ende
 * schon bereitgemacht (gepuffert, an der richtigen Stelle, pausiert). Zum Übergang startet er sofort
 * ohne Verzögerung, während der Hauptplayer den nächsten Song einblendet. Beide laufen mit
 * Equal-Power-Kurve, sodass die Lautstärke gleich bleibt.
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var main: ExoPlayer? = null

    private val handler = Handler(Looper.getMainLooper())
    private var tail: ExoPlayer? = null
    private var armedId: String? = null
    private var armedPos = 0L
    private var fading = false
    private var fadeStart = 0L
    private var fadeMs = 0L
    private var fadeTargetId: String? = null

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (_: Exception) {
                abortFade()
            }
            handler.postDelayed(this, 30)
        }
    }

    private fun audioAttrs() = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .build()

    private fun fadeSeconds(): Int =
        getSharedPreferences("settings", Context.MODE_PRIVATE).getInt("crossfade", 1)

    private fun ensureTail(): ExoPlayer {
        tail?.let { return it }
        val t = ExoPlayer.Builder(this).setAudioAttributes(audioAttrs(), false).build()
        t.trackSelectionParameters = t.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()
        tail = t
        return t
    }

    private fun disarm() {
        armedId = null
        tail?.let {
            it.playWhenReady = false
            it.stop()
            it.clearMediaItems()
        }
    }

    private fun abortFade() {
        fading = false
        fadeTargetId = null
        disarm()
        main?.volume = 1f
    }

    private fun step() {
        val p = main ?: return
        val t = tail

        // --- Überblendung läuft ---
        if (fading && t != null) {
            if (p.currentMediaItem?.mediaId != fadeTargetId) { // Nutzer hat in der Zwischenzeit gewechselt
                abortFade()
                return
            }
            val f = ((SystemClock.elapsedRealtime() - fadeStart).toFloat() / fadeMs).coerceIn(0f, 1f)
            val ang = f * (Math.PI / 2).toFloat()
            p.volume = sin(ang)
            t.volume = cos(ang)
            t.playWhenReady = p.playWhenReady
            if (f >= 1f || t.playbackState == Player.STATE_ENDED) {
                fading = false
                fadeTargetId = null
                p.volume = 1f
                disarm()
            }
            return
        }

        val sec = fadeSeconds()
        val cur = p.currentMediaItem
        val dur = p.duration
        val ok = sec > 0 && cur != null && p.hasNextMediaItem() && p.repeatMode != Player.REPEAT_MODE_ONE &&
            dur != C.TIME_UNSET && dur >= sec * 1000L * 4 + 4000L
        if (!ok) {
            if (armedId != null) disarm()
            return
        }
        val ms = sec * 1000L
        val trigger = dur - ms
        val pos = p.currentPosition

        // Ausläufer rechtzeitig vorbereiten (gepuffert, pausiert, genau am Startpunkt)
        if (armedId != null && (armedId != cur!!.mediaId || pos < trigger - 7000L || pos > trigger + 600L)) disarm()
        if (armedId == null && p.isPlaying && pos >= trigger - 4000L && pos < trigger) {
            val tl = ensureTail()
            tl.volume = 1f
            tl.playWhenReady = false
            tl.setMediaItem(cur!!)
            tl.prepare()
            tl.seekTo(trigger)
            armedId = cur.mediaId
            armedPos = trigger
        }

        // Übergang: Ausläufer startet sofort, neuer Song setzt im Hauptplayer ein
        val a = tail
        if (armedId != null && a != null && p.isPlaying && pos >= trigger && pos <= trigger + 600L &&
            a.playbackState == Player.STATE_READY
        ) {
            val nextIdx = p.nextMediaItemIndex
            if (nextIdx == C.INDEX_UNSET) return
            fadeTargetId = p.getMediaItemAt(nextIdx).mediaId
            fadeMs = ms
            fadeStart = SystemClock.elapsedRealtime()
            fading = true
            a.volume = 1f
            a.playWhenReady = true
            p.volume = 0f
            p.seekToNextMediaItem()
        }
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttrs(), true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        // MP4-Dateien: nur die Tonspur abspielen
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .build()
        main = player
        handler.post(tick)

        session = MediaSession.Builder(this, player)
            .setCallback(object : MediaSession.Callback {
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>,
                ): ListenableFuture<MutableList<MediaItem>> {
                    val resolved = mediaItems.map {
                        it.buildUpon()
                            .setUri(it.requestMetadata.mediaUri ?: it.localConfiguration?.uri)
                            .build()
                    }.toMutableList()
                    return Futures.immediateFuture(resolved)
                }
            })
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** App aus der Übersicht gewischt: Wiedergabe beenden. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        abortFade()
        session?.player?.run {
            pause()
            stop()
            clearMediaItems()
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        tail?.release()
        tail = null
        session?.run {
            player.release()
            release()
        }
        session = null
        main = null
        super.onDestroy()
    }
}
