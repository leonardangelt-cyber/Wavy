package app.wavy.player.playback

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/** Spielt Musik im Hintergrund, mit Benachrichtigung, Sperrbildschirm-Steuerung und Überblenden. */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var main: ExoPlayer? = null

    // Überblenden: Der Rest des alten Songs läuft in einem zweiten Player aus, während der neue im Hauptplayer einblendet.
    private val handler = Handler(Looper.getMainLooper())
    private var tail: ExoPlayer? = null
    private var fadeStart = 0L
    private var fadeMs = 0L
    private var fadeTargetId: String? = null

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (_: Exception) {
                stopFade()
            }
            handler.postDelayed(this, 80)
        }
    }

    private fun audioAttrs() = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .build()

    private fun fadeSeconds(): Int =
        getSharedPreferences("settings", Context.MODE_PRIVATE).getInt("crossfade", 5)

    private fun step() {
        val p = main ?: return
        val t = tail
        if (t != null) {
            // Läuft gerade eine Überblendung
            val cur = p.currentMediaItem?.mediaId
            if (cur != fadeTargetId) { // Nutzer hat in der Zwischenzeit geskippt
                stopFade()
                return
            }
            val f = ((SystemClock.elapsedRealtime() - fadeStart).toFloat() / fadeMs).coerceIn(0f, 1f)
            // Gleichbleibende Lautstärke (Equal-Power): beide Songs überlappen, ohne dass es leiser wird
            val ang = f * (Math.PI / 2).toFloat()
            p.volume = kotlin.math.sin(ang)
            t.volume = kotlin.math.cos(ang)
            if (p.playWhenReady) t.play() else t.pause()
            if (f >= 1f || t.playbackState == Player.STATE_ENDED) stopFade()
            return
        }
        val sec = fadeSeconds()
        if (sec <= 0 || !p.isPlaying || !p.hasNextMediaItem()) return
        if (p.repeatMode == Player.REPEAT_MODE_ONE) return
        val dur = p.duration
        if (dur == C.TIME_UNSET || dur < sec * 3000L) return
        val remaining = dur - p.currentPosition
        if (remaining in 1..(sec * 1000L)) startFade(p, minOf(remaining, sec * 1000L))
    }

    private fun startFade(p: ExoPlayer, ms: Long) {
        val item = p.currentMediaItem ?: return
        val nextIdx = p.nextMediaItemIndex
        if (nextIdx == C.INDEX_UNSET) return
        val nextId = p.getMediaItemAt(nextIdx).mediaId
        val t = ExoPlayer.Builder(this).setAudioAttributes(audioAttrs(), false).build()
        t.trackSelectionParameters = t.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()
        t.setMediaItem(item)
        t.prepare()
        t.seekTo(p.currentPosition)
        t.volume = 1f
        t.play()
        tail = t
        fadeMs = ms.coerceAtLeast(800L)
        fadeStart = SystemClock.elapsedRealtime()
        fadeTargetId = nextId
        p.volume = 0f
        p.seekToNextMediaItem()
    }

    private fun stopFade() {
        tail?.release()
        tail = null
        fadeTargetId = null
        main?.volume = 1f
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttrs(), true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        // MP4-Dateien: nur die Tonspur abspielen
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .build()
        main = player
        handler.post(tick)

        session = MediaSession.Builder(this, player)
            .setCallback(object : MediaSession.Callback {
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>,
                ): ListenableFuture<MutableList<MediaItem>> {
                    val resolved = mediaItems.map {
                        it.buildUpon()
                            .setUri(it.requestMetadata.mediaUri ?: it.localConfiguration?.uri)
                            .build()
                    }.toMutableList()
                    return Futures.immediateFuture(resolved)
                }
            })
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** App aus der Übersicht gewischt: Wiedergabe beenden. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopFade()
        session?.player?.run {
            pause()
            stop()
            clearMediaItems()
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        stopFade()
        session?.run {
            player.release()
            release()
        }
        session = null
        main = null
        super.onDestroy()
    }
}
