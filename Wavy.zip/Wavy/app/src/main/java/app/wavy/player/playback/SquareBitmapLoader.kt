package app.wavy.player.playback

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import app.wavy.player.data.CoverLoader
import app.wavy.player.data.Song
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import kotlinx.coroutines.runBlocking
import java.util.concurrent.Executors

/**
 * Liefert dem System (Benachrichtigung, Hyper Island, Sperrbildschirm) das Cover als mittig zugeschnittenes Quadrat,
 * damit links und rechts keine Balken erscheinen.
 */
@UnstableApi
class SquareBitmapLoader(private val ctx: Context) : BitmapLoader {
    private val pool = Executors.newSingleThreadExecutor()

    override fun supportsMimeType(mimeType: String): Boolean = mimeType.startsWith("image/")

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> {
        val f = SettableFuture.create<Bitmap>()
        pool.execute {
            val b = BitmapFactory.decodeByteArray(data, 0, data.size)
            if (b != null) f.set(square(b)) else f.setException(IllegalStateException("Bild nicht lesbar"))
        }
        return f
    }

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> {
        val f = SettableFuture.create<Bitmap>()
        pool.execute {
            try {
                val id = uri.lastPathSegment?.toLongOrNull() ?: 0L
                val src = uri.getQueryParameter("u")?.let { Uri.parse(it) }
                if (src == null) {
                    f.setException(IllegalStateException("Kein Cover"))
                    return@execute
                }
                val stub = Song(id, src, "", "", "", 0L, "", uri.getQueryParameter("v") == "1")
                val b = runBlocking { CoverLoader.load(ctx, stub, 512) }
                if (b != null) f.set(square(b)) else f.setException(IllegalStateException("Kein Cover"))
            } catch (e: Exception) {
                f.setException(e)
            }
        }
        return f
    }

    private fun square(b: Bitmap): Bitmap {
        val s = minOf(b.width, b.height)
        if (b.width == b.height) return b
        return Bitmap.createBitmap(b, (b.width - s) / 2, (b.height - s) / 2, s, s)
    }

    companion object {
        fun artworkUri(song: Song): Uri =
            Uri.parse("wavycover://c/${song.id}?u=${Uri.encode(song.uri.toString())}&v=${if (song.isVideo) 1 else 0}")
    }
}
