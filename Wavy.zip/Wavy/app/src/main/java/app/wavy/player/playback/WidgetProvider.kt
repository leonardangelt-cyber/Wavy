package app.wavy.player.playback

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import app.wavy.player.MainActivity
import app.wavy.player.R

/** Kleines Homescreen-Widget: Titel, Künstler und drei Tasten. */
class WidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        render(context, manager, ids)
    }

    companion object {
        const val ACTION_TOGGLE = "wavy.widget.toggle"
        const val ACTION_NEXT = "wavy.widget.next"
        const val ACTION_PREV = "wavy.widget.prev"

        fun push(ctx: Context, title: String, artist: String, playing: Boolean) {
            ctx.getSharedPreferences("widget", Context.MODE_PRIVATE).edit()
                .putString("title", title).putString("artist", artist).putBoolean("playing", playing).apply()
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, WidgetProvider::class.java))
            if (ids.isNotEmpty()) render(ctx, m, ids)
        }

        private fun service(ctx: Context, action: String, code: Int): PendingIntent {
            val i = Intent(ctx, PlaybackService::class.java).setAction(action)
            return PendingIntent.getForegroundService(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun render(ctx: Context, m: AppWidgetManager, ids: IntArray) {
            val sp = ctx.getSharedPreferences("widget", Context.MODE_PRIVATE)
            val title = sp.getString("title", "").orEmpty().ifBlank { "Wavy" }
            val artist = sp.getString("artist", "").orEmpty()
            val playing = sp.getBoolean("playing", false)
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            v.setTextViewText(R.id.w_title, title)
            v.setTextViewText(R.id.w_artist, artist.ifBlank { "Tippen zum Öffnen" })
            v.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
            v.setOnClickPendingIntent(R.id.w_play, service(ctx, ACTION_TOGGLE, 1))
            v.setOnClickPendingIntent(R.id.w_next, service(ctx, ACTION_NEXT, 2))
            v.setOnClickPendingIntent(R.id.w_prev, service(ctx, ACTION_PREV, 3))
            val open = PendingIntent.getActivity(
                ctx, 4, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            v.setOnClickPendingIntent(R.id.w_root, open)
            m.updateAppWidget(ids, v)
        }
    }
}
