package app.wavy.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.wavy.player.data.AlbumTrack
import app.wavy.player.data.Song
import app.wavy.player.data.normTitle
import java.net.URLEncoder

private sealed interface AlbumRow {
    data class Have(val song: Song, val number: Int) : AlbumRow
    data class Missing(val track: AlbumTrack) : AlbumRow
}

private fun ytSearch(q: String) = "https://music.youtube.com/search?q=" + URLEncoder.encode(q, "UTF-8")

private fun matches(song: Song, track: AlbumTrack): Boolean {
    val a = normTitle(song.title)
    val b = normTitle(track.title)
    if (a.isBlank() || b.isBlank()) return false
    return a == b || (minOf(a.length, b.length) >= 4 && (a.contains(b) || b.contains(a)))
}

/** Album mit allen Titeln: deine Songs spielbar, der Rest mit Link zu YouTube Music. */
@Composable
fun AlbumDetail(
    group: Group,
    bottomPad: Dp,
    currentId: Long?,
    onBack: () -> Unit,
    onPlay: (List<Song>, Boolean) -> Unit,
    onSongClick: (List<Song>, Song) -> Unit,
    onMore: (Song) -> Unit,
    loadAlbum: suspend (String, String) -> List<AlbumTrack>?,
    onOpenLink: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val albumName = group.title
    val artist = remember(group) {
        group.songs.groupingBy { it.artistLabel }.eachCount().maxByOrNull { it.value }?.key ?: ""
    }
    var tracks by remember(group.key) { mutableStateOf<List<AlbumTrack>?>(null) }
    var loading by remember(group.key) { mutableStateOf(true) }
    LaunchedEffect(group.key) {
        loading = true
        tracks = loadAlbum(artist, albumName)
        loading = false
    }

    val rows: List<AlbumRow> = remember(tracks, group) {
        val t = tracks
        if (t.isNullOrEmpty()) {
            group.songs.mapIndexed { i, s -> AlbumRow.Have(s, i + 1) }
        } else {
            val used = HashSet<Long>()
            val out = ArrayList<AlbumRow>()
            t.forEachIndexed { i, tr ->
                val s = group.songs.firstOrNull { it.id !in used && matches(it, tr) }
                if (s != null) {
                    used += s.id
                    out += AlbumRow.Have(s, i + 1)
                } else {
                    out += AlbumRow.Missing(tr)
                }
            }
            // Songs, die nicht in der Titelliste vorkommen, bleiben trotzdem sichtbar
            group.songs.filter { it.id !in used }.forEach { out += AlbumRow.Have(it, out.size + 1) }
            out
        }
    }
    val owned = remember(rows) { rows.filterIsInstance<AlbumRow.Have>().map { it.song } }
    val total = rows.size
    val missing = rows.count { it is AlbumRow.Missing }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 24.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item {
            Column(Modifier.statusBarsPadding().padding(top = 8.dp, bottom = 12.dp)) {
                BackButton(onBack, Modifier.padding(start = 4.dp))
                Row(Modifier.padding(start = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Cover(group.songs.first(), 400, Modifier.size(124.dp), RoundedCornerShape(28.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            albumName,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            artist,
                            style = MaterialTheme.typography.titleMedium,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            when {
                                loading -> "${owned.size} Songs auf deinem Handy"
                                missing > 0 -> "${owned.size} von $total Songs auf deinem Handy"
                                else -> "${owned.size} Songs"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(onClick = { onPlay(owned, false) }, modifier = Modifier.weight(1f).height(52.dp), shape = PlayShape) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(22.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Abspielen")
                }
                FilledTonalButton(onClick = { onPlay(owned, true) }, modifier = Modifier.weight(1f).height(52.dp), shape = ShuffleShape) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(22.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Shuffle")
                }
            }
        }
        item {
            FilledTonalButton(
                onClick = { onOpenLink(ytSearch("$artist $albumName")) },
                modifier = Modifier.fillMaxWidth().height(52.dp).padding(bottom = 0.dp),
                shape = CircleShape,
            ) {
                Icon(Icons.AutoMirrored.Rounded.OpenInNew, null, Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Ganzes Album auf YouTube Music")
            }
            Spacer(Modifier.height(10.dp))
            if (loading) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Lade Titelliste …", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            } else if (tracks == null) {
                Text(
                    "Titelliste nicht erreichbar (kein Internet?). Es werden nur deine Songs gezeigt.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
                )
            } else if (tracks!!.isEmpty()) {
                Text(
                    "Zu diesem Album wurde keine Titelliste gefunden.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
                )
            }
        }
        itemsIndexed(rows, key = { i, r ->
            when (r) {
                is AlbumRow.Have -> "h${r.song.id}"
                is AlbumRow.Missing -> "m$i"
            }
        }) { i, r ->
            when (r) {
                is AlbumRow.Have -> SongRow(
                    song = r.song,
                    index = i,
                    count = rows.size,
                    isCurrent = r.song.id == currentId,
                    onClick = { onSongClick(owned, r.song) },
                    onMore = { onMore(r.song) },
                )
                is AlbumRow.Missing -> MissingRow(
                    track = r.track,
                    subtitle = "Nicht auf deinem Handy · YouTube Music",
                    index = i,
                    count = rows.size,
                    onClick = { onOpenLink(ytSearch("$artist ${r.track.title}")) },
                )
            }
        }
    }
}

@Composable
private fun MissingRow(track: AlbumTrack, subtitle: String, index: Int, count: Int, onClick: () -> Unit, owned: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = segShape(index, count),
        color = cs.surfaceContainer,
        contentColor = cs.onSurface,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(start = 12.dp, end = 6.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = cs.surfaceContainerHighest,
                modifier = Modifier.size(54.dp),
            ) {
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${track.number}", style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    track.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = cs.onSurface.copy(alpha = if (owned) 1f else 0.75f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (track.durationMs > 0) {
                Text(formatTime(track.durationMs), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            }
            Icon(
                if (owned) Icons.Rounded.PlayArrow else Icons.AutoMirrored.Rounded.OpenInNew,
                if (owned) "Abspielen" else "In YouTube Music öffnen",
                tint = cs.primary,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
        }
    }
}

/** Künstler: deine Songs, darunter die fünf bekanntesten mit Link zu YouTube Music. */
@Composable
fun ArtistDetail(
    group: Group,
    bottomPad: Dp,
    currentId: Long?,
    onBack: () -> Unit,
    onPlay: (List<Song>, Boolean) -> Unit,
    onSongClick: (List<Song>, Song) -> Unit,
    onMore: (Song) -> Unit,
    loadTop: suspend (String) -> List<AlbumTrack>?,
    loadInfo: suspend (String) -> app.wavy.player.data.ArtistInfo? = { null },
    onOpenLink: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val artist = group.title
    var info by remember(group.key) { mutableStateOf<app.wavy.player.data.ArtistInfo?>(null) }
    LaunchedEffect(group.key) { if (artist != "Unbekannter Interpret") info = loadInfo(artist) }
    var top by remember(group.key) { mutableStateOf<List<AlbumTrack>?>(null) }
    var loading by remember(group.key) { mutableStateOf(true) }
    LaunchedEffect(group.key) {
        loading = true
        top = loadTop(artist)
        loading = false
    }
    val songs = group.songs

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 24.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item {
            Column(Modifier.statusBarsPadding().padding(top = 8.dp, bottom = 12.dp)) {
                BackButton(onBack, Modifier.padding(start = 4.dp))
                Row(Modifier.padding(start = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Cover(songs.first(), 400, Modifier.size(104.dp), CircleShape)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            artist,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            "${songs.size} " + if (songs.size == 1) "Song auf deinem Handy" else "Songs auf deinem Handy",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(onClick = { onPlay(songs, false) }, modifier = Modifier.weight(1f).height(52.dp), shape = PlayShape) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(22.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Abspielen")
                }
                FilledTonalButton(onClick = { onPlay(songs, true) }, modifier = Modifier.weight(1f).height(52.dp), shape = ShuffleShape) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(22.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Shuffle")
                }
            }
            if (artist != "Unbekannter Interpret") {
                FilledTonalButton(
                    onClick = { onOpenLink(ytSearch(artist)) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = CircleShape,
                ) {
                    Icon(Icons.AutoMirrored.Rounded.OpenInNew, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Künstler auf YouTube Music")
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Deine Songs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
        }
        itemsIndexed(songs, key = { _, s -> "s${s.id}" }) { i, s ->
            SongRow(
                song = s,
                index = i,
                count = songs.size,
                isCurrent = s.id == currentId,
                onClick = { onSongClick(songs, s) },
                onMore = { onMore(s) },
            )
        }
        val list = top
        if (artist != "Unbekannter Interpret") {
            item {
                Spacer(Modifier.height(14.dp))
                Text("Bekannteste Songs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
                if (loading) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Lade …", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                } else if (list == null) {
                    Text("Nicht erreichbar (kein Internet?).", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                } else if (list.isEmpty()) {
                    Text("Keine Songs gefunden.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                }
            }
            if (list != null) {
                itemsIndexed(list, key = { i, t -> "t$i" }) { i, t ->
                    val mine = songs.firstOrNull { matches(it, t) }
                    MissingRow(
                        track = t,
                        subtitle = if (mine != null) "Auf deinem Handy" else "Auf YouTube Music anhören",
                        index = i,
                        count = list.size,
                        owned = mine != null,
                        onClick = { if (mine != null) onSongClick(songs, mine) else onOpenLink(ytSearch("$artist ${t.title}")) },
                    )
                }
            }
        }
        val inf = info
        if (inf != null && inf.albums.isNotEmpty()) {
            item {
                Spacer(Modifier.height(18.dp))
                Text("Diskografie", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(inf.albums.size) { i ->
                        val a = inf.albums[i]
                        Column(Modifier.width(132.dp).clickable { onOpenLink(ytSearch("$artist ${a.title}")) }) {
                            RemoteCover(a.cover, Modifier.size(132.dp), RoundedCornerShape(24.dp))
                            Text(a.title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                            if (a.year.isNotBlank()) Text(a.year, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        if (inf != null && inf.related.isNotEmpty()) {
            item {
                Spacer(Modifier.height(18.dp))
                Text("Ähnliche Künstler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(inf.related.size) { i ->
                        val r = inf.related[i]
                        Column(Modifier.width(96.dp).clickable { onOpenLink(ytSearch(r.name)) }, horizontalAlignment = Alignment.CenterHorizontally) {
                            RemoteCover(r.picture, Modifier.size(96.dp), CircleShape)
                            Text(r.name, style = MaterialTheme.typography.labelMedium, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

/** Bild aus dem Netz mit weichem Platzhalter. */
@Composable
fun RemoteCover(url: String, modifier: Modifier, shape: androidx.compose.ui.graphics.Shape) {
    var bmp by remember(url) { mutableStateOf(app.wavy.player.data.RemoteImages.cached(url)) }
    LaunchedEffect(url) { if (bmp == null && url.isNotBlank()) bmp = app.wavy.player.data.RemoteImages.load(url) }
    Box(modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceContainerHighest)) {
        val b = bmp
        if (b != null) {
            androidx.compose.foundation.Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}
