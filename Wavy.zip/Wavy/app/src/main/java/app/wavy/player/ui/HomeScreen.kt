package app.wavy.player.ui

import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

data class Group(val key: String, val title: String, val subtitle: String, val songs: List<Song>)

private fun songsLabel(n: Int) = "$n " + if (n == 1) "Song" else "Songs"

private fun artistGroups(songs: List<Song>, prefix: String): List<Group> =
    songs.groupBy { it.artistLabel }
        .map { (name, l) -> Group("$prefix$name", name, songsLabel(l.size), l) }
        .sortedBy { it.title.lowercase() }

private fun albumGroups(songs: List<Song>): List<Group> =
    songs.filter { it.album.isNotBlank() }
        .groupBy { it.album }
        .map { (name, l) ->
            val artists = l.map { it.artistLabel }.distinct()
            val who = if (artists.size == 1) artists[0] else "Verschiedene Interpreten"
            Group("album:$name", name, "$who · ${songsLabel(l.size)}", l)
        }
        .sortedBy { it.title.lowercase() }

private val VIEW_LABELS = listOf("Songs", "Künstler", "Heruntergeladen", "Alben")

@Composable
fun HomeScreen(
    songs: List<Song>,
    loaded: Boolean,
    granted: Boolean,
    excluded: Set<Long>,
    currentId: Long?,
    bottomPad: Dp,
    view: Int,
    onView: (Int) -> Unit,
    groupKey: String?,
    onGroup: (String?) -> Unit,
    onRequestPermission: () -> Unit,
    onPlayAll: (List<Song>) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onSongClick: (List<Song>, Song) -> Unit,
    onMore: (Song) -> Unit,
    onPlayGroup: (List<Song>, Boolean) -> Unit,
    onGroupSongClick: (List<Song>, Song) -> Unit,
    loadAlbum: suspend (String, String) -> List<app.wavy.player.data.AlbumTrack>?,
    loadTop: suspend (String) -> List<app.wavy.player.data.AlbumTrack>?,
    onOpenLink: (String) -> Unit,
) {
    val groups = remember(songs, view) {
        when (view) {
            1 -> artistGroups(songs, "artist:")
            2 -> artistGroups(songs.filter { it.isDownload }, "dl:")
            3 -> albumGroups(songs)
            else -> emptyList()
        }
    }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val shown = remember(songs, query) {
        val q = query.trim()
        if (q.isEmpty()) songs else songs.filter {
            it.title.contains(q, true) || it.artistLabel.contains(q, true) || it.album.contains(q, true)
        }
    }
    val listState = rememberLazyListState()
    val group = groupKey?.let { k -> groups.firstOrNull { it.key == k } }

    Box(Modifier.fillMaxSize()) {
        when {
            !granted -> EmptyState(
                title = "Zugriff auf deine Musik",
                text = "Erlaube den Zugriff auf Audio- und MP4-Dateien, damit Wavy deine Songs anzeigen kann.",
                modifier = Modifier.statusBarsPadding(),
                buttonText = "Zugriff erlauben",
                onButton = onRequestPermission,
            )
            loaded && songs.isEmpty() -> EmptyState(
                title = "Keine Songs gefunden",
                text = "Lade Musik auf dein Handy (z. B. in den Ordner Download oder Music), dann erscheint sie hier.",
                modifier = Modifier.statusBarsPadding(),
            )
            group != null && view == 3 -> AlbumDetail(
                group = group,
                bottomPad = bottomPad,
                currentId = currentId,
                onBack = { onGroup(null) },
                onPlay = { list, shuffle -> onPlayGroup(list, shuffle) },
                onSongClick = { list, s -> onGroupSongClick(list, s) },
                onMore = onMore,
                loadAlbum = loadAlbum,
                onOpenLink = onOpenLink,
            )
            group != null && view == 1 -> ArtistDetail(
                group = group,
                bottomPad = bottomPad,
                currentId = currentId,
                onBack = { onGroup(null) },
                onPlay = { list, shuffle -> onPlayGroup(list, shuffle) },
                onSongClick = { list, s -> onGroupSongClick(list, s) },
                onMore = onMore,
                loadTop = loadTop,
                onOpenLink = onOpenLink,
            )
            group != null -> GroupDetail(
                group = group,
                bottomPad = bottomPad,
                round = view != 3,
                currentId = currentId,
                onBack = { onGroup(null) },
                onPlay = { shuffle -> onPlayGroup(group.songs, shuffle) },
                onSongClick = { s -> onGroupSongClick(group.songs, s) },
                onMore = onMore,
            )
            else -> Column(Modifier.fillMaxSize()) {
                TopChips(
                    view = view,
                    onView = onView,
                    showPlay = view == 0,
                    onPlayAll = { onPlayAll(shown) },
                    onShuffle = { onShuffle(shown) },
                    searching = searching,
                    query = query,
                    onQuery = { query = it },
                    onToggleSearch = { searching = !searching; if (!searching) query = "" },
                    showSearch = view == 0,
                )
                if (!searching) {
                    ViewChips(view = view, onView = onView)
                }
                if (view == 0) {
                  Box(Modifier.fillMaxSize()) {
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 24.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        itemsIndexed(shown, key = { _, s -> s.id }) { i, s ->
                            SongRow(
                                song = s,
                                index = i,
                                count = shown.size,
                                isCurrent = s.id == currentId,
                                note = if (s.id in excluded) "nicht in Auto-Wiedergabe" else null,
                                onClick = { onSongClick(shown, s) },
                                onMore = { onMore(s) },
                            )
                        }
                    }
                    FastScroller(
                        state = listState,
                        modifier = Modifier.align(Alignment.CenterEnd).padding(bottom = bottomPad),
                    ) { i -> shown.getOrNull(i)?.title?.trim()?.firstOrNull()?.uppercaseChar()?.let { c -> if (c.isLetter()) c.toString() else "#" } ?: "#" }
                  }
                } else if (groups.isEmpty()) {
                    Text(
                        when (view) {
                            2 -> "Keine heruntergeladenen Songs im Ordner Download gefunden."
                            3 -> "Keine Alben gefunden. Deine Songs haben keine Album-Angabe."
                            else -> "Keine Künstler gefunden."
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp),
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 24.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        itemsIndexed(groups, key = { _, g -> g.key }) { i, g ->
                            GroupRow(g, i, groups.size, round = view != 3) { onGroup(g.key) }
                        }
                    }
                }
            }
        }
    }
}

/** Kopfzeile: nur "Home" plus Shuffle und Alles abspielen. */
@Composable
private fun TopChips(
    view: Int,
    onView: (Int) -> Unit,
    showPlay: Boolean,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    searching: Boolean,
    query: String,
    onQuery: (String) -> Unit,
    onToggleSearch: () -> Unit,
    showSearch: Boolean,
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(searching) { if (searching) focus.requestFocus() }
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (searching) {
            OutlinedTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                placeholder = { Text("Songs, Künstler, Alben") },
                shape = CircleShape,
                modifier = Modifier.weight(1f).focusRequester(focus),
            )
            IconButton(onClick = onToggleSearch) { Icon(Icons.Rounded.Close, "Suche schließen") }
            return@Row
        }
        Text(
            "Home",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.weight(1f),
        )
        if (showSearch) IconButton(onClick = onToggleSearch) { Icon(Icons.Rounded.Search, "Suchen") }
        if (showSearch) {
            IconButton(onClick = onShuffle) { Icon(Icons.Rounded.Shuffle, "Shuffle") }
            FilledIconButton(onClick = onPlayAll) { Icon(Icons.Rounded.PlayArrow, "Alle abspielen") }
        }
    }
}

/** Kleine Ansichten unter "Home": Songs, Künstler, Alben. */
@Composable
private fun ViewChips(view: Int, onView: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val colors = FilterChipDefaults.filterChipColors(
        selectedContainerColor = cs.primary,
        selectedLabelColor = cs.onPrimary,
    )
    Row(
        Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        listOf("Songs" to 0, "Künstler" to 1, "Alben" to 3).forEach { (label, v) ->
            FilterChip(selected = view == v, onClick = { onView(v) }, label = { Text(label) }, colors = colors)
        }
    }
}

@Composable
private fun GroupRow(group: Group, index: Int, count: Int, round: Boolean, onClick: () -> Unit) {
    val dark = isSystemInDarkTheme()
    val key = group.title.hashCode().toLong() and 0x7fffffffL
    val container = Vivid.container(key, dark)
    val content = readable(container, Vivid.onContainer(key, dark))
    val src = remember { MutableInteractionSource() }
    val coverShape: Shape = if (round) CircleShape else RoundedCornerShape(18.dp)
    Surface(
        onClick = onClick,
        shape = segShape(index, count),
        color = container,
        contentColor = content,
        interactionSource = src,
        modifier = Modifier.fillMaxWidth().pressScale(src, 0.97f),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(group.songs.first(), 160, Modifier.size(60.dp), coverShape)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    group.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    group.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = content.copy(alpha = 0.85f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** Alle Songs eines Künstlers oder Albums. */
@Composable
private fun GroupDetail(
    bottomPad: Dp,
    group: Group,
    round: Boolean,
    currentId: Long?,
    onBack: () -> Unit,
    onPlay: (Boolean) -> Unit,
    onSongClick: (Song) -> Unit,
    onMore: (Song) -> Unit,
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 24.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item {
            Row(
                Modifier.statusBarsPadding().padding(top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Zurück") }
                Cover(
                    group.songs.first(), 160, Modifier.size(52.dp),
                    if (round) CircleShape else RoundedCornerShape(16.dp),
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        group.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        group.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val s1 = remember { MutableInteractionSource() }
                val s2 = remember { MutableInteractionSource() }
                Button(
                    onClick = { onPlay(false) },
                    interactionSource = s1,
                    modifier = Modifier.weight(1f).height(52.dp).pressScale(s1),
                    shape = CircleShape,
                ) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(ButtonDefaults.IconSize))
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text("Abspielen")
                }
                FilledTonalButton(
                    onClick = { onPlay(true) },
                    interactionSource = s2,
                    modifier = Modifier.weight(1f).height(52.dp).pressScale(s2),
                    shape = CircleShape,
                ) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(ButtonDefaults.IconSize))
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text("Shuffle")
                }
            }
        }
        itemsIndexed(group.songs, key = { _, s -> s.id }) { i, s ->
            SongRow(
                song = s,
                index = i,
                count = group.songs.size,
                isCurrent = s.id == currentId,
                onClick = { onSongClick(s) },
                onMore = { onMore(s) },
            )
        }
    }
}
