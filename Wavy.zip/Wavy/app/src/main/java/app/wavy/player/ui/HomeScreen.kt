package app.wavy.player.ui

import androidx.compose.animation.core.spring
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.SortByAlpha
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

data class Group(val key: String, val title: String, val subtitle: String, val songs: List<Song>)

private fun songsLabel(n: Int) = "$n " + if (n == 1) "Song" else "Songs"

private fun artistGroups(songs: List<Song>, prefix: String): List<Group> =
    songs.groupBy { it.artistLabel }
        .map { (name, l) -> Group("$prefix$name", name, songsLabel(l.size), l) }
        .sortedBy { it.title.lowercase() }

private fun albumGroups(songs: List<Song>): List<Group> =
    songs.filter { it.album.isNotBlank() }
        .groupBy { it.album }
        .map { (name, l) ->
            val artists = l.map { it.artistLabel }.distinct()
            val who = if (artists.size == 1) artists[0] else "Verschiedene Interpreten"
            Group("album:$name", name, "$who · ${songsLabel(l.size)}", l)
        }
        .sortedBy { it.title.lowercase() }

private val VIEW_LABELS = listOf("Songs", "Künstler", "Heruntergeladen", "Alben")

@Composable
fun HomeScreen(
    songs: List<Song>,
    loaded: Boolean,
    granted: Boolean,
    excluded: Set<Long>,
    currentId: Long?,
    bottomPad: Dp,
    view: Int,
    onView: (Int) -> Unit,
    groupKey: String?,
    onGroup: (String?) -> Unit,
    onRequestPermission: () -> Unit,
    onPlayAll: (List<Song>) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onSongClick: (List<Song>, Song) -> Unit,
    onMore: (Song) -> Unit,
    onPlayGroup: (List<Song>, Boolean) -> Unit,
    onGroupSongClick: (List<Song>, Song) -> Unit,
    loadAlbum: suspend (String, String) -> List<app.wavy.player.data.AlbumTrack>?,
    loadTop: suspend (String) -> List<app.wavy.player.data.AlbumTrack>?,
    loadInfo: suspend (String) -> app.wavy.player.data.ArtistInfo? = { null },
    onOpenLink: (String) -> Unit,
) {
    val groups = remember(songs, view) {
        when (view) {
            1 -> artistGroups(songs, "artist:")
            2 -> artistGroups(songs.filter { it.isDownload }, "dl:")
            3 -> albumGroups(songs)
            else -> emptyList()
        }
    }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val shown = remember(songs, query) {
        val q = query.trim()
        if (q.isEmpty()) songs else songs.filter {
            it.title.contains(q, true) || it.artistLabel.contains(q, true) || it.album.contains(q, true)
        }
    }
    val shownGroups = remember(groups, query) {
        val q = query.trim()
        if (q.isEmpty()) groups else groups.filter { g ->
            g.title.contains(q, true) || g.subtitle.contains(q, true) ||
                g.songs.any { it.title.contains(q, true) || it.artistLabel.contains(q, true) || it.album.contains(q, true) }
        }
    }
    var sort by rememberSaveable { mutableStateOf(0) }
    val listSongs = remember(shown, sort) {
        when (sort) {
            1 -> shown.sortedByDescending { it.dateAdded }
            2 -> shown.sortedWith(compareBy({ it.artistLabel.lowercase() }, { it.title.lowercase() }))
            3 -> shown.sortedByDescending { it.durationMs }
            else -> shown
        }
    }
    val listState = rememberLazyListState()
    val group = groupKey?.let { k -> groups.firstOrNull { it.key == k } }

    Box(Modifier.fillMaxSize()) {
        when {
            !granted -> EmptyState(
                title = "Zugriff auf deine Musik",
                text = "Erlaube den Zugriff auf Audio- und MP4-Dateien, damit Wavy deine Songs anzeigen kann.",
                modifier = Modifier.statusBarsPadding(),
                buttonText = "Zugriff erlauben",
                onButton = onRequestPermission,
            )
            loaded && songs.isEmpty() -> EmptyState(
                title = "Keine Songs gefunden",
                text = "Lade Musik auf dein Handy (z. B. in den Ordner Download oder Music), dann erscheint sie hier.",
                modifier = Modifier.statusBarsPadding(),
            )
            group != null && view == 3 -> AlbumDetail(
                group = group,
                bottomPad = bottomPad,
                currentId = currentId,
                onBack = { onGroup(null) },
                onPlay = { list, shuffle -> onPlayGroup(list, shuffle) },
                onSongClick = { list, s -> onGroupSongClick(list, s) },
                onMore = onMore,
                loadAlbum = loadAlbum,
                onOpenLink = onOpenLink,
            )
            group != null && view == 1 -> ArtistDetail(
                group = group,
                bottomPad = bottomPad,
                currentId = currentId,
                onBack = { onGroup(null) },
                onPlay = { list, shuffle -> onPlayGroup(list, shuffle) },
                onSongClick = { list, s -> onGroupSongClick(list, s) },
                onMore = onMore,
                loadTop = loadTop,
                loadInfo = loadInfo,
                onOpenLink = onOpenLink,
            )
            group != null -> GroupDetail(
                group = group,
                bottomPad = bottomPad,
                round = view != 3,
                currentId = currentId,
                onBack = { onGroup(null) },
                onPlay = { shuffle -> onPlayGroup(group.songs, shuffle) },
                onSongClick = { s -> onGroupSongClick(group.songs, s) },
                onMore = onMore,
            )
            else -> Column(Modifier.fillMaxSize()) {
                TopChips(
                    view = view,
                    onView = onView,
                    showPlay = view == 0,
                    onPlayAll = { onPlayAll(listSongs) },
                    onShuffle = { onShuffle(listSongs) },
                    sort = if (view == 0) sort else -1,
                    onSort = { sort = it },
                    searching = searching,
                    query = query,
                    onQuery = { query = it },
                    onToggleSearch = { searching = !searching; if (!searching) query = "" },
                    showSearch = true,
                )
                ViewChips(view = view, onView = onView)
                if (view == 0) {
                  Box(Modifier.fillMaxSize()) {
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 24.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        if (listSongs.isNotEmpty()) item(key = "playrow") {
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Button(onClick = { onPlayAll(listSongs) }, shape = PlayShape, contentPadding = PaddingValues(horizontal = 18.dp)) {
                                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(ButtonDefaults.IconSize))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Abspielen")
                                }
                                androidx.compose.material3.FilledTonalButton(onClick = { onShuffle(listSongs) }, shape = ShuffleShape, contentPadding = PaddingValues(horizontal = 18.dp)) {
                                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(ButtonDefaults.IconSize))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Shuffle")
                                }
                            }
                        }
                        itemsIndexed(listSongs, key = { _, s -> s.id }) { i, s ->
                            SongRow(
                                song = s,
                                index = i,
                                count = listSongs.size,
                                isCurrent = s.id == currentId,
                                note = if (s.id in excluded) "nicht in Auto-Wiedergabe" else null,
                                onClick = { onSongClick(listSongs, s) },
                                onMore = { onMore(s) },
                            )
                        }
                    }
                    if (sort == 0) FastScroller(
                        state = listState,
                        modifier = Modifier.align(Alignment.CenterEnd).padding(bottom = bottomPad),
                    ) { i -> listSongs.getOrNull(i - 1)?.title?.trim()?.firstOrNull()?.uppercaseChar()?.let { c -> if (c.isLetter()) c.toString() else "#" } ?: "#" }
                  }
                } else if (shownGroups.isEmpty()) {
                    Text(
                        if (query.isNotBlank()) "Nichts gefunden für „${query.trim()}“." else when (view) {
                            2 -> "Keine heruntergeladenen Songs im Ordner Download gefunden."
                            3 -> "Keine Alben gefunden. Deine Songs haben keine Album-Angabe."
                            else -> "Keine Künstler gefunden."
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp),
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 24.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        itemsIndexed(shownGroups, key = { _, g -> g.key }) { i, g ->
                            GroupRow(g, i, shownGroups.size, round = view != 3) { onGroup(g.key) }
                        }
                    }
                }
            }
        }
    }
}

/** Kopfzeile: nur "Home" plus Shuffle und Alles abspielen. */
@Composable
private fun TopChips(
    view: Int,
    onView: (Int) -> Unit,
    showPlay: Boolean,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    searching: Boolean,
    query: String,
    onQuery: (String) -> Unit,
    onToggleSearch: () -> Unit,
    showSearch: Boolean,
    sort: Int = -1,
    onSort: (Int) -> Unit = {},
) {
    var sortMenu by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(searching) { if (searching) focus.requestFocus() }
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (searching) {
            androidx.compose.material3.TextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                placeholder = { Text("Songs, Künstler, Alben") },
                shape = CircleShape,
                colors = androidx.compose.material3.TextFieldDefaults.colors(
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    disabledIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                ),
                modifier = Modifier.weight(1f).focusRequester(focus),
            )
            Spacer(Modifier.width(8.dp))
            androidx.compose.material3.FilledTonalIconButton(
                onClick = onToggleSearch,
                modifier = Modifier.size(48.dp),
                shape = RoundedCornerShape(16.dp),
            ) { Icon(Icons.Rounded.Close, "Suche schließen") }
            return@Row
        }
        Text(
            "Home",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.weight(1f),
        )
        if (sort >= 0) {
            Box {
                androidx.compose.material3.FilledTonalIconButton(
                    onClick = { sortMenu = true },
                    modifier = Modifier.size(48.dp),
                    shape = RoundedCornerShape(16.dp),
                ) { Icon(Icons.AutoMirrored.Rounded.Sort, "Sortieren") }
                WavyMenu(sortMenu, { sortMenu = false }) {
                    val opts = listOf(
                        "Name" to Icons.Rounded.SortByAlpha,
                        "Zuletzt hinzugefügt" to Icons.Rounded.Schedule,
                        "Künstler" to Icons.Rounded.Person,
                        "Länge" to Icons.Rounded.Timer,
                    )
                    opts.forEachIndexed { i, (t, ic) ->
                        WavyMenuItem(icon = ic, title = t, summary = if (i == sort) "aktiv" else null, onClick = { onSort(i); sortMenu = false })
                    }
                }
            }
            Spacer(Modifier.width(6.dp))
        }
        if (showSearch) {
            androidx.compose.material3.FilledTonalIconButton(
                onClick = onToggleSearch,
                modifier = Modifier.size(48.dp),
                shape = RoundedCornerShape(16.dp),
            ) { Icon(Icons.Rounded.Search, "Suchen") }
        }
    }
}

/** Kleine Ansichten unter "Home": Songs, Künstler, Alben. */
@Composable
private fun ViewChips(view: Int, onView: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val items = listOf(
        Triple("Songs", 0, Icons.Rounded.MusicNote),
        Triple("Künstler", 1, Icons.Rounded.Person),
        Triple("Alben", 3, Icons.Rounded.Album),
    )
    // Verbundene Tasten (M3 Expressive): gleiche Abstände, die gewählte wird zur vollen Kapsel
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        items.forEachIndexed { i, (label, v, icon) ->
            val sel = view == v
            val spec = spring<androidx.compose.ui.unit.Dp>(dampingRatio = 0.6f, stiffness = 400f)
            val outer = 24.dp
            val inner = 8.dp
            val tl by androidx.compose.animation.core.animateDpAsState(if (sel || i == 0) outer else inner, spec, label = "tl")
            val bl by androidx.compose.animation.core.animateDpAsState(if (sel || i == 0) outer else inner, spec, label = "bl")
            val tr by androidx.compose.animation.core.animateDpAsState(if (sel || i == items.lastIndex) outer else inner, spec, label = "tr")
            val br by androidx.compose.animation.core.animateDpAsState(if (sel || i == items.lastIndex) outer else inner, spec, label = "br")
            val bg by androidx.compose.animation.animateColorAsState(if (sel) cs.primary else cs.surfaceContainerHigh, label = "vbg")
            val fg by androidx.compose.animation.animateColorAsState(if (sel) cs.onPrimary else cs.onSurfaceVariant, label = "vfg")
            val src = remember { MutableInteractionSource() }
            Surface(
                onClick = { onView(v) },
                shape = RoundedCornerShape(tl, tr, br, bl),
                color = bg,
                contentColor = fg,
                interactionSource = src,
                modifier = Modifier.weight(1f).height(48.dp).pressScale(src, 0.96f),
            ) {
                Row(
                    Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(icon, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun GroupRow(group: Group, index: Int, count: Int, round: Boolean, onClick: () -> Unit) {
    val dark = isSystemInDarkTheme()
    val key = group.title.hashCode().toLong() and 0x7fffffffL
    val container = Vivid.container(key, dark)
    val content = readable(container, Vivid.onContainer(key, dark))
    val src = remember { MutableInteractionSource() }
    val coverShape: Shape = if (round) CircleShape else RoundedCornerShape(18.dp)
    Surface(
        onClick = onClick,
        shape = segShape(index, count),
        color = container,
        contentColor = content,
        interactionSource = src,
        modifier = Modifier.fillMaxWidth().pressScale(src, 0.97f),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(group.songs.first(), 160, Modifier.size(60.dp), coverShape)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    group.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    group.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = content.copy(alpha = 0.85f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** Alle Songs eines Künstlers oder Albums. */
@Composable
private fun GroupDetail(
    bottomPad: Dp,
    group: Group,
    round: Boolean,
    currentId: Long?,
    onBack: () -> Unit,
    onPlay: (Boolean) -> Unit,
    onSongClick: (Song) -> Unit,
    onMore: (Song) -> Unit,
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 24.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item {
            Row(
                Modifier.statusBarsPadding().padding(top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BackButton(onBack, Modifier.padding(start = 4.dp))
                Cover(
                    group.songs.first(), 160, Modifier.size(52.dp),
                    if (round) CircleShape else RoundedCornerShape(16.dp),
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        group.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        group.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                val s1 = remember { MutableInteractionSource() }
                val s2 = remember { MutableInteractionSource() }
                Button(
                    onClick = { onPlay(false) },
                    interactionSource = s1,
                    modifier = Modifier.weight(1f).height(52.dp).pressScale(s1),
                    shape = PlayShape,
                ) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(ButtonDefaults.IconSize))
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text("Abspielen")
                }
                FilledTonalButton(
                    onClick = { onPlay(true) },
                    interactionSource = s2,
                    modifier = Modifier.weight(1f).height(52.dp).pressScale(s2),
                    shape = ShuffleShape,
                ) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(ButtonDefaults.IconSize))
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text("Shuffle")
                }
            }
        }
        itemsIndexed(group.songs, key = { _, s -> s.id }) { i, s ->
            SongRow(
                song = s,
                index = i,
                count = group.songs.size,
                isCurrent = s.id == currentId,
                onClick = { onSongClick(s) },
                onMore = { onMore(s) },
            )
        }
    }
}
