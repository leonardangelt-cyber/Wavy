package app.wavy.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

/**
 * Schwebende Navigationsleiste aus einem Guss: oben läuft der Song (wischen = Titel wechseln),
 * eine dünne Fortschrittslinie verbindet ihn mit den drei Zielen darunter.
 */
@Composable
fun FloatingNavBar(
    selected: Int,
    onSelect: (Int) -> Unit,
    song: Song?,
    nextSong: Song?,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpenPlayer: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(34.dp),
        color = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        shadowElevation = 12.dp,
        tonalElevation = 2.dp,
        modifier = modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .fillMaxWidth()
            .animateContentSize(spring(dampingRatio = 0.8f, stiffness = 400f)),
    ) {
        Column(Modifier.padding(horizontal = 6.dp, vertical = 6.dp)) {
            if (song != null) {
                NowPlayingRow(song, nextSong, isPlaying, onOpenPlayer, onToggle, onNext, onPrevTrack)
                LinearProgressIndicator(
                    progress = progress,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).height(4.dp),
                    color = cs.primary,
                    trackColor = cs.primary.copy(alpha = 0.18f),
                    gapSize = 0.dp,
                    drawStopIndicator = {},
                )
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                NavItem(selected == 0, Icons.Rounded.Home, "Home") { onSelect(0) }
                NavItem(selected == 1, Icons.AutoMirrored.Rounded.QueueMusic, "Playlists") { onSelect(1) }
                NavItem(selected == 2, Icons.Rounded.Settings, "Einstellungen") { onSelect(2) }
            }
        }
    }
}

@Composable
private fun NowPlayingRow(
    song: Song,
    nextSong: Song?,
    isPlaying: Boolean,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var dx by remember { mutableFloatStateOf(0f) }
    val drag = rememberDraggableState { dx += it * 0.6f }
    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { translationX = dx }
            .draggable(
                state = drag,
                orientation = Orientation.Horizontal,
                onDragStopped = { v ->
                    if (dx < -80f || v < -1200f) onNext() else if (dx > 80f || v > 1200f) onPrevTrack()
                    animate(dx, 0f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f)) { x, _ -> dx = x }
                },
            )
            .clip(RoundedCornerShape(28.dp))
            .clickable(onClick = onOpen)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(song, 128, Modifier.size(48.dp), RoundedCornerShape(16.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                song.artistLabel,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(6.dp))
        // Nächster Song als kleines Cover – antippen = überspringen
        if (nextSong != null) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onNext),
                contentAlignment = Alignment.Center,
            ) {
                Cover(nextSong, 96, Modifier.fillMaxSize(), CircleShape)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
                Icon(Icons.Rounded.SkipNext, "Nächster Song: ${nextSong.title}", Modifier.size(22.dp), tint = Color.White)
            }
            Spacer(Modifier.width(6.dp))
        }
        FilledIconButton(onClick = onToggle, modifier = Modifier.size(44.dp)) {
            Icon(
                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                if (isPlaying) "Pause" else "Abspielen",
                Modifier.size(26.dp),
            )
        }
    }
}

@Composable
private fun RowScope.NavItem(
    selected: Boolean,
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (selected) cs.primary else Color.Transparent, label = "navBg")
    val fg = if (selected) cs.onPrimary else cs.onSurfaceVariant
    val src = remember { MutableInteractionSource() }
    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
        Row(
            Modifier
                .pressScale(src, 0.92f)
                .clip(CircleShape)
                .background(bg)
                .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick)
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, label, tint = fg)
            AnimatedVisibility(
                visible = selected,
                enter = expandHorizontally(spring(dampingRatio = 0.8f, stiffness = 400f)) + fadeIn(),
                exit = shrinkHorizontally(spring(dampingRatio = 0.8f, stiffness = 400f)) + fadeOut(),
            ) {
                Text(
                    label,
                    color = fg,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier.padding(start = 8.dp),
                )
            }
        }
    }
}
