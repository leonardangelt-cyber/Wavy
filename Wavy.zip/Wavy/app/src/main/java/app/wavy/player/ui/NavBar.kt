package app.wavy.player.ui

import androidx.compose.ui.unit.Dp
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.expandVertically
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.sin
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

/**
 * Eine gemeinsame schwebende Leiste (Material 3 Expressive): in einem tonalen Container sitzt oben der
 * Mini-Player (klappt beim Start/Ende weich auf und zu), darunter die Navigations-Kapsel mit gleichmäßig
 * verteilten Zielen. Der Container ist zugleich der Ursprung der Player-Animation.
 */
@Composable
fun FloatingNavBar(
    selected: Int,
    onSelect: (Int) -> Unit,
    song: Song?,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpenPlayer: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
    onMiniBounds: (Rect) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    var last by remember { mutableStateOf<Song?>(null) }
    SideEffect { if (song != null) last = song }
    val shown = song ?: last

    val hasSong = song != null
    val spec = spring<Dp>(dampingRatio = 0.8f, stiffness = 380f)
    val containerColor by animateColorAsState(if (hasSong) cs.primaryContainer else Color.Transparent, tween(300), label = "navContainer")
    val pillColor by animateColorAsState(if (hasSong) cs.surfaceContainerHigh else cs.secondaryContainer, tween(300), label = "pillColor")
    val outerPad by animateDpAsState(if (hasSong) 8.dp else 0.dp, spec, label = "outerPad")
    val outerShadow by animateDpAsState(if (hasSong) 12.dp else 0.dp, spec, label = "outerShadow")
    val pillShadow by animateDpAsState(if (hasSong) 0.dp else 12.dp, spec, label = "pillShadow")
    val frac by animateFloatAsState(if (hasSong) 1f else 0.78f, spring(dampingRatio = 0.8f, stiffness = 380f), label = "navFrac")

    // Ohne Musik: nur die schlanke Kapsel, kein Container drumherum
    Column(
        modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Surface(
            shape = RoundedCornerShape(36.dp),
            color = containerColor,
            contentColor = cs.onPrimaryContainer,
            shadowElevation = outerShadow,
            modifier = Modifier
                .fillMaxWidth(frac)
                .onGloballyPositioned { onMiniBounds(it.boundsInRoot()) }
                .animateContentSize(spring(dampingRatio = 0.8f, stiffness = 380f)),
        ) {
            Column(Modifier.padding(outerPad)) {
                AnimatedVisibility(
                    visible = hasSong,
                    enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 380f)) + fadeIn(tween(220)),
                    exit = shrinkVertically(tween(220)) + fadeOut(tween(140)),
                ) {
                    if (shown != null) {
                        MiniContent(shown, isPlaying, progress, onOpenPlayer, onToggle, onNext, onPrevTrack)
                    }
                }
                Surface(
                    shape = CircleShape,
                    color = pillColor,
                    contentColor = cs.onSurface,
                    shadowElevation = pillShadow,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        NavItem(selected == 0, Icons.Rounded.Home, "Home") { onSelect(0) }
                        NavItem(selected == 1, Icons.AutoMirrored.Rounded.QueueMusic, "Playlists") { onSelect(1) }
                        NavItem(selected == 2, Icons.Rounded.Settings, "Einstellungen") { onSelect(2) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniContent(
    song: Song,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var dx by remember { mutableFloatStateOf(0f) }
    val drag = rememberDraggableState { dx += it * 0.6f }
    // Der Play-Knopf wechselt seine Form: eckiger beim Spielen, rund bei Pause
    val corner by animateDpAsState(
        if (isPlaying) 16.dp else 23.dp,
        spring(dampingRatio = 0.55f, stiffness = 400f),
        label = "playShape",
    )
    Column(
        Modifier
            .padding(bottom = 6.dp)
            .graphicsLayer { translationX = dx }
            .draggable(
                state = drag,
                orientation = Orientation.Horizontal,
                onDragStopped = { v ->
                    if (dx < -70f || v < -1200f) onNext() else if (dx > 70f || v > 1200f) onPrevTrack()
                    animate(dx, 0f, animationSpec = spring(dampingRatio = 0.6f, stiffness = 350f)) { x, _ -> dx = x }
                },
            ),
    ) {
        Row(
            Modifier
                .clip(RoundedCornerShape(28.dp))
                .clickable(onClick = onOpen)
                .padding(start = 4.dp, end = 2.dp, top = 4.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Cover(song, 128, Modifier.size(56.dp), RoundedCornerShape(20.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song.artistLabel,
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onPrimaryContainer.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            FilledIconButton(
                onClick = onToggle,
                modifier = Modifier.size(46.dp),
                shape = RoundedCornerShape(corner),
            ) {
                Icon(
                    if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (isPlaying) "Pause" else "Abspielen",
                    Modifier.size(26.dp),
                )
            }
            IconButton(onClick = onNext, modifier = Modifier.size(44.dp)) {
                Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(28.dp))
            }
        }
        WaveLine(
            progress = progress,
            playing = isPlaying,
            color = cs.primary,
            modifier = Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 2.dp),
        )
    }
}

/** Kleine Wellenlinie als Fortschrittsanzeige. Läuft nur beim Abspielen, sonst kostet sie nichts. */
@Composable
private fun WaveLine(progress: () -> Float, playing: Boolean, color: Color, modifier: Modifier = Modifier) {
    val phaseAnim = remember { Animatable(0f) }
    LaunchedEffect(playing) {
        if (playing) {
            while (true) {
                phaseAnim.snapTo(0f)
                phaseAnim.animateTo((2 * PI).toFloat(), tween(1600, easing = LinearEasing))
            }
        }
    }
    val amp by animateFloatAsState(if (playing) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 200f), label = "miniAmp")
    val path = remember { Path() }
    Canvas(modifier.height(14.dp)) {
        val w = size.width
        val cy = size.height / 2
        val stroke = 3.dp.toPx()
        val x = w * progress().coerceIn(0f, 1f)
        val phase = phaseAnim.value
        drawLine(color.copy(alpha = 0.25f), Offset(x, cy), Offset(w, cy), stroke, StrokeCap.Round)
        if (x > 0f) {
            path.rewind()
            val wave = 26.dp.toPx()
            val a = 2.5.dp.toPx() * amp
            val step = 3.dp.toPx()
            var px = 0f
            path.moveTo(0f, cy)
            while (px < x) {
                val fade = (px / 12.dp.toPx()).coerceIn(0f, 1f)
                path.lineTo(px, cy + a * fade * sin(px / wave * 2f * PI.toFloat() - phase))
                px += step
            }
            path.lineTo(x, cy + a * sin(x / wave * 2f * PI.toFloat() - phase))
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

@Composable
private fun NavItem(selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (selected) cs.primary else Color.Transparent, tween(250), label = "navBg")
    val fg by animateColorAsState(if (selected) cs.onPrimary else cs.onSurfaceVariant, tween(250), label = "navFg")
    val r by animateDpAsState(if (selected) 24.dp else 20.dp, spring(dampingRatio = 0.55f, stiffness = 400f), label = "navShape")
    val src = remember { MutableInteractionSource() }
    Row(
        Modifier
            .pressScale(src, 0.92f)
            .clip(RoundedCornerShape(r))
            .background(bg)
            .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .animateContentSize(spring(dampingRatio = 0.7f, stiffness = 450f)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, label, tint = fg)
        if (selected) {
            Text(
                label,
                color = fg,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
    }
}
