package app.wavy.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.sin
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

/**
 * Material-3-Expressive-Stil: oben die Now-Playing-Karte (große Rundung, Cover mit weicher Ecke,
 * Play-Knopf der seine Form wechselt, Wellen-Fortschritt), darunter die schwebende Toolbar mit
 * federnder Auswahl-Kapsel. Alles tonal in den Cover-Farben.
 */
@Composable
fun FloatingNavBar(
    selected: Int,
    onSelect: (Int) -> Unit,
    song: Song?,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpenPlayer: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
    onMiniBounds: (Rect) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    var last by remember { mutableStateOf<Song?>(null) }
    SideEffect { if (song != null) last = song }
    val shown = song ?: last

    Column(
        modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        AnimatedVisibility(
            visible = song != null,
            enter = slideInVertically(spring(dampingRatio = 0.7f, stiffness = 380f)) { it / 2 } +
                fadeIn(tween(220)) + scaleIn(spring(dampingRatio = 0.75f, stiffness = 380f), initialScale = 0.88f),
            exit = slideOutVertically(tween(220)) { it / 2 } + fadeOut(tween(160)) + scaleOut(tween(220), targetScale = 0.9f),
        ) {
            if (shown != null) {
                MiniCard(shown, isPlaying, progress, onOpenPlayer, onToggle, onNext, onPrevTrack, onMiniBounds)
            }
        }
        // Schwebende Toolbar
        Surface(
            shape = CircleShape,
            color = cs.secondaryContainer,
            contentColor = cs.onSecondaryContainer,
            shadowElevation = 10.dp,
            tonalElevation = 3.dp,
        ) {
            Row(
                Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NavItem(selected == 0, Icons.Rounded.Home, "Home") { onSelect(0) }
                NavItem(selected == 1, Icons.AutoMirrored.Rounded.QueueMusic, "Playlists") { onSelect(1) }
                NavItem(selected == 2, Icons.Rounded.Settings, "Einstellungen") { onSelect(2) }
            }
        }
    }
}

@Composable
private fun MiniCard(
    song: Song,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
    onBounds: (Rect) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var dx by remember { mutableFloatStateOf(0f) }
    val drag = rememberDraggableState { dx += it * 0.6f }
    // Der Play-Knopf wechselt seine Form: eckiger beim Spielen, rund bei Pause
    val corner by animateDpAsState(
        if (isPlaying) 16.dp else 23.dp,
        spring(dampingRatio = 0.55f, stiffness = 400f),
        label = "playShape",
    )
    Surface(
        onClick = onOpen,
        shape = RoundedCornerShape(32.dp),
        color = cs.primaryContainer,
        contentColor = cs.onPrimaryContainer,
        shadowElevation = 10.dp,
        tonalElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .onGloballyPositioned { onBounds(it.boundsInRoot()) }
            .graphicsLayer { translationX = dx }
            .draggable(
                state = drag,
                orientation = Orientation.Horizontal,
                onDragStopped = { v ->
                    if (dx < -70f || v < -1200f) onNext() else if (dx > 70f || v > 1200f) onPrevTrack()
                    animate(dx, 0f, animationSpec = spring(dampingRatio = 0.6f, stiffness = 350f)) { x, _ -> dx = x }
                },
            ),
    ) {
        Column {
            Row(
                Modifier.padding(start = 12.dp, end = 10.dp, top = 12.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Cover(song, 128, Modifier.size(56.dp), RoundedCornerShape(20.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        song.artistLabel,
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onPrimaryContainer.copy(alpha = 0.8f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                FilledIconButton(
                    onClick = onToggle,
                    modifier = Modifier.size(46.dp),
                    shape = RoundedCornerShape(corner),
                ) {
                    Icon(
                        if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (isPlaying) "Pause" else "Abspielen",
                        Modifier.size(26.dp),
                    )
                }
                IconButton(onClick = onNext, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(28.dp))
                }
            }
            WaveLine(
                progress = progress,
                playing = isPlaying,
                color = cs.primary,
                modifier = Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, bottom = 10.dp),
            )
        }
    }
}

/** Kleine Wellenlinie als Fortschrittsanzeige (nur beim Zeichnen gelesen, kostet kaum). */
@Composable
private fun WaveLine(progress: () -> Float, playing: Boolean, color: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "miniWave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart),
        label = "miniPhase",
    )
    val amp by animateFloatAsState(if (playing) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 200f), label = "miniAmp")
    Canvas(modifier.height(14.dp)) {
        val w = size.width
        val cy = size.height / 2
        val stroke = 3.dp.toPx()
        val x = w * progress().coerceIn(0f, 1f)
        drawLine(color.copy(alpha = 0.25f), Offset(x, cy), Offset(w, cy), stroke, StrokeCap.Round)
        if (x > 0f) {
            val path = Path()
            val wave = 26.dp.toPx()
            val a = 2.5.dp.toPx() * amp
            var px = 0f
            path.moveTo(0f, cy)
            while (px < x) {
                val fade = (px / 12.dp.toPx()).coerceIn(0f, 1f)
                path.lineTo(px, cy + a * fade * sin(px / wave * 2f * PI.toFloat() - phase))
                px += 2.dp.toPx()
            }
            path.lineTo(x, cy + a * sin(x / wave * 2f * PI.toFloat() - phase))
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

@Composable
private fun NavItem(selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (selected) cs.primary else Color.Transparent, tween(250), label = "navBg")
    val fg by animateColorAsState(if (selected) cs.onPrimary else cs.onSecondaryContainer, tween(250), label = "navFg")
    val r by animateDpAsState(if (selected) 24.dp else 20.dp, spring(dampingRatio = 0.55f, stiffness = 400f), label = "navShape")
    val src = remember { MutableInteractionSource() }
    Row(
        Modifier
            .pressScale(src, 0.9f)
            .clip(RoundedCornerShape(r))
            .background(bg)
            .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .animateContentSize(spring(dampingRatio = 0.7f, stiffness = 450f)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, label, tint = fg)
        if (selected) {
            Text(
                label,
                color = fg,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
    }
}
