package app.wavy.player.ui

import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

/**
 * Schwebende Leiste: oben die Mini-Player-Karte (gleitet beim Start/Ende ein und aus, Wischen = Titel wechseln),
 * darunter die kompakte Navigations-Kapsel. Beide heben sich mit Rand und Schatten vom Inhalt ab.
 */
@Composable
fun FloatingNavBar(
    selected: Int,
    onSelect: (Int) -> Unit,
    song: Song?,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpenPlayer: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
    onMiniBounds: (Rect) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.4f))
    var last by remember { mutableStateOf<Song?>(null) }
    SideEffect { if (song != null) last = song }
    val shown = song ?: last

    Column(
        modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        AnimatedVisibility(
            visible = song != null,
            enter = slideInVertically(spring(dampingRatio = 0.78f, stiffness = 380f)) { it / 2 } +
                fadeIn(tween(220)) + scaleIn(spring(dampingRatio = 0.8f, stiffness = 380f), initialScale = 0.9f),
            exit = slideOutVertically(tween(220)) { it / 2 } + fadeOut(tween(160)) + scaleOut(tween(220), targetScale = 0.9f),
        ) {
            if (shown != null) {
                MiniCard(shown, isPlaying, progress, onOpenPlayer, onToggle, onNext, onPrevTrack, border, onMiniBounds)
            }
        }
        Surface(
            shape = CircleShape,
            color = cs.surfaceContainerHighest,
            contentColor = cs.onSurface,
            border = border,
            shadowElevation = 16.dp,
        ) {
            Row(
                Modifier.padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NavItem(selected == 0, Icons.Rounded.Home, "Home") { onSelect(0) }
                NavItem(selected == 1, Icons.AutoMirrored.Rounded.QueueMusic, "Playlists") { onSelect(1) }
                NavItem(selected == 2, Icons.Rounded.Settings, "Einstellungen") { onSelect(2) }
            }
        }
    }
}

@Composable
private fun MiniCard(
    song: Song,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
    border: BorderStroke,
    onBounds: (Rect) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var dx by remember { mutableFloatStateOf(0f) }
    val drag = rememberDraggableState { dx += it * 0.6f }
    Surface(
        onClick = onOpen,
        shape = RoundedCornerShape(30.dp),
        color = cs.primaryContainer,
        contentColor = cs.onPrimaryContainer,
        border = border,
        shadowElevation = 18.dp,
        modifier = Modifier
            .fillMaxWidth()
            .onGloballyPositioned { onBounds(it.boundsInRoot()) }
            .graphicsLayer { translationX = dx }
            .draggable(
                state = drag,
                orientation = Orientation.Horizontal,
                onDragStopped = { v ->
                    if (dx < -70f || v < -1200f) onNext() else if (dx > 70f || v > 1200f) onPrevTrack()
                    animate(dx, 0f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f)) { x, _ -> dx = x }
                },
            ),
    ) {
        Column {
            Row(
                Modifier.padding(start = 10.dp, end = 10.dp, top = 10.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Cover(song, 128, Modifier.size(52.dp), RoundedCornerShape(18.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        song.artistLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onPrimaryContainer.copy(alpha = 0.8f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                FilledIconButton(onClick = onToggle, modifier = Modifier.size(46.dp)) {
                    Icon(
                        if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (isPlaying) "Pause" else "Abspielen",
                        Modifier.size(26.dp),
                    )
                }
                IconButton(onClick = onNext, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(26.dp))
                }
            }
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 10.dp).height(4.dp),
                color = cs.primary,
                trackColor = cs.primary.copy(alpha = 0.2f),
                gapSize = 0.dp,
                drawStopIndicator = {},
            )
        }
    }
}

@Composable
private fun NavItem(selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (selected) cs.primary else Color.Transparent, tween(250), label = "navBg")
    val fg by animateColorAsState(if (selected) cs.onPrimary else cs.onSurfaceVariant, tween(250), label = "navFg")
    val src = remember { MutableInteractionSource() }
    Row(
        Modifier
            .pressScale(src, 0.92f)
            .clip(CircleShape)
            .background(bg)
            .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .animateContentSize(spring(dampingRatio = 0.8f, stiffness = 500f)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, label, tint = fg)
        if (selected) {
            Text(
                label,
                color = fg,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
    }
}
