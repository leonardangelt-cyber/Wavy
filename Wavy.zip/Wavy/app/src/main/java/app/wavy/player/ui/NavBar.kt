package app.wavy.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.wavy.player.data.Song

/**
 * Zwei schwebende Kapseln nebeneinander: links die Navigation (kompakt), rechts der Mini-Player
 * (Wischen = Titel wechseln, Antippen = Player öffnen). Beide heben sich mit Rand und Schatten vom Hintergrund ab.
 */
@Composable
fun FloatingNavBar(
    selected: Int,
    onSelect: (Int) -> Unit,
    song: Song?,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpenPlayer: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.45f))
    Row(
        modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(
            shape = CircleShape,
            color = cs.surfaceContainerHighest,
            contentColor = cs.onSurface,
            border = border,
            shadowElevation = 14.dp,
        ) {
            Row(Modifier.padding(5.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                NavIcon(selected == 0, Icons.Rounded.Home, "Home") { onSelect(0) }
                NavIcon(selected == 1, Icons.AutoMirrored.Rounded.QueueMusic, "Playlists") { onSelect(1) }
                NavIcon(selected == 2, Icons.Rounded.Settings, "Einstellungen") { onSelect(2) }
            }
        }
        if (song != null) {
            MiniCapsule(Modifier.weight(1f), song, isPlaying, progress, onOpenPlayer, onToggle, onNext, onPrevTrack, border)
        }
    }
}

@Composable
private fun MiniCapsule(
    modifier: Modifier,
    song: Song,
    isPlaying: Boolean,
    progress: () -> Float,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevTrack: () -> Unit,
    border: BorderStroke,
) {
    val cs = MaterialTheme.colorScheme
    var dx by remember { mutableFloatStateOf(0f) }
    val drag = rememberDraggableState { dx += it * 0.6f }
    Surface(
        onClick = onOpen,
        shape = CircleShape,
        color = cs.primaryContainer,
        contentColor = cs.onPrimaryContainer,
        border = border,
        shadowElevation = 14.dp,
        modifier = modifier
            .height(56.dp)
            .graphicsLayer { translationX = dx }
            .draggable(
                state = drag,
                orientation = Orientation.Horizontal,
                onDragStopped = { v ->
                    if (dx < -70f || v < -1200f) onNext() else if (dx > 70f || v > 1200f) onPrevTrack()
                    animate(dx, 0f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f)) { x, _ -> dx = x }
                },
            ),
    ) {
        Row(Modifier.padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = progress,
                    modifier = Modifier.fillMaxSize(),
                    color = cs.primary,
                    trackColor = cs.onPrimaryContainer.copy(alpha = 0.15f),
                    strokeWidth = 2.5.dp,
                )
                Cover(song, 96, Modifier.size(36.dp), CircleShape)
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song.artistLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onPrimaryContainer.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            FilledIconButton(onClick = onToggle, modifier = Modifier.size(40.dp)) {
                Icon(
                    if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (isPlaying) "Pause" else "Abspielen",
                    Modifier.size(24.dp),
                )
            }
        }
    }
}

@Composable
private fun NavIcon(selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (selected) cs.primary else Color.Transparent, label = "navBg")
    val fg = if (selected) cs.onPrimary else cs.onSurfaceVariant
    val src = remember { MutableInteractionSource() }
    Box(
        Modifier
            .size(46.dp)
            .pressScale(src, 0.9f)
            .clip(CircleShape)
            .background(bg)
            .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, label, tint = fg) }
}
