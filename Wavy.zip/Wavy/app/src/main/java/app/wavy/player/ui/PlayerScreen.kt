package app.wavy.player.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.LongState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import androidx.media3.common.Player
import app.wavy.player.PlayerUi
import app.wavy.player.data.LyricsUi
import app.wavy.player.data.Song
import app.wavy.player.data.TranslationStatus
import app.wavy.player.data.TranslationUi
import kotlin.math.abs
import kotlin.math.PI
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    song: Song,
    prevSong: Song?,
    nextSong: Song?,
    queue: List<Song>,
    onPlayQueueItem: (Song) -> Unit,
    state: PlayerUi,
    positionMs: LongState,
    lyrics: LyricsUi,
    translation: TranslationUi,
    onTranslate: () -> Unit,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onPrevTrack: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onSeekFraction: (Float) -> Unit,
    onSeekMs: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
) {
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val duration = if (state.durationMs > 0) state.durationMs else song.durationMs

    val corner by animateDpAsState(
        if (state.isPlaying) 12.dp else 8.dp,
        spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "coverCorner",
    )
    val scale by animateFloatAsState(
        1f,
        spring(dampingRatio = 0.55f, stiffness = 300f),
        label = "coverScale",
    )
    val playCorner by animateDpAsState(
        if (state.isPlaying) 28.dp else 42.dp,
        spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "playCorner",
    )

    // Nach unten wischen schließt den Player (Überscroll-Geste, funktioniert überall außer auf Zeitstrahl und Cover)
    var dismissPx by remember { mutableFloatStateOf(0f) }
    var screenH by remember { mutableIntStateOf(1) }
    val closeNow by rememberUpdatedState(onClose)
    val dismissConn = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (dismissPx > 0f && available.y < 0f) {
                    val newV = (dismissPx + available.y).coerceAtLeast(0f)
                    val used = newV - dismissPx
                    dismissPx = newV
                    return Offset(0f, used)
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f) {
                    dismissPx += available.y
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (dismissPx <= 0f) return Velocity.Zero
                if (dismissPx > screenH * 0.2f || available.y > 1500f) {
                    animate(dismissPx, screenH.toFloat(), animationSpec = tween(180)) { v, _ -> dismissPx = v }
                    closeNow()
                } else {
                    animate(dismissPx, 0f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f)) { v, _ -> dismissPx = v }
                }
                return available
            }
        }
    }

    // Wischen auf Cover/Titel: links = nächster Song, rechts = vorheriger Song
    var swipePx by remember { mutableFloatStateOf(0f) }
    var swipeW by remember { mutableIntStateOf(1) }
    val swipeState = rememberDraggableState { d -> swipePx += d }
    val density = LocalDensity.current
    // Wechselt der Song, springt das Karussell nahtlos in die Mitte (der neue Song steht schon an der richtigen Stelle)
    var lastId by remember { mutableLongStateOf(song.id) }
    if (song.id != lastId) {
        lastId = song.id
        swipePx = 0f
    }

    // Komplett deckender Hintergrund (nichts schimmert durch), Touches werden hier abgefangen.
    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { screenH = it.height }
            .graphicsLayer { translationY = dismissPx }
            .background(cs.surface)
            .background(
                Brush.verticalGradient(
                    0f to cs.primaryContainer,
                    0.65f to cs.surface,
                    1f to cs.surface,
                ),
            )
            .pointerInput(Unit) { detectTapGestures { } }
            .nestedScroll(dismissConn),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalIconButton(onClick = onClose, modifier = Modifier.size(52.dp), shape = CircleShape) {
                    Icon(Icons.Rounded.KeyboardArrowDown, "Schließen", Modifier.size(30.dp))
                }
                Text(
                    "Aktuelle Wiedergabe",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f).padding(start = 20.dp),
                )
            }
            Spacer(Modifier.height(16.dp))

            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val coverSize = if (maxWidth < 600.dp) maxWidth else 600.dp
                Box(
                    Modifier
                        .fillMaxWidth()
                        .onSizeChanged { swipeW = it.width }
                        .draggable(
                            state = swipeState,
                            orientation = Orientation.Horizontal,
                            onDragStopped = { v ->
                                val pitch = swipeW + with(density) { 24.dp.toPx() }
                                val go = when {
                                    swipePx < -pitch * 0.22f || v < -900f -> -1
                                    swipePx > pitch * 0.22f || v > 900f -> 1
                                    else -> 0
                                }
                                val ok = (go < 0 && nextSong != null) || (go > 0 && prevSong != null)
                                if (!ok) {
                                    animate(swipePx, 0f, animationSpec = spring(dampingRatio = 0.75f, stiffness = 380f)) { x, _ -> swipePx = x }
                                } else {
                                    animate(
                                        swipePx,
                                        go * pitch,
                                        initialVelocity = v,
                                        animationSpec = spring(dampingRatio = 0.9f, stiffness = 450f),
                                    ) { x, _ -> swipePx = x }
                                    if (go < 0) onNext() else onPrevTrack()
                                    // Falls der Titel gleich bleibt (z. B. Einzelwiederholung): zurückfedern
                                    delay(700)
                                    if (swipePx != 0f) {
                                        animate(swipePx, 0f, animationSpec = spring(dampingRatio = 0.8f, stiffness = 380f)) { x, _ -> swipePx = x }
                                    }
                                }
                            },
                        ),
                ) {
                    // Vorheriges Cover: direkt links neben dem aktuellen
                    if (prevSong != null) {
                        Box(
                            Modifier.matchParentSize().graphicsLayer {
                                translationX = swipePx - (swipeW + 24.dp.toPx())
                                alpha = if (swipePx == 0f) 0f else 1f
                            },
                        ) { TrackSlot(prevSong, coverSize, scale, corner) }
                    }
                    // Nächstes Cover: direkt rechts daneben, schiebt sich beim Wischen herein
                    if (nextSong != null) {
                        Box(
                            Modifier.matchParentSize().graphicsLayer {
                                translationX = swipePx + (swipeW + 24.dp.toPx())
                                alpha = if (swipePx == 0f) 0f else 1f
                            },
                        ) { TrackSlot(nextSong, coverSize, scale, corner) }
                    }
                    Box(Modifier.graphicsLayer { translationX = swipePx }) {
                        TrackSlot(song, coverSize, scale, corner)
                    }
                    FilledTonalIconButton(
                        onClick = { showQueue = true },
                        modifier = Modifier.align(Alignment.BottomEnd).size(56.dp),
                        shape = CircleShape,
                    ) { Icon(Icons.AutoMirrored.Rounded.QueueMusic, "Als Nächstes") }
                }
            }
            Spacer(Modifier.height(12.dp))

            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                SeekSection(
                    positionMs = positionMs,
                    durationMs = duration,
                    playing = state.isPlaying,
                    onSeek = onSeekFraction,
                )
            }
            Spacer(Modifier.height(12.dp))

            var act by remember { mutableIntStateOf(-1) }
            val setAct: (Int, Boolean) -> Unit = { i, on ->
                if (on) act = i else if (act == i) act = -1
            }
            // Der gedrückte Knopf wird richtig groß, die anderen machen Platz
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TransportButton(0, act, setAct, 1f, onPrev, CircleShape, cs.primaryContainer, cs.onPrimaryContainer) {
                    Icon(Icons.Rounded.SkipPrevious, "Zurück", Modifier.size(36.dp))
                }
                TransportButton(1, act, setAct, 1.2f, onToggle, RoundedCornerShape(playCorner), cs.primary, cs.onPrimary) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (state.isPlaying) "Pause" else "Abspielen",
                        Modifier.size(44.dp),
                    )
                }
                TransportButton(2, act, setAct, 1f, onNext, CircleShape, cs.primaryContainer, cs.onPrimaryContainer) {
                    Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(36.dp))
                }
            }
            Spacer(Modifier.height(14.dp))

            // Shuffle, Wiederholen, Songtext in einer Pille
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                color = cs.surfaceContainer,
                contentColor = cs.onSurface,
            ) {
                Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    PillAction(state.shuffle, Icons.Rounded.Shuffle, "Shuffle", onShuffle)
                    PillAction(
                        state.repeat != Player.REPEAT_MODE_OFF,
                        if (state.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        when (state.repeat) {
                            Player.REPEAT_MODE_ONE -> "Einmal wiederholen"
                            Player.REPEAT_MODE_ALL -> "Alles wiederholen"
                            else -> "Wiederholung aus"
                        },
                        onRepeat,
                    )
                    PillAction(showLyrics, Icons.Rounded.Lyrics, "Songtext") { showLyrics = !showLyrics }
                    PillAction(false, Icons.AutoMirrored.Rounded.PlaylistAdd, "Zu Playlist hinzufügen", onAddToPlaylist)
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showQueue) {
        ModalBottomSheet(
            onDismissRequest = { showQueue = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = cs.surfaceContainerHigh,
            contentColor = cs.onSurface,
        ) {
            Text(
                "Als Nächstes",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            )
            if (queue.isEmpty()) {
                Text(
                    "Danach kommt nichts mehr.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(24.dp),
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxHeight(0.7f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    itemsIndexed(queue) { i, q ->
                        SongRow(
                            song = q,
                            index = i,
                            count = queue.size,
                            isCurrent = false,
                            onClick = { onPlayQueueItem(q) },
                        )
                    }
                }
            }
        }
    }

    if (showLyrics) {
        ModalBottomSheet(
            onDismissRequest = { showLyrics = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = cs.surfaceContainerHigh,
            contentColor = cs.onSurface,
        ) {
            var showTr by rememberSaveable { mutableStateOf(true) }
            LyricsHeader(translation, showTr, onTranslate) { showTr = !showTr }
            LyricsContent(
                lyrics,
                positionMs,
                onSeekMs,
                if (showTr && translation.status == TranslationStatus.Done) translation.map else emptyMap(),
            )
        }
    }
}

/** Cover + Titel eines Songs (ein "Slot" im Wisch-Karussell). */
@Composable
private fun TrackSlot(song: Song, size: Dp, scale: Float, corner: Dp) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        CoverFramed(
            song = song,
            px = 900,
            modifier = Modifier
                .size(size)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                },
            shape = RoundedCornerShape(corner),
        )
        Spacer(Modifier.height(24.dp))
        Column(Modifier.fillMaxWidth().padding(end = 68.dp)) {
            Text(
                song.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                song.artistLabel,
                style = MaterialTheme.typography.titleMedium,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** Play/Zurück/Weiter: beim Drücken (und bei jedem Tippen) wächst der Knopf stark, die anderen weichen aus. */
@Composable
private fun RowScope.TransportButton(
    index: Int,
    active: Int,
    onActive: (Int, Boolean) -> Unit,
    baseWeight: Float,
    onClick: () -> Unit,
    shape: Shape,
    container: Color,
    content: Color,
    icon: @Composable () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    var bump by remember { mutableStateOf(false) }
    LaunchedEffect(bump) {
        if (bump) {
            delay(220)
            bump = false
        }
    }
    val on = pressed || bump
    LaunchedEffect(on) { onActive(index, on) }
    val target = when {
        active == index -> baseWeight * 1.9f
        active >= 0 -> baseWeight * 0.7f
        else -> baseWeight
    }
    val w by animateFloatAsState(target, spring(dampingRatio = 0.55f, stiffness = 380f), label = "transportWeight")
    FilledIconButton(
        onClick = {
            bump = true
            onClick()
        },
        modifier = Modifier.weight(w.coerceAtLeast(0.1f)).height(92.dp),
        shape = shape,
        colors = IconButtonDefaults.filledIconButtonColors(containerColor = container, contentColor = content),
        interactionSource = src,
    ) { icon() }
}

/** Ein Segment der Aktions-Pille: aktiv = große Kapsel, inaktiv = eckiger. */
@Composable
private fun RowScope.PillAction(
    checked: Boolean,
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val r by animateDpAsState(
        if (checked) 22.dp else 14.dp,
        spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "pillCorner",
    )
    val bg by animateColorAsState(if (checked) cs.primary else cs.surfaceContainerHighest, label = "pillBg")
    val fg = if (checked) cs.onPrimary else cs.onSurface
    Box(
        Modifier
            .weight(1f)
            .height(44.dp)
            .pressScale(src, 1.06f)
            .clip(RoundedCornerShape(r))
            .background(bg)
            .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = fg, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun TimeText(ms: () -> Long, style: TextStyle = MaterialTheme.typography.labelLarge) {
    val current by rememberUpdatedState(ms)
    val sec by remember { derivedStateOf { current() / 1000 } }
    Text(formatTime(sec * 1000), style = style, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Zeitstrahl mit Welle, Punkt (Griff) und Zeiten. Antippen oder Ziehen zum Spulen. */
@Composable
private fun SeekSection(
    positionMs: LongState,
    durationMs: Long,
    playing: Boolean,
    onSeek: (Float) -> Unit,
) {
    var width by remember { mutableIntStateOf(0) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val seek by rememberUpdatedState(onSeek)
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .onSizeChanged { width = it.width }
            .pointerInput(Unit) {
                awaitEachGesture {
                    fun frac(x: Float) = if (width > 0) (x / width).coerceIn(0f, 1f) else 0f
                    val down = awaitFirstDown()
                    drag = frac(down.position.x)
                    down.consume()
                    do {
                        val event = awaitPointerEvent()
                        val c = event.changes.firstOrNull() ?: break
                        if (c.pressed) {
                            drag = frac(c.position.x)
                            c.consume()
                        }
                    } while (event.changes.any { it.pressed })
                    drag?.let { seek(it) }
                    drag = null
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        WavyProgress(
            progress = {
                drag ?: if (durationMs > 0) (positionMs.longValue.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
            },
            playing = playing,
            dragging = drag != null,
            color = cs.primary,
            trackColor = cs.primary.copy(alpha = 0.25f),
            modifier = Modifier.fillMaxWidth(),
        )
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        TimeText(ms = { drag?.let { (it * durationMs).toLong() } ?: positionMs.longValue })
        Text(
            formatTime(durationMs),
            style = MaterialTheme.typography.labelLarge,
            color = cs.onSurfaceVariant,
        )
    }
}

/** Selbst gezeichneter Wellen-Zeitstrahl mit Griff. Alles Animierte wird erst beim Zeichnen gelesen. */
@Composable
private fun WavyProgress(
    progress: () -> Float,
    playing: Boolean,
    dragging: Boolean,
    color: Color,
    trackColor: Color,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart),
        label = "phase",
    )
    val amp by animateFloatAsState(
        if (playing && !dragging) 1f else 0f,
        spring(dampingRatio = 0.6f, stiffness = 200f),
        label = "amp",
    )
    val handleH by animateFloatAsState(
        if (dragging) 40f else 30f,
        spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "handle",
    )
    Canvas(modifier.height(44.dp)) {
        val w = size.width
        val cy = size.height / 2
        val stroke = 4.dp.toPx()
        val ampPx = 3.5.dp.toPx() * amp
        val wave = 34.dp.toPx()
        val hw = 5.dp.toPx()
        val hh = handleH.dp.toPx()
        val gap = 6.dp.toPx()
        val x = (w * progress().coerceIn(0f, 1f)).coerceIn(hw, w - hw)

        if (x + gap < w) {
            drawLine(trackColor, Offset(x + gap, cy), Offset(w, cy), stroke, StrokeCap.Round)
        }
        val end = x - gap
        if (end > 0f) {
            val path = Path()
            val step = 2.dp.toPx()
            val fadeLen = 16.dp.toPx()
            var px = 0f
            path.moveTo(0f, cy)
            while (px < end) {
                val fade = (px / fadeLen).coerceIn(0f, 1f)
                path.lineTo(px, cy + ampPx * fade * sin(px / wave * 2f * PI.toFloat() - phase))
                px += step
            }
            path.lineTo(end, cy + ampPx * sin(end / wave * 2f * PI.toFloat() - phase))
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        drawRoundRect(
            color,
            topLeft = Offset(x - hw / 2, cy - hh / 2),
            size = Size(hw, hh),
            cornerRadius = CornerRadius(hw / 2, hw / 2),
        )
    }
}

@Composable
private fun LyricsContent(
    lyrics: LyricsUi,
    positionMs: LongState,
    onSeekMs: (Long) -> Unit,
    translations: Map<String, String>,
) {
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier.fillMaxWidth().fillMaxHeight(0.75f),
        contentAlignment = Alignment.Center,
    ) {
        when {
            lyrics.loading -> CircularProgressIndicator()

            lyrics.lines.isNotEmpty() -> {
                val listState = rememberLazyListState()
                val idx by remember(lyrics.lines) {
                    derivedStateOf {
                        val p = positionMs.longValue + 200
                        lyrics.lines.indexOfLast { it.timeMs <= p }
                    }
                }
                // Weiches Mitscrollen: die aktive Zeile gleitet auf ein Drittel der Höhe
                LaunchedEffect(idx) {
                    if (idx < 0) return@LaunchedEffect
                    val info = listState.layoutInfo
                    val target = info.viewportSize.height * 0.30f
                    val item = info.visibleItemsInfo.firstOrNull { it.index == idx }
                    if (item == null) {
                        listState.scrollToItem(idx)
                    } else {
                        listState.animateScrollBy(
                            item.offset - target,
                            spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessVeryLow),
                        )
                    }
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    itemsIndexed(lyrics.lines) { i, line ->
                        val active = i == idx
                        val a by animateFloatAsState(
                            if (active) 1f else 0.4f,
                            spring(stiffness = Spring.StiffnessLow),
                            label = "lyricAlpha",
                        )
                        val sc by animateFloatAsState(
                            if (active) 1f else 0.9f,
                            spring(stiffness = Spring.StiffnessLow),
                            label = "lyricScale",
                        )
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .graphicsLayer {
                                    alpha = a
                                    scaleX = sc
                                    scaleY = sc
                                    transformOrigin = TransformOrigin(0f, 0.5f)
                                }
                                .clickable { onSeekMs(line.timeMs) },
                        ) {
                            Text(
                                line.text.ifBlank { "♪" },
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = cs.onSurface,
                            )
                            translations[line.text.trim()]?.let { tr ->
                                Text(
                                    tr,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = cs.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 4.dp),
                                )
                            }
                        }
                    }
                }
            }

            lyrics.plain != null -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            ) {
                lyrics.plain.lines().forEach { l ->
                    if (l.isBlank()) {
                        Spacer(Modifier.height(14.dp))
                    } else {
                        Text(
                            l,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Medium,
                            color = cs.onSurface,
                        )
                        translations[l.trim()]?.let { tr ->
                            Text(tr, style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }

            lyrics.instrumental -> LyricsMessage("Instrumental – kein Text vorhanden")
            lyrics.error -> LyricsMessage("Keine Internetverbindung. Der Songtext wird im Hintergrund erneut geladen.")
            else -> LyricsMessage("Kein Songtext gefunden")
        }
    }
}

@Composable
private fun LyricsMessage(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(32.dp),
    )
}

@Composable
private fun LyricsHeader(
    tr: TranslationUi,
    showTr: Boolean,
    onTranslate: () -> Unit,
    onToggle: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Songtext",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            when (tr.status) {
                TranslationStatus.Loading -> CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                TranslationStatus.Done -> FilterChip(selected = showTr, onClick = onToggle, label = { Text("Übersetzung") })
                TranslationStatus.Same -> {}
                else -> FilledTonalButton(onClick = onTranslate) { Text("Übersetzen") }
            }
        }
        tr.message?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = if (tr.status == TranslationStatus.Error) cs.error else cs.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
