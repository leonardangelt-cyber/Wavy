package app.wavy.player.ui

import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.rounded.Bedtime
import kotlin.math.roundToInt
import androidx.compose.ui.zIndex
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.key
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.LongState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.positionInRoot
import androidx.media3.common.Player
import app.wavy.player.PlayerUi
import app.wavy.player.data.LyricsUi
import app.wavy.player.data.Song
import app.wavy.player.data.TranslationStatus
import app.wavy.player.data.TranslationUi
import kotlin.math.abs
import kotlin.math.PI
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    song: Song,
    prevSong: Song?,
    nextSong: Song?,
    state: PlayerUi,
    positionMs: LongState,
    lyrics: LyricsUi,
    translation: TranslationUi,
    onTranslate: () -> Unit,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onPrevTrack: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onSeekFraction: (Float) -> Unit,
    onSeekStart: () -> Unit,
    onSeekEnd: () -> Unit,
    onSeekMs: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    contentAlpha: () -> Float = { 1f },
    hideCover: () -> Boolean = { false },
    onCoverBounds: (androidx.compose.ui.geometry.Rect) -> Unit = {},
    songsById: Map<Long, Song> = emptyMap(),
    onPull: (Float) -> Float = { 0f },
    onPullEnd: (Float) -> Unit = {},
    onPeek: (Song?) -> Unit = {},
    onPlayQueueItem: (Long) -> Unit = {},
    onMoveQueue: (Long, Long) -> Unit = { _, _ -> },
    onRemoveQueue: (Long) -> Unit = {},
    sleepLeftMin: Int = 0,
    onSleep: (Int) -> Unit = {},
    karaoke: Boolean = true,
    onSaveLyrics: (String) -> Unit = {},
    onDeleteLyrics: () -> Unit = {},
    onSaveQueue: (String) -> Unit = {},
    lyricsSize: Int = 1,
) {
    var showWeb by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val duration = if (state.durationMs > 0) state.durationMs else song.durationMs

    val corner by animateDpAsState(
        if (state.isPlaying) 12.dp else 8.dp,
        spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "coverCorner",
    )
    // Pausiert: das Cover rückt ein Stück nach hinten, beim Abspielen wird es wieder groß
    val scale by animateFloatAsState(
        if (state.isPlaying) 1f else 0.84f,
        spring(dampingRatio = 0.7f, stiffness = 260f),
        label = "coverScale",
    )
    val playCorner by animateDpAsState(
        if (state.isPlaying) 28.dp else 42.dp,
        spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "playCorner",
    )

    // Warteschlange: q (0..1) folgt direkt dem Finger. Nach oben wischen = Cover wandert nach oben und
    // wird zum Kopf der Warteschlange, nach unten wischen = alles läuft rückwärts.
    var queueMode by rememberSaveable { mutableStateOf(false) }
    var q by remember { mutableFloatStateOf(if (queueMode) 1f else 0f) }
    var qDrag by remember { mutableStateOf(false) }
    var rootW by remember { mutableIntStateOf(1) }
    var rootH by remember { mutableIntStateOf(1) }
    var rootOrigin by remember { mutableStateOf(Offset.Zero) }
    var coverRect by remember { mutableStateOf(androidx.compose.ui.geometry.Rect.Zero) }
    val qScope = rememberCoroutineScope()
    val qJob = remember { arrayOfNulls<kotlinx.coroutines.Job>(1) }
    val lastQDrag = remember { longArrayOf(0L) }
    val travelNow by rememberUpdatedState(rootH * 0.5f)
    val settleQ: (Float, Float) -> Unit = remember {
        { target, vy ->
            qDrag = false
            queueMode = target >= 1f
            qJob[0]?.cancel()
            qJob[0] = qScope.launch {
                animate(
                    q, target,
                    initialVelocity = -vy / travelNow,
                    animationSpec = spring(dampingRatio = 0.9f, stiffness = 300f),
                ) { v, _ -> q = v }
            }
        }
    }
    val endQ: (Float) -> Unit = remember {
        { vy ->
            settleQ(
                when {
                    vy < -900f -> 1f
                    vy > 900f -> 0f
                    q > 0.5f -> 1f
                    else -> 0f
                },
                vy,
            )
        }
    }
    val dragQ: (Float) -> Float = remember {
        { dy ->
            qJob[0]?.cancel()
            qDrag = true
            lastQDrag[0] = System.nanoTime() / 1_000_000L
            val nq = (q - dy / travelNow).coerceIn(0f, 1f)
            val used = -(nq - q) * travelNow
            q = nq
            used
        }
    }
    val qDragState = rememberDraggableState { dy -> dragQ(dy) }
    // Sicherheitsnetz: bricht eine Geste ohne Ende ab, wird der Zustand nach kurzer Zeit sauber abgeschlossen
    LaunchedEffect(qDrag) {
        if (qDrag) {
            while (true) {
                delay(300)
                if (System.nanoTime() / 1_000_000L - lastQDrag[0] > 700L) {
                    endQ(0f)
                    break
                }
            }
        }
    }
    val showNormal by remember { derivedStateOf { q < 0.999f || qDrag } }
    // Die Warteschlange wird kurz nach dem Öffnen schon unsichtbar vorbereitet, damit das Hochwischen nicht stockt
    var warm by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(700)
        warm = true
    }
    val showQueue by remember { derivedStateOf { warm || q > 0.45f || qDrag } }

    // Nach unten ziehen (Warteschlange zu, dann Player zusammenziehen) – App steuert das Schließen
    val pull by rememberUpdatedState(onPull)
    val pullEnd by rememberUpdatedState(onPullEnd)
    val dismissConn = remember {
        object : NestedScrollConnection {
            var pulling = false

            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.Fling || source == NestedScrollSource.SideEffect) return Offset.Zero
                if (qDrag && available.y != 0f) return Offset(0f, dragQ(available.y))
                if (pulling && available.y < 0f) return Offset(0f, pull(available.y))
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                // Nur echte Fingerbewegungen zählen (nicht das Auslaufen eines Wischens)
                if (source == NestedScrollSource.Fling || source == NestedScrollSource.SideEffect) return Offset.Zero
                val y = available.y
                if (y == 0f) return Offset.Zero
                if (qDrag) return Offset(0f, dragQ(y))
                if (y < 0f && q < 1f && !pulling) return Offset(0f, dragQ(y))
                if (y > 0f && q > 0f) return Offset(0f, dragQ(y))
                if (y > 0f && q <= 0f) {
                    pulling = true
                    return Offset(0f, pull(y))
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (qDrag) {
                    endQ(available.y)
                    return available
                }
                if (pulling) {
                    pulling = false
                    pullEnd(available.y)
                    return available
                }
                return Velocity.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (pulling) {
                    pulling = false
                    pullEnd(0f)
                }
                if (qDrag) endQ(0f)
                return Velocity.Zero
            }
        }
    }
    androidx.activity.compose.BackHandler(enabled = queueMode) { settleQ(0f, 0f) }

    // Wischen auf Cover/Titel: links = nächster Song, rechts = vorheriger Song
    var swipePx by remember { mutableFloatStateOf(0f) }
    var swipeW by remember { mutableIntStateOf(1) }
    val swipeState = rememberDraggableState { d -> swipePx += d }
    val density = LocalDensity.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    // Wechselt der Song, springt das Karussell nahtlos in die Mitte (der neue Song steht schon an der richtigen Stelle)
    var lastId by remember { mutableLongStateOf(song.id) }
    if (song.id != lastId) {
        lastId = song.id
        swipePx = 0f
    }

    // Weiter/Zurück per Knopf: dieselbe Gleit-Animation wie beim Wischen (ohne Kippen)
    val btnScope = rememberCoroutineScope()
    val slideTo: (Int) -> Unit = { go ->
        val ok = (go < 0 && nextSong != null) || (go > 0 && prevSong != null)
        if (!ok || swipePx != 0f) {
            if (go < 0) onNext() else onPrevTrack()
        } else {
            btnScope.launch {
                val pitch = swipeW + with(density) { 24.dp.toPx() }
                animate(0f, go * pitch, animationSpec = spring(dampingRatio = 0.9f, stiffness = 450f)) { x, _ -> swipePx = x }
                if (go < 0) onNext() else onPrevTrack()
                delay(700)
                if (swipePx != 0f) {
                    animate(swipePx, 0f, animationSpec = spring(dampingRatio = 0.8f, stiffness = 380f)) { x, _ -> swipePx = x }
                }
            }
        }
    }

    // Akzentfarbe folgt schon dem Song, auf den man gerade wischt
    val peekSong = when {
        swipePx < -swipeW * 0.3f -> nextSong
        swipePx > swipeW * 0.3f -> prevSong
        else -> null
    }
    LaunchedEffect(peekSong?.id) { onPeek(peekSong) }
    DisposableEffect(Unit) { onDispose { onPeek(null) } }

    // Komplett deckender Hintergrund (nichts schimmert durch), Touches werden hier abgefangen.
    Box(
        Modifier
            .fillMaxSize()
            .background(cs.surface)
            .background(
                Brush.verticalGradient(
                    0f to cs.primaryContainer,
                    0.65f to cs.surface,
                    1f to cs.surface,
                ),
            )
            .onSizeChanged { rootW = it.width.coerceAtLeast(1); rootH = it.height.coerceAtLeast(1) }
            .onGloballyPositioned { rootOrigin = it.positionInRoot() }
            .pointerInput(Unit) { detectTapGestures { } }
            .nestedScroll(dismissConn),
    ) {
        if (showNormal) Column(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val t = (q / 0.55f).coerceIn(0f, 1f)
                    alpha = contentAlpha() * (1f - t * t * (3f - 2f * t))
                    compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.ModulateAlpha
                }
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalIconButton(onClick = onClose, modifier = Modifier.size(52.dp), shape = CircleShape) {
                    Icon(Icons.Rounded.KeyboardArrowDown, "Schließen", Modifier.size(30.dp))
                }
                Text(
                    "Aktuelle Wiedergabe",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f).padding(start = 20.dp),
                )
                if (sleepLeftMin > 0) {
                    Text("$sleepLeftMin min", style = MaterialTheme.typography.labelLarge, color = cs.primary, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { showSleep = true }) {
                    Icon(Icons.Rounded.Bedtime, "Schlaftimer", tint = if (sleepLeftMin > 0) cs.primary else cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(16.dp))

            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val coverSize = if (maxWidth < 600.dp) maxWidth else 600.dp
                Box(
                    Modifier
                        .fillMaxWidth()
                        .onSizeChanged { swipeW = it.width }
                        .draggable(
                            state = swipeState,
                            orientation = Orientation.Horizontal,
                            onDragStopped = { v ->
                                val pitch = swipeW + with(density) { 24.dp.toPx() }
                                val go = when {
                                    swipePx < -pitch * 0.22f || v < -900f -> -1
                                    swipePx > pitch * 0.22f || v > 900f -> 1
                                    else -> 0
                                }
                                val ok = (go < 0 && nextSong != null) || (go > 0 && prevSong != null)
                                if (!ok) {
                                    animate(swipePx, 0f, animationSpec = spring(dampingRatio = 0.75f, stiffness = 380f)) { x, _ -> swipePx = x }
                                } else {
                                    haptic.tick()
                                    animate(
                                        swipePx,
                                        go * pitch,
                                        initialVelocity = v,
                                        animationSpec = spring(dampingRatio = 0.9f, stiffness = 450f),
                                    ) { x, _ -> swipePx = x }
                                    if (go < 0) onNext() else onPrevTrack()
                                    // Falls der Titel gleich bleibt (z. B. Einzelwiederholung): zurückfedern
                                    delay(700)
                                    if (swipePx != 0f) {
                                        animate(swipePx, 0f, animationSpec = spring(dampingRatio = 0.8f, stiffness = 380f)) { x, _ -> swipePx = x }
                                    }
                                }
                            },
                        ),
                ) {
                    // Vorheriges Cover: direkt links neben dem aktuellen
                    if (prevSong != null) {
                        Box(
                            Modifier.matchParentSize().graphicsLayer {
                                translationX = swipePx - (swipeW + 24.dp.toPx())
                                alpha = if (swipePx == 0f) 0f else 1f
                            },
                        ) { TrackSlot(prevSong, coverSize, scale, corner) }
                    }
                    // Nächstes Cover: direkt rechts daneben, schiebt sich beim Wischen herein
                    if (nextSong != null) {
                        Box(
                            Modifier.matchParentSize().graphicsLayer {
                                translationX = swipePx + (swipeW + 24.dp.toPx())
                                alpha = if (swipePx == 0f) 0f else 1f
                            },
                        ) { TrackSlot(nextSong, coverSize, scale, corner) }
                    }
                    Box(
                        Modifier
                            .graphicsLayer {
                                translationX = swipePx
                            }
                            .pointerInput(duration) {
                                detectTapGestures(onDoubleTap = { o ->
                                    val back = o.x < size.width / 2f
                                    val to = (positionMs.longValue + if (back) -10_000L else 10_000L).coerceIn(0L, duration.coerceAtLeast(1L))
                                    onSeekMs(to)
                                    haptic.tick()
                                })
                            },
                    ) {
                        TrackSlot(
                            song, coverSize, scale, corner,
                            { hideCover() || q > 0.001f },
                            { r -> coverRect = r; onCoverBounds(r) },
                        )
                    }
                    FilledTonalIconButton(
                        onClick = { showLyrics = !showLyrics },
                        modifier = Modifier.align(Alignment.BottomEnd).size(56.dp),
                        shape = CircleShape,
                        colors = if (showLyrics) IconButtonDefaults.filledIconButtonColors(containerColor = cs.primary, contentColor = cs.onPrimary)
                        else IconButtonDefaults.filledTonalIconButtonColors(),
                    ) { Icon(Icons.Rounded.Lyrics, "Songtext") }
                }
            }
            Spacer(Modifier.height(12.dp))

            Column(Modifier.fillMaxWidth()) {
                SeekSection(
                    positionMs = positionMs,
                    durationMs = duration,
                    playing = state.isPlaying,
                    onSeek = onSeekFraction,
                    onSeekStart = onSeekStart,
                    onSeekEnd = onSeekEnd,
                )
            }
            Spacer(Modifier.height(12.dp))

            var act by remember { mutableIntStateOf(-1) }
            val setAct: (Int, Boolean) -> Unit = { i, on ->
                if (on) act = i else if (act == i) act = -1
            }
            // Der gedrückte Knopf wird richtig groß, die anderen machen Platz
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TransportButton(0, act, setAct, 1f, { if (positionMs.longValue > 3000L) onPrev() else slideTo(1) }, CircleShape, cs.primaryContainer, cs.onPrimaryContainer) {
                    Icon(Icons.Rounded.SkipPrevious, "Zurück", Modifier.size(36.dp))
                }
                TransportButton(1, act, setAct, 1.2f, onToggle, RoundedCornerShape(playCorner), cs.primary, cs.onPrimary) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (state.isPlaying) "Pause" else "Abspielen",
                        Modifier.size(44.dp),
                    )
                }
                TransportButton(2, act, setAct, 1f, { slideTo(-1) }, CircleShape, cs.primaryContainer, cs.onPrimaryContainer) {
                    Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(36.dp))
                }
            }
            Spacer(Modifier.height(14.dp))

            // Shuffle, Wiederholen, Songtext in einer Pille
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(36.dp),
                color = cs.surfaceContainerHigh,
                contentColor = cs.onSurface,
            ) {
                // Überall gleicher Abstand (8 dp) zum Rand und zwischen den Segmenten; Segmente sind konzentrische Kapseln
                Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillAction(state.shuffle, Icons.Rounded.Shuffle, "Shuffle", "Shuffle", onShuffle)
                    PillAction(
                        state.repeat != Player.REPEAT_MODE_OFF,
                        if (state.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        when (state.repeat) {
                            Player.REPEAT_MODE_ONE -> "Einmal wiederholen"
                            Player.REPEAT_MODE_ALL -> "Alles wiederholen"
                            else -> "Wiederholung aus"
                        },
                        when (state.repeat) {
                            Player.REPEAT_MODE_ONE -> "Eins"
                            Player.REPEAT_MODE_ALL -> "Alle"
                            else -> "Aus"
                        },
                        onRepeat,
                    )
                    PillAction(false, Icons.AutoMirrored.Rounded.PlaylistAdd, "Zu Playlist hinzufügen", "Playlist", onAddToPlaylist)
                }
            }
            // Griff: nach oben wischen (mit dem Finger) oder tippen zeigt die Warteschlange
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .clickable { settleQ(1f, 0f) }
                    .draggable(
                        state = qDragState,
                        orientation = Orientation.Vertical,
                        onDragStarted = { qDrag = true },
                        onDragStopped = { v -> endQ(v) },
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.size(width = 44.dp, height = 5.dp).clip(CircleShape).background(cs.onSurfaceVariant.copy(alpha = 0.5f)))
            }
            Spacer(Modifier.height(12.dp))
        }
        // Das eine Cover, das vom normalen Platz nach oben in den Kopf der Warteschlange wandert
        Box(
            Modifier
                .fillMaxSize()
                .layout { m, c ->
                    val qq = q
                    val rc = coverRect
                    val sc = scale
                    val nw = rc.width * sc
                    val nh = rc.height * sc
                    val cx = rc.center.x - rootOrigin.x
                    val cy = rc.center.y - rootOrigin.y
                    val bw = c.maxWidth.toFloat()
                    val w = lerpF(nw, bw, qq)
                    val h = lerpF(nh, bw * 0.9f, qq)
                    val x = lerpF(cx - nw / 2f, 0f, qq)
                    val y = lerpF(cy - nh / 2f, 0f, qq)
                    val p = m.measure(androidx.compose.ui.unit.Constraints.fixed(w.roundToInt().coerceAtLeast(0), h.roundToInt().coerceAtLeast(0)))
                    layout(c.maxWidth, c.maxHeight) { p.place(x.roundToInt(), y.roundToInt()) }
                },
        ) {
            Cover(
                song, app.wavy.player.data.Perf.bigCoverPx,
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val qq = q
                        alpha = if (qq > 0.001f && !hideCover()) 1f else 0f
                        compositingStrategy = if (qq > 0.001f) androidx.compose.ui.graphics.CompositingStrategy.Offscreen
                        else androidx.compose.ui.graphics.CompositingStrategy.Auto
                        shape = RoundedCornerShape(lerpF(corner.toPx(), 0f, qq))
                        clip = true
                    }
                    .drawWithContent {
                        drawContent()
                        val qq = q
                        if (qq > 0.001f) {
                            val stops = Array(17) { i ->
                                val t = i / 16f
                                fun sm(e0: Float, e1: Float, x: Float): Float {
                                    val u = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
                                    return u * u * (3f - 2f * u)
                                }
                                val a = sm(0f, 0.42f, t) * (1f - sm(0.50f, 1f, t))
                                t to Color.Black.copy(alpha = 1f - qq * (1f - a))
                            }
                            drawRect(Brush.verticalGradient(colorStops = stops), blendMode = androidx.compose.ui.graphics.BlendMode.DstIn)
                        }
                    },
                androidx.compose.ui.graphics.RectangleShape,
            )
        }
        if (showQueue) {
            QueueView(
                song = song,
                state = state,
                songsById = songsById,
                qv = { q },
                positionMs = positionMs,
                durationMs = duration,
                onSeekFraction = onSeekFraction,
                onSeekStart = onSeekStart,
                onSeekEnd = onSeekEnd,
                onBack = { settleQ(0f, 0f) },
                onToggle = onToggle,
                onNext = onNext,
                onPrev = onPrev,
                onPlay = onPlayQueueItem,
                onMove = onMoveQueue,
                onRemove = onRemoveQueue,
                onAddToPlaylist = onAddToPlaylist,
                onSaveQueue = onSaveQueue,
                dragState = qDragState,
                onDragStartQ = { qDrag = true },
                onEndQ = endQ,
            )
        }
    }

    if (showSleep) {
        SleepSheet(current = sleepLeftMin, onSet = onSleep, onDismiss = { showSleep = false })
    }

    if (showWeb) {
        LyricsWebDialog(
            title = song.title,
            artist = song.artist,
            onUse = { t -> onSaveLyrics(t); showWeb = false },
            onDismiss = { showWeb = false },
        )
    }

    if (showLyrics) {
        ModalBottomSheet(
            onDismissRequest = { showLyrics = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = cs.surfaceContainerHigh,
            contentColor = cs.onSurface,
        ) {
            var showTr by rememberSaveable { mutableStateOf(true) }
            LyricsHeader(
                translation, showTr, onTranslate,
                canDelete = lyrics.custom,
                onDelete = { onDeleteLyrics() },
                onToggle = { showTr = !showTr },
            )
            LyricsContent(
                lyrics,
                positionMs,
                onSeekMs,
                if (showTr && translation.status == TranslationStatus.Done) translation.map else emptyMap(),
                karaoke,
                onSearchWeb = { showWeb = true },
                textSize = lyricsSize,
            )
        }
    }
}

/** Cover + Titel eines Songs (ein "Slot" im Wisch-Karussell). */
@Composable
private fun TrackSlot(
    song: Song,
    size: Dp,
    scale: Float,
    corner: Dp,
    hideCover: (() -> Boolean)? = null,
    onCoverBounds: ((androidx.compose.ui.geometry.Rect) -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        CoverFramed(
            song = song,
            px = app.wavy.player.data.Perf.bigCoverPx,
            modifier = Modifier
                .size(size)
                .then(
                    if (onCoverBounds != null) Modifier.onGloballyPositioned { onCoverBounds(it.boundsInRoot()) } else Modifier,
                )
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    alpha = if (hideCover?.invoke() == true) 0f else 1f
                },
            shape = RoundedCornerShape(corner),
        )
        Spacer(Modifier.height(24.dp))
        Column(Modifier.fillMaxWidth().padding(end = 68.dp)) {
            Text(
                song.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier.marq(),
            )
            Text(
                song.artistLabel,
                style = MaterialTheme.typography.titleMedium,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier.marq(),
            )
        }
    }
}

/** Play/Zurück/Weiter: beim Drücken (und bei jedem Tippen) wächst der Knopf stark, die anderen weichen aus. */
@Composable
private fun RowScope.TransportButton(
    index: Int,
    active: Int,
    onActive: (Int, Boolean) -> Unit,
    baseWeight: Float,
    onClick: () -> Unit,
    shape: Shape,
    container: Color,
    content: Color,
    icon: @Composable () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    var bump by remember { mutableStateOf(false) }
    LaunchedEffect(bump) {
        if (bump) {
            delay(220)
            bump = false
        }
    }
    val on = pressed || bump
    LaunchedEffect(on) { onActive(index, on) }
    val target = when {
        active == index -> baseWeight * 1.9f
        active >= 0 -> baseWeight * 0.7f
        else -> baseWeight
    }
    val w by animateFloatAsState(target, spring(dampingRatio = 0.55f, stiffness = 380f), label = "transportWeight")
    FilledIconButton(
        onClick = {
            bump = true
            onClick()
        },
        modifier = Modifier.weight(w.coerceAtLeast(0.1f)).height(92.dp),
        shape = shape,
        colors = IconButtonDefaults.filledIconButtonColors(containerColor = container, contentColor = content),
        interactionSource = src,
    ) { icon() }
}

/** Ein Segment der Aktions-Pille: aktiv = volle Kapsel in Akzentfarbe, inaktiv = weicher Block. */
@Composable
private fun RowScope.PillAction(
    checked: Boolean,
    icon: ImageVector,
    desc: String,
    label: String,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val bg by animateColorAsState(if (checked) cs.primary else cs.surfaceContainerHighest, tween(220), label = "pillBg")
    val fg by animateColorAsState(if (checked) cs.onPrimary else cs.onSurface, label = "pillFg")
    Row(
        Modifier
            .weight(1f)
            .height(56.dp)
            .pressScale(src, 1.05f)
            .clip(RoundedCornerShape(28.dp))
            .background(bg)
            .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, desc, tint = fg, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun TimeText(ms: () -> Long, style: TextStyle = MaterialTheme.typography.labelLarge) {
    val current by rememberUpdatedState(ms)
    val sec by remember { derivedStateOf { current() / 1000 } }
    Text(formatTime(sec * 1000), style = style, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Zeitstrahl mit Welle, Punkt (Griff) und Zeiten. Antippen oder Ziehen zum Spulen. */
@Composable
private fun SeekSection(
    positionMs: LongState,
    durationMs: Long,
    playing: Boolean,
    onSeek: (Float) -> Unit,
    onSeekStart: () -> Unit,
    onSeekEnd: () -> Unit,
) {
    val startSeek by rememberUpdatedState(onSeekStart)
    val endSeek by rememberUpdatedState(onSeekEnd)
    var width by remember { mutableIntStateOf(0) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val seek by rememberUpdatedState(onSeek)
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .onSizeChanged { width = it.width }
            .pointerInput(Unit) {
                awaitEachGesture {
                    fun frac(x: Float) = if (width > 0) (x / width).coerceIn(0f, 1f) else 0f
                    val down = awaitFirstDown()
                    startSeek()
                    drag = frac(down.position.x)
                    down.consume()
                    do {
                        val event = awaitPointerEvent()
                        val c = event.changes.firstOrNull() ?: break
                        if (c.pressed) {
                            drag = frac(c.position.x)
                            c.consume()
                        }
                    } while (event.changes.any { it.pressed })
                    drag?.let { seek(it) }
                    drag = null
                    endSeek()
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        PillProgress(
            progress = {
                drag ?: if (durationMs > 0) (positionMs.longValue.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
            },
            playing = playing,
            dragging = drag != null,
            color = cs.primary,
            trackColor = cs.primary.copy(alpha = 0.25f),
            trackHeight = 8.dp,
            handleHeight = 14.dp,
            playWidth = 36.dp,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        )
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        TimeText(ms = { drag?.let { (it * durationMs).toLong() } ?: positionMs.longValue })
        Text(
            formatTime(durationMs),
            style = MaterialTheme.typography.labelLarge,
            color = cs.onSurfaceVariant,
        )
    }
}

/** Selbst gezeichneter Wellen-Zeitstrahl mit Griff. Alles Animierte wird erst beim Zeichnen gelesen. */
@Composable
private fun WavyProgress(
    progress: () -> Float,
    playing: Boolean,
    dragging: Boolean,
    color: Color,
    trackColor: Color,
    modifier: Modifier = Modifier,
) {
    // Die Welle bewegt sich nur beim Abspielen (kein Dauerlauf im Leerlauf)
    val phaseAnim = remember { Animatable(0f) }
    LaunchedEffect(playing) {
        if (playing) {
            while (true) {
                phaseAnim.snapTo(0f)
                phaseAnim.animateTo((2 * PI).toFloat(), tween(1800, easing = LinearEasing))
            }
        }
    }
    val path = remember { Path() }
    val amp by animateFloatAsState(
        if (playing && !dragging) 1f else 0f,
        spring(dampingRatio = 0.6f, stiffness = 200f),
        label = "amp",
    )
    val handleH by animateFloatAsState(
        if (dragging) 40f else 30f,
        spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "handle",
    )
    Canvas(modifier.height(44.dp)) {
        val w = size.width
        val cy = size.height / 2
        val stroke = 4.dp.toPx()
        val ampPx = 3.5.dp.toPx() * amp
        val wave = 34.dp.toPx()
        val hw = 5.dp.toPx()
        val hh = handleH.dp.toPx()
        val gap = 6.dp.toPx()
        val x = (w * progress().coerceIn(0f, 1f)).coerceIn(hw, w - hw)

        if (x + gap < w) {
            drawLine(trackColor, Offset(x + gap, cy), Offset(w, cy), stroke, StrokeCap.Round)
        }
        val phase = phaseAnim.value
        val end = x - gap
        if (end > 0f) {
            path.rewind()
            val step = 3.dp.toPx()
            val fadeLen = 16.dp.toPx()
            var px = 0f
            path.moveTo(0f, cy)
            while (px < end) {
                val fade = (px / fadeLen).coerceIn(0f, 1f)
                path.lineTo(px, cy + ampPx * fade * sin(px / wave * 2f * PI.toFloat() - phase))
                px += step
            }
            path.lineTo(end, cy + ampPx * sin(end / wave * 2f * PI.toFloat() - phase))
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        drawRoundRect(
            color,
            topLeft = Offset(x - hw / 2, cy - hh / 2),
            size = Size(hw, hh),
            cornerRadius = CornerRadius(hw / 2, hw / 2),
        )
    }
}

@Composable
private fun LyricsContent(
    lyrics: LyricsUi,
    positionMs: LongState,
    onSeekMs: (Long) -> Unit,
    translations: Map<String, String>,
    karaoke: Boolean = true,
    onSearchWeb: () -> Unit = {},
    textSize: Int = 1,
) {
    val cs = MaterialTheme.colorScheme
    val lineStyle = MaterialTheme.typography.headlineSmall.let {
        when (textSize) {
            0 -> it.copy(fontSize = 20.sp, lineHeight = 28.sp)
            2 -> it.copy(fontSize = 32.sp, lineHeight = 40.sp)
            else -> it
        }
    }

    Box(
        Modifier.fillMaxWidth().fillMaxHeight(0.75f),
        contentAlignment = Alignment.Center,
    ) {
        when {
            lyrics.loading -> CircularProgressIndicator()

            lyrics.lines.isNotEmpty() -> {
                val listState = rememberLazyListState()
                val idx by remember(lyrics.lines) {
                    derivedStateOf {
                        val p = positionMs.longValue + 200
                        lyrics.lines.indexOfLast { it.timeMs <= p }
                    }
                }
                // Weiches Mitscrollen: die aktive Zeile gleitet auf ein Drittel der Höhe
                LaunchedEffect(idx) {
                    if (idx < 0) return@LaunchedEffect
                    val info = listState.layoutInfo
                    val target = info.viewportSize.height * 0.30f
                    val item = info.visibleItemsInfo.firstOrNull { it.index == idx }
                    if (item == null) {
                        listState.scrollToItem(idx)
                    } else {
                        listState.animateScrollBy(
                            item.offset - target,
                            spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessVeryLow),
                        )
                    }
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    itemsIndexed(lyrics.lines) { i, line ->
                        val active = i == idx
                        val a by animateFloatAsState(
                            if (active) 1f else 0.4f,
                            spring(stiffness = Spring.StiffnessLow),
                            label = "lyricAlpha",
                        )
                        val sc by animateFloatAsState(
                            if (active) 1f else 0.9f,
                            spring(stiffness = Spring.StiffnessLow),
                            label = "lyricScale",
                        )
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .graphicsLayer {
                                    alpha = a
                                    scaleX = sc
                                    scaleY = sc
                                    transformOrigin = TransformOrigin(0f, 0.5f)
                                }
                                .clickable { onSeekMs(line.timeMs) },
                        ) {
                            if (active && karaoke && line.text.isNotBlank()) {
                                KaraokeLine(
                                    text = line.text,
                                    startMs = line.timeMs,
                                    endMs = lyrics.lines.getOrNull(i + 1)?.timeMs,
                                    wordStarts = lyrics.words?.starts?.getOrNull(i),
                                    lineEnd = lyrics.words?.ends?.getOrNull(i),
                                    positionMs = positionMs,
                                    lit = cs.primary,
                                    dim = cs.onSurface.copy(alpha = 0.5f),
                                    style = lineStyle,
                                )
                            } else {
                                Text(
                                    line.text.ifBlank { "♪" },
                                    style = lineStyle,
                                    fontWeight = FontWeight.Bold,
                                    color = cs.onSurface,
                                )
                            }
                            translations[line.text.trim()]?.let { tr ->
                                Text(
                                    tr,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = cs.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 4.dp),
                                )
                            }
                        }
                    }
                }
            }

            lyrics.plain != null -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            ) {
                lyrics.plain.lines().forEach { l ->
                    if (l.isBlank()) {
                        Spacer(Modifier.height(14.dp))
                    } else {
                        Text(
                            l,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Medium,
                            color = cs.onSurface,
                        )
                        translations[l.trim()]?.let { tr ->
                            Text(tr, style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }

            lyrics.instrumental -> LyricsMessage("Instrumental – kein Text vorhanden")
            lyrics.error -> LyricsMessage("Keine Internetverbindung. Der Songtext wird im Hintergrund erneut geladen.")
            else -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                LyricsMessage("Kein Songtext gefunden")
                FilledTonalButton(onClick = onSearchWeb) { Text("Im Web suchen") }
            }
        }
    }
}

@Composable
private fun LyricsMessage(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(32.dp),
    )
}

@Composable
private fun LyricsHeader(
    tr: TranslationUi,
    showTr: Boolean,
    onTranslate: () -> Unit,
    canDelete: Boolean,
    onDelete: () -> Unit,
    onToggle: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Songtext",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            if (canDelete) {
                IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "Eigenen Songtext löschen") }
            }
            when (tr.status) {
                TranslationStatus.Loading -> CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                TranslationStatus.Done -> FilterChip(selected = showTr, onClick = onToggle, label = { Text("Übersetzung") })
                TranslationStatus.Same -> {}
                else -> FilledTonalButton(onClick = onTranslate) { Text("Übersetzen") }
            }
        }
        tr.message?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = if (tr.status == TranslationStatus.Error) cs.error else cs.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}


/** Warteschlange: großes Cover am oberen Rand (verschmilzt mit dem Hintergrund), Name, Balken und Tasten darauf, darunter die nächsten Songs. */
@Composable
private fun QueueView(
    song: Song,
    state: PlayerUi,
    songsById: Map<Long, Song>,
    qv: () -> Float,
    positionMs: LongState,
    durationMs: Long,
    onSeekFraction: (Float) -> Unit,
    onSeekStart: () -> Unit,
    onSeekEnd: () -> Unit,
    onBack: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onPlay: (Long) -> Unit,
    onMove: (Long, Long) -> Unit,
    onRemove: (Long) -> Unit,
    onAddToPlaylist: () -> Unit,
    onSaveQueue: (String) -> Unit,
    dragState: androidx.compose.foundation.gestures.DraggableState,
    onDragStartQ: () -> Unit,
    onEndQ: (Float) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val density = LocalDensity.current
    val pitchPx = with(density) { (74.dp + 3.dp).toPx() }
    val ids = state.queue
    val local = remember(ids) { mutableStateListOf<Long>().also { it.addAll(ids) } }
    var dragId by remember { mutableStateOf<Long?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val canMove = true
    val selected = remember { mutableStateListOf<Long>() }
    // Zeilen werden erst nach und nach aufgebaut: schont die Animation beim Songwechsel und beim Hochwischen
    var rowsShown by remember { mutableIntStateOf(6) }
    val atTop by remember { derivedStateOf { qv() > 0.97f } }
    LaunchedEffect(atTop) {
        if (atTop) {
            delay(220)
            rowsShown = 16
            delay(200)
            rowsShown = Int.MAX_VALUE
        } else {
            rowsShown = 6
        }
    }
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    var showSave by remember { mutableStateOf(false) }
    SaveQueueDialogHost(showSave, { showSave = false }) { n -> showSave = false; onSaveQueue(n) }
    val btn = IconButtonDefaults.filledTonalIconButtonColors(containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer)

    Column(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val t = ((qv() - 0.45f) / 0.55f).coerceIn(0f, 1f)
                val a = t * t * (3f - 2f * t)
                this.alpha = a
                compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.ModulateAlpha
                // Unsichtbar = weit außerhalb, so fängt die vorbereitete Ansicht keine Berührungen ab
                translationY = if (a <= 0f) 100000f else (1f - a) * 60f
            }
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        // Fester Kopf: das Cover liegt darunter (wandert mit dem Finger hierher), Name, Balken und Tasten bleiben stehen
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f / 0.9f)
                .draggable(
                    state = dragState,
                    orientation = Orientation.Vertical,
                    onDragStarted = { onDragStartQ() },
                    onDragStopped = { v -> onEndQ(v) },
                ),
        ) {
            FilledTonalIconButton(
                onClick = onBack,
                modifier = Modifier.statusBarsPadding().padding(start = 16.dp, top = 8.dp).size(48.dp),
                shape = CircleShape,
                colors = btn,
            ) { Icon(Icons.Rounded.KeyboardArrowDown, "Zurück zum Player", Modifier.size(28.dp)) }

            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 20.dp)) {
                Text(song.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.marq())
                Text(song.artistLabel, style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.marq())
                Spacer(Modifier.height(2.dp))
                SeekSection(
                    positionMs = positionMs,
                    durationMs = if (state.durationMs > 0) state.durationMs else durationMs,
                    playing = state.isPlaying,
                    onSeek = onSeekFraction,
                    onSeekStart = onSeekStart,
                    onSeekEnd = onSeekEnd,
                )
                Row(
                    Modifier.fillMaxWidth().padding(top = 0.dp, bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FilledTonalIconButton(onClick = onPrev, modifier = Modifier.size(52.dp), shape = CircleShape, colors = btn) {
                        Icon(Icons.Rounded.SkipPrevious, "Zurück", Modifier.size(28.dp))
                    }
                    FilledIconButton(
                        onClick = onToggle,
                        modifier = Modifier.size(68.dp),
                        shape = RoundedCornerShape(if (state.isPlaying) 22.dp else 34.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = cs.primary, contentColor = cs.onPrimary),
                    ) {
                        Icon(
                            if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            if (state.isPlaying) "Pause" else "Abspielen",
                            Modifier.size(38.dp),
                        )
                    }
                    FilledTonalIconButton(onClick = onNext, modifier = Modifier.size(52.dp), shape = CircleShape, colors = btn) {
                        Icon(Icons.Rounded.SkipNext, "Weiter", Modifier.size(28.dp))
                    }
                }
            }
        }

        Row(Modifier.padding(start = 20.dp, end = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (selected.isNotEmpty()) {
                Text("${selected.size} ausgewählt", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { selected.toList().forEach { onRemove(it) }; selected.clear() }) {
                    Icon(Icons.Rounded.Delete, "Auswahl entfernen")
                }
                IconButton(onClick = { selected.clear() }) { Icon(Icons.Rounded.Close, "Auswahl aufheben") }
            } else {
                Text("Als Nächstes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { showSave = true }) { Icon(Icons.Rounded.Save, "Warteschlange als Playlist speichern") }
                IconButton(onClick = onAddToPlaylist) { Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, "Zu Playlist hinzufügen") }
            }
        }
        // Die Liste liegt auf einer Fläche mit runden oberen Ecken: Songs verschwinden unter einer weichen, runden Kante
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                .background(cs.surfaceContainerLow),
        ) {
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState(), enabled = dragId == null)) {
        Spacer(Modifier.height(12.dp))
        if (local.isEmpty()) {
            Text("Keine weiteren Songs in der Warteschlange.", modifier = Modifier.padding(20.dp), color = cs.onSurfaceVariant)
        }
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            val rows = local.toList().take(rowsShown)
            rows.forEachIndexed { i, id ->
                val s = songsById[id] ?: return@forEachIndexed
                key(id) {
                    val dragging = dragId == id
                    var sx by remember { mutableFloatStateOf(0f) }
                    var rowW by remember { mutableIntStateOf(1) }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .onSizeChanged { rowW = it.width.coerceAtLeast(1) }
                            .zIndex(if (dragging) 1f else 0f)
                            .graphicsLayer {
                                translationY = if (dragging) dragOffset else 0f
                                val sc = if (dragging) 1.03f else 1f
                                scaleX = sc
                                scaleY = sc
                                shadowElevation = if (dragging) 24f else 0f
                                shape = RoundedCornerShape(20.dp)
                            }
                            .pointerInput(id) {
                                // Nach rechts wischen nimmt den Song aus der Warteschlange
                                detectHorizontalDragGestures(
                                    onDragEnd = {
                                        if (sx > rowW * 0.35f) onRemove(id)
                                        sx = 0f
                                    },
                                    onDragCancel = { sx = 0f },
                                ) { change, d ->
                                    change.consume()
                                    sx = (sx + d).coerceAtLeast(0f)
                                }
                            },
                    ) {
                        Box(
                            Modifier
                                .matchParentSize()
                                .graphicsLayer { this.alpha = if (sx > 0f) 1f else 0f }
                                .clip(RoundedCornerShape(20.dp))
                                .background(cs.errorContainer),
                            contentAlignment = Alignment.CenterStart,
                        ) { Icon(Icons.Rounded.Delete, "Entfernen", Modifier.padding(start = 24.dp), tint = cs.onErrorContainer) }
                        Box(Modifier.graphicsLayer { translationX = sx }) {
                        SongRow(
                            song = s,
                            index = i,
                            count = rows.size,
                            isCurrent = id in selected,
                            onClick = { if (selected.isNotEmpty()) { if (id in selected) selected.remove(id) else selected.add(id) } else onPlay(id) },
                            onLongClick = {
                                haptic.tick(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                                if (id in selected) selected.remove(id) else selected.add(id)
                            },
                            trailing = {
                                if (canMove) {
                                    Box(
                                        Modifier
                                            .size(52.dp)
                                            .pointerInput(id) {
                                                detectDragGesturesAfterLongPress(
                                                    onDragStart = { dragId = id; dragOffset = 0f },
                                                    onDrag = { change, amt ->
                                                        change.consume()
                                                        dragOffset += amt.y
                                                        val cur = local.indexOf(id)
                                                        val target = (cur + (dragOffset / pitchPx).roundToInt()).coerceIn(0, local.lastIndex)
                                                        if (target != cur && cur >= 0) {
                                                            local.add(target, local.removeAt(cur))
                                                            dragOffset -= (target - cur) * pitchPx
                                                            haptic.tick()
                                                        }
                                                    },
                                                    onDragEnd = {
                                                        val to = local.indexOf(id)
                                                        val from = ids.indexOf(id)
                                                        if (to >= 0 && from >= 0 && to != from) onMove(id, ids[to])
                                                        dragId = null
                                                        dragOffset = 0f
                                                    },
                                                    onDragCancel = {
                                                        dragId = null
                                                        dragOffset = 0f
                                                        local.clear(); local.addAll(ids)
                                                    },
                                                )
                                            },
                                        contentAlignment = Alignment.Center,
                                    ) { Icon(Icons.Rounded.DragHandle, "Verschieben") }
                                }
                            },
                        )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.navigationBarsPadding().height(24.dp))
        }
        }
    }
}

@Composable
private fun SaveQueueDialogHost(show: Boolean, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    if (show) NameDialog(title = "Warteschlange speichern", initial = "Meine Warteschlange", confirm = "Speichern", onDismiss = onDismiss, onConfirm = { onSave(it) })
}

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t


/**
 * Die gerade gesungene Zeile leuchtet Buchstabe für Buchstabe auf. LRCLIB liefert nur Zeilenzeiten,
 * die Buchstaben werden deshalb gleichmäßig über die geschätzte Singdauer der Zeile verteilt.
 */
@Composable
private fun KaraokeLine(
    text: String,
    startMs: Long,
    endMs: Long?,
    wordStarts: LongArray? = null,
    lineEnd: Long? = null,
    positionMs: LongState,
    lit: Color,
    dim: Color,
    style: TextStyle,
) {
    // Gewicht pro Buchstabe: Vokale (Silbenkerne) werden gedehnt gesungen, Konsonanten kurz,
    // nach Komma/Punkt etc. entsteht eine kleine Atempause. So folgt das Leuchten dem Sprechrhythmus.
    val weights = remember(text) {
        val w = ArrayList<Float>()
        val t = text.trim()
        t.forEachIndexed { i, ch ->
            if (!ch.isWhitespace()) {
                val vowel = ch.lowercaseChar() in "aeiouyäöüàáâèéêìíòóôùú"
                var x = if (vowel) 2.4f else if (ch.isLetterOrDigit()) 0.9f else 0.3f
                val nxt = t.getOrNull(i + 1)
                if (ch in ",;:.!?–-…" && (nxt == null || nxt.isWhitespace())) x += 2.2f
                w.add(x)
            }
        }
        if (w.isEmpty()) w.add(1f)
        w
    }
    val total = remember(weights) { weights.sum() }
    val singMs = remember(text, startMs, endMs, total) {
        val syll = (total / 3.0f).coerceAtLeast(1f)
        val natural = syll * 300f + 400f
        val gap = (endMs?.let { it - startMs } ?: 5000L).toFloat()
        // Kurze Lücke: durchgehend gesungen. Lange Lücke (Pause/Instrumental): nur die natürliche Dauer.
        (if (gap <= natural * 1.6f) gap - 150f else natural).coerceAtLeast(400f)
    }
    // Wortzeiten aus der Audio-Analyse (falls vorhanden); sonst gleichmäßig über die Zeile verteilt
    val chunk = remember(text) { text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.map { it.length } }
    val wordCum = remember(weights, chunk) {
        val c = FloatArray(chunk.size + 1)
        var n = 0
        for (k in chunk.indices) {
            var sum = 0f
            repeat(chunk[k]) { sum += weights.getOrElse(n) { 0f }; n++ }
            c[k + 1] = c[k] + sum
        }
        c
    }
    val useWords = wordStarts != null && wordStarts.isNotEmpty() && wordStarts.size == chunk.size && chunk.sum() == weights.size
    val cut = if (useWords && wordStarts != null) {
        val p = positionMs.longValue + 60L
        var k = -1
        for (j in wordStarts.indices) { if (wordStarts[j] <= p) k = j else break }
        if (k < 0) 0f else {
            val ws = wordStarts[k]
            val we = if (k + 1 < wordStarts.size) wordStarts[k + 1] else (lineEnd ?: (ws + 800L))
            val span = (we - ws).coerceAtLeast(120L)
            val f = ((p - ws) / (span * 0.85f)).coerceIn(0f, 1f)
            wordCum[k] + f * (wordCum[k + 1] - wordCum[k])
        }
    } else {
        val frac = ((positionMs.longValue + 120L - startMs) / singMs).coerceIn(0f, 1f)
        // leichte S-Kurve: Anfang und Ende der Zeile wirken natürlicher
        (frac * frac * (3f - 2f * frac) * 0.35f + frac * 0.65f) * total
    }
    val styled = buildAnnotatedString {
        var n = 0
        var acc = 0f
        text.trim().forEach { ch ->
            if (ch.isWhitespace()) {
                append(ch)
            } else {
                val w = weights[n]
                val a = ((cut - acc) / w).coerceIn(0f, 1f)
                withStyle(SpanStyle(color = androidx.compose.ui.graphics.lerp(dim, lit, a))) { append(ch) }
                acc += w
                n++
            }
        }
    }
    Text(styled, style = style, fontWeight = FontWeight.Bold)
}

/** Schlaftimer im Material-3-Expressive-Stil: große Zahl, Plus/Minus, Schnellwahl und ein großer Startknopf. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SleepSheet(current: Int, onSet: (Int) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var minutes by remember { mutableIntStateOf(if (current > 0) current else 30) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        shape = RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(18.dp)).background(cs.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Bedtime, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(28.dp)) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Schlaftimer", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        if (current > 0) "Läuft noch $current min" else "Die Musik wird sanft ausgeblendet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                FilledTonalIconButton(
                    onClick = { minutes = (minutes - 5).coerceAtLeast(5) },
                    modifier = Modifier.size(64.dp),
                    shape = RoundedCornerShape(22.dp),
                ) { Icon(Icons.Rounded.Remove, "Weniger", Modifier.size(30.dp)) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$minutes", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.ExtraBold, color = cs.primary)
                    Text("Minuten", style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant)
                }
                FilledTonalIconButton(
                    onClick = { minutes = (minutes + 5).coerceAtMost(180) },
                    modifier = Modifier.size(64.dp),
                    shape = RoundedCornerShape(22.dp),
                ) { Icon(Icons.Rounded.Add, "Mehr", Modifier.size(30.dp)) }
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(10, 15, 30, 45, 60).forEach { v ->
                    val sel = minutes == v
                    val r by animateDpAsState(if (sel) 24.dp else 14.dp, spring(dampingRatio = 0.6f, stiffness = 400f), label = "presetShape")
                    val bg by animateColorAsState(if (sel) cs.primary else cs.surfaceContainerHighest, label = "presetBg")
                    val fg by animateColorAsState(if (sel) cs.onPrimary else cs.onSurface, label = "presetFg")
                    Box(
                        Modifier
                            .weight(1f)
                            .height(52.dp)
                            .clip(RoundedCornerShape(r))
                            .background(bg)
                            .clickable { minutes = v },
                        contentAlignment = Alignment.Center,
                    ) { Text("$v", color = fg, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(28.dp))
            androidx.compose.material3.Button(
                onClick = { onSet(minutes); onDismiss() },
                modifier = Modifier.fillMaxWidth().height(60.dp),
                shape = RoundedCornerShape(30.dp),
            ) {
                Icon(Icons.Rounded.Bedtime, null, Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Text(if (current > 0) "Timer neu starten" else "Timer starten", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            if (current > 0) {
                TextButton(onClick = { onSet(0); onDismiss() }, modifier = Modifier.padding(top = 4.dp)) { Text("Timer ausschalten") }
            }
        }
    }
}
